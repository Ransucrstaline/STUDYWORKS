package com.example.myapp.studyworks

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File
import java.io.FileOutputStream

class CreateClassActivity : AppCompatActivity() {

    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var imgSearch: ImageView
    private lateinit var btnBack: ImageView
    private lateinit var etSearch: EditText
    private lateinit var etClassName: EditText
    private lateinit var etSection: EditText
    private lateinit var etRoomNumber: EditText

    private lateinit var spinnerAcademicLevel: Spinner
    private lateinit var spinnerMonth: Spinner
    private lateinit var spinnerDate: Spinner
    private lateinit var spinnerDateNumber: Spinner
    private lateinit var spinnerTime: Spinner

    private lateinit var tvClassCode: TextView

    private lateinit var btnCancel: Button
    private lateinit var btnCreate: Button

    private lateinit var coverPickerArea: FrameLayout
    private lateinit var imgCoverPreview: ImageView
    private lateinit var tvCoverDefaultLabel: TextView
    private lateinit var tvCoverHint: TextView

    /** File path of the image copied to internal storage; empty = no image chosen */
    private var selectedCoverPath: String = ""

    /** When non-null we are in Edit mode for this existing class */
    private var editingClass: ClassData? = null

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) handleImageSelected(uri)
        }

    private val academicLevels = arrayOf(
        "Grade 7", "Grade 8", "Grade 9", "Grade 10",
        "Grade 11", "Grade 12"
    )
    private val months = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    private val days   = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    private val dates  = (1..31).map { it.toString() }.toTypedArray()
    private val times  = arrayOf(
        "7:00 am", "8:00 am", "9:00 am", "10:00 am", "11:00 am",
        "12:00 pm", "1:00 pm", "2:00 pm", "3:00 pm", "4:00 pm", "5:00 pm"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_class)

        initViews()
        setupSpinners()

        // --- Check for edit mode ---
        val editMode = intent.getBooleanExtra("edit_mode", false)
        val classId  = intent.getStringExtra("class_id") ?: ""
        if (editMode && classId.isNotEmpty()) {
            editingClass = DataManager.getClassById(this, classId)
            editingClass?.let { populateForEdit(it) }
        }

        setupClicks()
    }

    private fun initViews() {
        btnAdd    = findViewById(R.id.btnAdd)
        btnMenu   = findViewById(R.id.btnMenu)
        imgSearch = findViewById(R.id.imgSearch)
        btnBack   = findViewById(R.id.btnBack)

        etSearch    = findViewById(R.id.etSearch)
        etClassName = findViewById(R.id.etClassName)
        etSection   = findViewById(R.id.etSection)
        etRoomNumber= findViewById(R.id.etRoomNumber)

        spinnerAcademicLevel = findViewById(R.id.spinnerAcademicLevel)
        spinnerMonth         = findViewById(R.id.spinnerMonth)
        spinnerDate          = findViewById(R.id.spinnerDate)
        spinnerDateNumber    = findViewById(R.id.spinnerDateNumber)
        spinnerTime          = findViewById(R.id.spinnerTime)

        tvClassCode = findViewById(R.id.tvClassCode)
        btnCancel   = findViewById(R.id.btnCancel)
        btnCreate   = findViewById(R.id.btnCreate)

        coverPickerArea    = findViewById(R.id.coverPickerArea)
        imgCoverPreview    = findViewById(R.id.imgCoverPreview)
        tvCoverDefaultLabel= findViewById(R.id.tvCoverDefaultLabel)
        tvCoverHint        = findViewById(R.id.tvCoverHint)

        // Generate unique class code (only shown in create mode; kept for edit)
        val classCode = DataManager.generateUniqueClassCode(this)
        tvClassCode.text = "Class Code: $classCode"
    }

    /** Pre-fill all fields when editing an existing class */
    private fun populateForEdit(cls: ClassData) {
        etClassName.setText(cls.className)
        etSection.setText(cls.section)
        etRoomNumber.setText(cls.roomNumber)
        tvClassCode.text = "Class Code: ${cls.classCode}"
        btnCreate.text = "Save Changes"

        // Pre-select academic level
        val levelIdx = academicLevels.indexOf(cls.academicLevel)
        if (levelIdx >= 0) spinnerAcademicLevel.setSelection(levelIdx)

        // Pre-load cover image if it exists
        selectedCoverPath = cls.coverImagePath
        val coverFile = if (cls.coverImagePath.isNotEmpty()) File(cls.coverImagePath) else null
        if (coverFile != null && coverFile.exists()) {
            imgCoverPreview.visibility = android.view.View.VISIBLE
            tvCoverDefaultLabel.visibility = android.view.View.GONE
            tvCoverHint.text = "Tap to change cover photo"
            Glide.with(this).load(coverFile).centerCrop().into(imgCoverPreview)
        }
    }

    private fun setupSpinners() {
        val academicAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, academicLevels)
        academicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerAcademicLevel.adapter = academicAdapter

        val monthAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, months)
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMonth.adapter = monthAdapter

        val dayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, days)
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDate.adapter = dayAdapter

        val dateAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, dates)
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDateNumber.adapter = dateAdapter

        val timeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, times)
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTime.adapter = timeAdapter
    }

    private fun setupClicks() {
        coverPickerArea.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        btnAdd.setOnClickListener { startActivity(Intent(this, Add::class.java)) }
        btnMenu.setOnClickListener { startActivity(Intent(this, Profile::class.java)) }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancel.setOnClickListener {
            if (editingClass != null) {
                finish()
            } else {
                clearFields()
                Toast.makeText(this, "Form cleared", Toast.LENGTH_SHORT).show()
            }
        }

        btnCreate.setOnClickListener {
            if (editingClass != null) saveEdits() else createClass()
        }

        btnBack.setOnClickListener { finish() }

    }

    private fun handleImageSelected(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri) ?: return
            val coversDir = File(filesDir, "covers").apply { mkdirs() }
            val destFile  = File(coversDir, "cover_${System.currentTimeMillis()}.jpg")

            FileOutputStream(destFile).use { out -> inputStream.copyTo(out) }
            inputStream.close()

            selectedCoverPath = destFile.absolutePath

            imgCoverPreview.visibility     = android.view.View.VISIBLE
            tvCoverDefaultLabel.visibility = android.view.View.GONE
            tvCoverHint.text = "Tap to change cover photo"

            Glide.with(this).load(destFile).centerCrop().into(imgCoverPreview)
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearFields() {
        etClassName.text.clear()
        etSection.text.clear()
        etRoomNumber.text.clear()
        spinnerAcademicLevel.setSelection(0)
        spinnerMonth.setSelection(0)
        spinnerDate.setSelection(0)
        spinnerDateNumber.setSelection(0)
        spinnerTime.setSelection(0)
        selectedCoverPath = ""
        imgCoverPreview.visibility     = android.view.View.GONE
        tvCoverDefaultLabel.visibility = android.view.View.VISIBLE
        tvCoverHint.text = "Optional — tap to upload a cover photo"
    }

    private fun createClass() {
        val className    = etClassName.text.toString().trim()
        val section      = etSection.text.toString().trim()
        val roomNumber   = etRoomNumber.text.toString().trim()
        val academicLevel= spinnerAcademicLevel.selectedItem.toString()
        val classCode    = tvClassCode.text.toString().replace("Class Code: ", "")
        val schedule     = "${spinnerDate.selectedItem}, ${spinnerMonth.selectedItem} ${spinnerDateNumber.selectedItem}, ${spinnerTime.selectedItem}"

        if (className.isEmpty())  { Toast.makeText(this, "Enter class name", Toast.LENGTH_SHORT).show(); return }
        if (section.isEmpty())    { Toast.makeText(this, "Enter section", Toast.LENGTH_SHORT).show(); return }
        if (roomNumber.isEmpty()) { Toast.makeText(this, "Enter room number", Toast.LENGTH_SHORT).show(); return }

        val newClass = ClassData(
            className      = className,
            section        = section,
            schedule       = schedule,
            roomNumber     = roomNumber,
            academicLevel  = academicLevel,
            classCode      = classCode,
            coverImagePath = selectedCoverPath,
            teacherName    = DataManager.getCurrentUser()?.username ?: ""  // NEW: store teacher
        )

        DataManager.addClass(this, newClass)
        Toast.makeText(this, "Class '$className' created successfully!", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MyClassesActivity::class.java))
        finish()
    }

    /** Save edits to an existing class */
    private fun saveEdits() {
        val cls = editingClass ?: return
        val className    = etClassName.text.toString().trim()
        val section      = etSection.text.toString().trim()
        val roomNumber   = etRoomNumber.text.toString().trim()
        val academicLevel= spinnerAcademicLevel.selectedItem.toString()
        val schedule     = "${spinnerDate.selectedItem}, ${spinnerMonth.selectedItem} ${spinnerDateNumber.selectedItem}, ${spinnerTime.selectedItem}"

        if (className.isEmpty())  { Toast.makeText(this, "Enter class name", Toast.LENGTH_SHORT).show(); return }
        if (section.isEmpty())    { Toast.makeText(this, "Enter section", Toast.LENGTH_SHORT).show(); return }
        if (roomNumber.isEmpty()) { Toast.makeText(this, "Enter room number", Toast.LENGTH_SHORT).show(); return }

        val updated = cls.copy(
            className      = className,
            section        = section,
            schedule       = schedule,
            roomNumber     = roomNumber,
            academicLevel  = academicLevel,
            coverImagePath = selectedCoverPath
        )

        DataManager.updateClass(this, updated)
        Toast.makeText(this, "Class '$className' updated!", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MyClassesActivity::class.java))
        finish()
    }
}
