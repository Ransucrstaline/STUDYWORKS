package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Add : AppCompatActivity() {

    private lateinit var imgLogo: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var btnCreateClass: LinearLayout
    private lateinit var btnJoinClass: LinearLayout
    private lateinit var btnAddTodo: LinearLayout
    private lateinit var btnBack: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_options)

        initViews()
        applyRoleVisibility()
        setupClicks()
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)
    }

    private fun initViews() {
        imgLogo        = findViewById(R.id.imgLogo)
        btnAdd         = findViewById(R.id.btnAdd)
        btnMenu        = findViewById(R.id.btnMenu)
        btnCreateClass = findViewById(R.id.btnCreateClass)
        btnJoinClass   = findViewById(R.id.btnJoinClass)
        btnAddTodo     = findViewById(R.id.btnAddTodo)
        btnBack        = findViewById(R.id.btnBack)
    }

    /**
     * Teachers  → see "Create Class" + "Join Class" (join kept for flexibility)
     * Students  → see "Join Class" only; "Create Class" is hidden
     */
    private fun applyRoleVisibility() {
        if (DataManager.isStudent()) {
            btnCreateClass.visibility = View.GONE
        }
    }

    private fun setupClicks() {
        btnAdd.setOnClickListener {
            Toast.makeText(this, "You are already on Add screen", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener { finish() }

        btnCreateClass.setOnClickListener {
            startActivity(Intent(this, CreateClassActivity::class.java))
        }

        btnJoinClass.setOnClickListener {
            startActivity(Intent(this, JoinClass::class.java))
        }

        btnAddTodo.setOnClickListener {
            startActivity(Intent(this, AddTodoActivity::class.java))
        }
    }
}
