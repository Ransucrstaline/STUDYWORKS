package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class AddClassOrJoinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_class_or_join)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val btnCreateClass = findViewById<LinearLayout>(R.id.btnCreateClass)
        val btnJoinClass = findViewById<LinearLayout>(R.id.btnJoinClass)
        val btnClose = findViewById<ImageView>(R.id.btnClose)

        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        // ✅ MAIN ACTIONS
        btnCreateClass.setOnClickListener {
            startActivity(Intent(this, CreateClassActivity::class.java))
        }

        // ✅ JOIN CLASS — show styled popup dialog instead of full activity
        btnJoinClass.setOnClickListener {
            showJoinClassDialog()
        }

        btnClose.setOnClickListener { finish() }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // ✅ NAVIGATION
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }
        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }

    // ── Styled Join Class Dialog ───────────────────────────────────────────

    private fun showJoinClassDialog() {
        val currentUser = DataManager.getCurrentUser()
        if (currentUser == null) {
            Toast.makeText(this, "Please log in first.", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_join_class, null)

        val etClassCode        = dialogView.findViewById<EditText>(R.id.etClassCode)
        val btnFindClass       = dialogView.findViewById<Button>(R.id.btnFindClass)
        val layoutClassPreview = dialogView.findViewById<LinearLayout>(R.id.layoutClassPreview)
        val tvPreviewClassName = dialogView.findViewById<TextView>(R.id.tvPreviewClassName)
        val tvPreviewSection   = dialogView.findViewById<TextView>(R.id.tvPreviewSection)
        val tvPreviewTeacher   = dialogView.findViewById<TextView>(R.id.tvPreviewTeacher)
        val tvPreviewSchedule  = dialogView.findViewById<TextView>(R.id.tvPreviewSchedule)
        val btnCancelJoin      = dialogView.findViewById<TextView>(R.id.btnCancelJoin)
        val btnConfirmJoin     = dialogView.findViewById<Button>(R.id.btnConfirmJoin)

        var foundClass: ClassData? = null

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        // ── Find Class ────────────────────────────────────────────────────
        btnFindClass.setOnClickListener {
            val code = etClassCode.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Please enter a class code", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = DataManager.getClasses(this).find { it.classCode == code }
            if (cls == null) {
                layoutClassPreview.visibility = View.GONE
                btnConfirmJoin.isEnabled = false
                btnConfirmJoin.alpha = 0.5f
                foundClass = null
                Toast.makeText(this, "Class code not found. Please try again.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (DataManager.isStudentEnrolled(this, currentUser.username, cls.id)) {
                layoutClassPreview.visibility = View.GONE
                btnConfirmJoin.isEnabled = false
                btnConfirmJoin.alpha = 0.5f
                foundClass = null
                Toast.makeText(this, "You are already enrolled in this class.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Populate preview card
            foundClass = cls
            tvPreviewClassName.text = cls.className
            tvPreviewSection.text   = cls.section
            tvPreviewSchedule.text  = cls.schedule.ifEmpty { "Not specified" }
            tvPreviewTeacher.text   = cls.teacherName.ifEmpty { "Not assigned" }

            layoutClassPreview.visibility = View.VISIBLE
            btnConfirmJoin.isEnabled = true
            btnConfirmJoin.alpha = 1.0f
        }

        // ── Confirm Join ──────────────────────────────────────────────────
        btnConfirmJoin.setOnClickListener {
            val cls = foundClass ?: return@setOnClickListener

            DataManager.enrollStudent(
                this,
                StudentEnrollment(
                    studentName = currentUser.username,
                    classId     = cls.id,
                    section     = cls.section
                )
            )

            val teacherMsg = if (cls.teacherName.isNotEmpty()) "\nTeacher: ${cls.teacherName}" else ""
            Toast.makeText(this, "Joined ${cls.className}$teacherMsg", Toast.LENGTH_LONG).show()

            dialog.dismiss()
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        btnCancelJoin.setOnClickListener { dialog.dismiss() }

        dialog.show()

        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.90).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
}
