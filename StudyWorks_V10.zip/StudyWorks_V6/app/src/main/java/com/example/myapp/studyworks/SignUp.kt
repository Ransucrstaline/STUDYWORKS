package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.studyworks.R

class SignUp : AppCompatActivity() {

    private var isPasswordVisible = false
    private var selectedRole: String = ""   // "Teacher" or "Student"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val imgBack        = findViewById<ImageView>(R.id.btnBack)
        val imgEye         = findViewById<ImageView>(R.id.imgEye)
        val etFirstName    = findViewById<EditText>(R.id.etFirstName)
        val etLastName     = findViewById<EditText>(R.id.etLastName)
        val etUsername     = findViewById<EditText>(R.id.etUsername)
        val etPassword     = findViewById<EditText>(R.id.etPassword)
        val btnSignUp      = findViewById<Button>(R.id.btnSignUp)
        val tvLogin        = findViewById<TextView>(R.id.tvLogin)
        val btnTeacher     = findViewById<TextView>(R.id.btnRoleTeacher)   // NEW
        val btnStudent     = findViewById<TextView>(R.id.btnRoleStudent)   // NEW

        // ── Role toggle helpers ─────────────────────────────────────────
        fun applyRoleStyle(selected: TextView, unselected: TextView) {
            selected.setBackgroundResource(R.drawable.bg_role_selected)
            selected.setTextColor(ContextCompat.getColor(this, android.R.color.white))
            unselected.setBackgroundResource(R.drawable.bg_role_unselected)
            unselected.setTextColor(ContextCompat.getColor(this, R.color.role_unselected_text))
        }

        btnTeacher.setOnClickListener {
            selectedRole = "Teacher"
            applyRoleStyle(btnTeacher, btnStudent)
        }

        btnStudent.setOnClickListener {
            selectedRole = "Student"
            applyRoleStyle(btnStudent, btnTeacher)
        }

        // ── Back ────────────────────────────────────────────────────────
        imgBack.setOnClickListener { finish() }

        // ── Already have account ────────────────────────────────────────
        tvLogin.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }

        // ── Password visibility ─────────────────────────────────────────
        imgEye.setOnClickListener {
            if (isPasswordVisible) {
                etPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off)
            } else {
                etPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off)
            }
            etPassword.setSelection(etPassword.text.length)
            isPasswordVisible = !isPasswordVisible
        }

        // ── Sign Up ─────────────────────────────────────────────────────
        btnSignUp.setOnClickListener {
            val firstName = etFirstName.text.toString().trim()
            val lastName  = etLastName.text.toString().trim()
            val username  = etUsername.text.toString().trim()
            val password  = etPassword.text.toString().trim()

            if (firstName.isEmpty() || lastName.isEmpty() ||
                username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (selectedRole.isEmpty()) {
                Toast.makeText(this, "Please select your role", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newUser = UserData(
                firstName    = firstName,
                lastName     = lastName,
                username     = username,
                passwordHash = password,  // In a real app, hash this!
                role         = selectedRole
            )

            if (DataManager.registerUser(this, newUser)) {
                Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this, Login::class.java))
                finish()
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
