package com.example.myapp.studyworks

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class ClassDetailsActivity : AppCompatActivity() {

    private lateinit var materialsContainer: LinearLayout
    private lateinit var tvNoMaterials: TextView
    private var currentClassId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class_details)

        // ===== GET DATA =====
        currentClassId = intent.getStringExtra("class_id") ?: ""
        val className = intent.getStringExtra("class_name")
        val subjectName = intent.getStringExtra("subject_name")

        // If class_id is empty, try to find it by name if possible (for featured subjects)
        if (currentClassId.isEmpty()) {
            val nameToSearch = className ?: subjectName
            val foundClass = DataManager.getClasses(this).find { it.className == nameToSearch }
            currentClassId = foundClass?.id ?: ""
        }

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        // ===== TOP CONTROLS =====
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnCalendar = findViewById<LinearLayout>(R.id.btnCalendar)

        // ===== SUBJECT / CLASS INFO =====
        val tvSubjectName = findViewById<TextView>(R.id.tvSubjectName)
        val tvSectionName = findViewById<TextView>(R.id.tvSectionName)
        val tvSchedule = findViewById<TextView>(R.id.tvSchedule)
        val tvRoomNumber = findViewById<TextView>(R.id.tvRoomNumber)

        // ===== ENROLLMENT =====
        val tvEnrollmentCode = findViewById<TextView>(R.id.tvEnrollmentCode)
        val btnCopyCode = findViewById<LinearLayout>(R.id.btnCopyCode)

        // ===== MATERIALS =====
        materialsContainer = findViewById(R.id.materialsContainer)
        tvNoMaterials = findViewById(R.id.tvNoMaterials)

        // ===== ACTION BUTTONS =====
        val btnAnnouncements = findViewById<LinearLayout>(R.id.btnAnnouncements)
        val btnAttendance = findViewById<LinearLayout>(R.id.btnAttendance)
        val btnDeadline = findViewById<LinearLayout>(R.id.btnDeadline)
        val btnQuiz = findViewById<LinearLayout>(R.id.btnQuiz)
        val btnStudentRecords = findViewById<LinearLayout>(R.id.btnStudentRecords)
        val btnUploadMaterial = findViewById<LinearLayout>(R.id.btnUploadMaterial)
        val btnCreateQuiz = findViewById<LinearLayout>(R.id.btnCreateQuiz)

        // ===== NAVIGATION =====
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)

        // Populate Class Info
        val displayTitle = className ?: subjectName ?: "Class Details"
        tvSubjectName.text = displayTitle

        val tvBannerName    = findViewById<TextView>(R.id.tvBannerName)
        val imgSubjectBanner= findViewById<ImageView>(R.id.imgSubjectBanner)
        val tvTotalStudents = findViewById<TextView>(R.id.tvTotalStudents)

        val classData = DataManager.getClassById(this, currentClassId)
        if (classData != null) {
            tvSectionName.text    = classData.section
            tvEnrollmentCode.text = classData.classCode
            tvSchedule.text       = classData.schedule
            tvRoomNumber.text     = classData.roomNumber

            // ── Cover photo or text fallback ──────────────────────────────
            tvBannerName.text = classData.className
            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                tvBannerName.visibility     = View.GONE
                imgSubjectBanner.visibility = View.VISIBLE
                Glide.with(this)
                    .load(coverFile)
                    .centerCrop()
                    .placeholder(R.drawable.bg_subject_card_empty)
                    .into(imgSubjectBanner)
            } else {
                imgSubjectBanner.visibility = View.GONE
                tvBannerName.visibility     = View.VISIBLE
            }

            // ── Real enrolled student count ───────────────────────────────
            val enrolledCount = DataManager.getStudentsByClass(this, currentClassId).size
            tvTotalStudents.text = "$enrolledCount enrolled"
        } else {
            // No classData — show safe defaults
            tvBannerName.text           = displayTitle
            tvBannerName.visibility     = View.VISIBLE
            imgSubjectBanner.visibility = View.GONE
            tvTotalStudents.text        = "0 enrolled"
        }

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        btnCopyCode.setOnClickListener {
            val code = tvEnrollmentCode.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Enrollment Code", code)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "Copied: $code", Toast.LENGTH_SHORT).show()
        }

        // ===== ACTION BUTTONS =====
        btnAnnouncements.setOnClickListener {
            val intent = Intent(this, Announcements::class.java)
            intent.putExtra("class_id", currentClassId)
            startActivity(intent)
        }

        btnAttendance.setOnClickListener {
            val intent = Intent(this, AttendanceActivity::class.java)
            intent.putExtra("class_id", currentClassId)
            startActivity(intent)
        }

        btnDeadline.setOnClickListener {
            startActivity(Intent(this, Deadline::class.java))
        }

        btnQuiz.setOnClickListener {
            startActivity(Intent(this, Quiz::class.java))
        }

        btnStudentRecords.setOnClickListener {
            val intent = Intent(this, StudentRecords::class.java)
            intent.putExtra("class_id", currentClassId)
            startActivity(intent)
        }

        btnUploadMaterial.setOnClickListener {
            val intent = Intent(this, UploadMaterialActivity::class.java)
            intent.putExtra("class_id", currentClassId)
            startActivity(intent)
        }

        btnCreateQuiz.setOnClickListener {
            startActivity(Intent(this, CreateQuiz::class.java))
        }



        loadMaterials()
    }

    override fun onResume() {
        super.onResume()
        loadMaterials()
    }

    private fun loadMaterials() {
        materialsContainer.removeAllViews()
        val materials = DataManager.getMaterialsByClass(currentClassId)

        if (materials.isEmpty()) {
            tvNoMaterials.visibility = View.VISIBLE
        } else {
            tvNoMaterials.visibility = View.GONE
            for (material in materials) {
                val materialView = layoutInflater.inflate(R.layout.item_material, materialsContainer, false)

                val tvTitle = materialView.findViewById<TextView>(R.id.tvMaterialTitle)
                val tvFileName = materialView.findViewById<TextView>(R.id.tvFileName)
                val tvDate = materialView.findViewById<TextView>(R.id.tvUploadDate)

                tvTitle.text = material.title
                tvFileName.text = material.fileName
                tvDate.text = "Uploaded: ${material.uploadDate}"

                materialView.setOnClickListener {
                    Toast.makeText(this, "Opening ${material.fileName}", Toast.LENGTH_SHORT).show()
                }

                materialsContainer.addView(materialView)
            }
        }
    }
}