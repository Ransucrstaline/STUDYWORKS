package com.example.myapp.studyworks

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UploadMaterialActivity : AppCompatActivity() {

    private lateinit var imgLogo: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var etMaterialTitle: EditText
    private lateinit var etMaterialDescription: EditText
    private lateinit var uploadDropZone: LinearLayout
    private lateinit var tvSelectedFile: TextView

    private lateinit var btnCancel: Button
    private lateinit var btnUpload: Button
    private lateinit var btnBack: ImageView

    private var selectedFileUri: Uri? = null
    private var selectedFileName: String = ""
    private var classId: String = ""

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedFileUri = uri
            selectedFileName = getFileNameFromUri(uri)
            tvSelectedFile.text = "Selected: $selectedFileName"
            Toast.makeText(this, "File selected: $selectedFileName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_material)

        // Get class ID from intent
        classId = intent.getStringExtra("class_id") ?: ""

        initViews()
        setupClicks()
    }

    private fun initViews() {
        imgLogo = findViewById(R.id.imgLogo)
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)

        etMaterialTitle = findViewById(R.id.etMaterialTitle)
        etMaterialDescription = findViewById(R.id.etMaterialDescription)
        uploadDropZone = findViewById(R.id.uploadDropZone)
        tvSelectedFile = findViewById(R.id.tvSelectedFile)

        btnCancel = findViewById(R.id.btnCancel)
        btnUpload = findViewById(R.id.btnUpload)
        btnBack = findViewById(R.id.btnClose) // Matched with XML ID

    }

    private fun setupClicks() {

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        uploadDropZone.setOnClickListener {
            openFilePicker()
        }

        btnCancel.setOnClickListener {
            clearFields()
            Toast.makeText(this, "Upload cancelled", Toast.LENGTH_SHORT).show()
        }

        btnUpload.setOnClickListener {
            uploadMaterial()
        }

        btnBack.setOnClickListener {
            finish()
        }

    }

    private fun openFilePicker() {
        filePickerLauncher.launch("*/*")
    }

    private fun getFileNameFromUri(uri: Uri): String {
        return try {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                val nameIndex = it.getColumnIndex("_display_name")
                it.moveToFirst()
                it.getString(nameIndex)
            } ?: "Unknown File"
        } catch (e: Exception) {
            "Unknown File"
        }
    }

    private fun uploadMaterial() {
        val title = etMaterialTitle.text.toString().trim()
        val description = etMaterialDescription.text.toString().trim()

        if (title.isEmpty()) {
            Toast.makeText(this, "Enter material title", Toast.LENGTH_SHORT).show()
            return
        }

        if (description.isEmpty()) {
            Toast.makeText(this, "Enter material description", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedFileUri == null || selectedFileName.isEmpty()) {
            Toast.makeText(this, "Please select a file to upload", Toast.LENGTH_SHORT).show()
            return
        }

        // Create material data
        val uploadDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val material = MaterialData(
            classId = classId,
            title = title,
            description = description,
            fileName = selectedFileName,
            uploadDate = uploadDate
        )

        // Save to DataManager
        DataManager.addMaterial(material)

        Toast.makeText(this, "Material uploaded successfully!", Toast.LENGTH_SHORT).show()
        clearFields()
        finish()
    }

    private fun clearFields() {
        etMaterialTitle.text.clear()
        etMaterialDescription.text.clear()
        selectedFileUri = null
        selectedFileName = ""
        tvSelectedFile.text = "No file selected"
    }
}
