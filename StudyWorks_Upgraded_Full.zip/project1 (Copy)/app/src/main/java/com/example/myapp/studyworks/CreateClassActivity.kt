package com.example.myapp.studyworks

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File
import java.io.FileOutputStream

class CreateClassActivity : AppCompatActivity() {

    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var imgFilter: ImageView
    private lateinit var imgSearch: ImageView
    private lateinit var btnBack: ImageView

    private lateinit var navHome: LinearLayout
    private lateinit var navClasses: LinearLayout
    private lateinit var navNotification: LinearLayout
    private lateinit var navProfile: LinearLayout
    private lateinit var navMore: LinearLayout

    private lateinit var etSearch: EditText
    private lateinit var etClassName: EditText
    private lateinit var etSection: EditText
    private lateinit var etRoomNumber: EditText

    private lateinit var spinnerAcademicLevel: Spinner
    private lateinit var spinnerMonth: Spinner
    private lateinit var spinnerDate: Spinner
    private lateinit var spinnerDateNumber: Spinner
    private lateinit var spinnerTime: Spinner

    private lateinit var tvClassCode: TextView

    private lateinit var btnCancel: Button
    private lateinit var btnCreate: Button

    // ── Cover image views (NEW) ──────────────────────────────────────────────
    private lateinit var coverPickerArea: FrameLayout
    private lateinit var imgCoverPreview: ImageView
    private lateinit var tvCoverDefaultLabel: TextView
    private lateinit var tvCoverHint: TextView

    /** File path of the image copied to internal storage; empty = no image chosen */
    private var selectedCoverPath: String = ""

    // ActivityResultLauncher for the image picker
    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) {
                handleImageSelected(uri)
            }
        }
    // ────────────────────────────────────────────────────────────────────────

    private val academicLevels = arrayOf(
        "Grade 7", "Grade 8", "Grade 9", "Grade 10",
        "Grade 11", "Grade 12",
        "1st Year College", "2nd Year College",
        "3rd Year College", "4th Year College"
    )

    private val months = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    private val days = arrayOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    private val dates = (1..31).map { it.toString() }.toTypedArray()
    private val times = arrayOf(
        "7:00 am", "8:00 am", "9:00 am", "10:00 am", "11:00 am",
        "12:00 pm", "1:00 pm", "2:00 pm", "3:00 pm", "4:00 pm", "5:00 pm"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_class)

        initViews()
        setupSpinners()
        setupClicks()
    }

    private fun initViews() {
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)
        imgFilter = findViewById(R.id.imgFilter)
        imgSearch = findViewById(R.id.imgSearch)
        btnBack = findViewById(R.id.btnBack)

        navHome = findViewById(R.id.navHome)
        navClasses = findViewById(R.id.navClasses)
        navNotification = findViewById(R.id.navNotification)
        navProfile = findViewById(R.id.navProfile)
        navMore = findViewById(R.id.navMore)

        etSearch = findViewById(R.id.etSearch)
        etClassName = findViewById(R.id.etClassName)
        etSection = findViewById(R.id.etSection)
        etRoomNumber = findViewById(R.id.etRoomNumber)

        spinnerAcademicLevel = findViewById(R.id.spinnerAcademicLevel)
        spinnerMonth = findViewById(R.id.spinnerMonth)
        spinnerDate = findViewById(R.id.spinnerDate)
        spinnerDateNumber = findViewById(R.id.spinnerDateNumber)
        spinnerTime = findViewById(R.id.spinnerTime)

        tvClassCode = findViewById(R.id.tvClassCode)

        btnCancel = findViewById(R.id.btnCancel)
        btnCreate = findViewById(R.id.btnCreate)

        // Cover image views (NEW)
        coverPickerArea = findViewById(R.id.coverPickerArea)
        imgCoverPreview = findViewById(R.id.imgCoverPreview)
        tvCoverDefaultLabel = findViewById(R.id.tvCoverDefaultLabel)
        tvCoverHint = findViewById(R.id.tvCoverHint)

        // Generate and display a UNIQUE class code
        val classCode = DataManager.generateUniqueClassCode(this)
        tvClassCode.text = "Class Code: $classCode"
    }

    private fun setupSpinners() {
        val academicAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, academicLevels)
        academicAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerAcademicLevel.adapter = academicAdapter

        val monthAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, months)
        monthAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMonth.adapter = monthAdapter

        val dayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, days)
        dayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDate.adapter = dayAdapter

        val dateAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, dates)
        dateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDateNumber.adapter = dateAdapter

        val timeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, times)
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTime.adapter = timeAdapter
    }

    private fun setupClicks() {
        // Cover image picker tap (NEW)
        coverPickerArea.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancel.setOnClickListener {
            clearFields()
            Toast.makeText(this, "Form cleared", Toast.LENGTH_SHORT).show()
        }

        btnCreate.setOnClickListener {
            createClass()
        }

        btnBack.setOnClickListener {
            finish()
        }

        setupBottomNavigation()
    }

    /**
     * Called when the user picks an image from the gallery.
     * Copies the image to internal app storage so it remains accessible
     * even if the original URI is revoked later.
     */
    private fun handleImageSelected(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri) ?: return
            val coversDir = File(filesDir, "covers").apply { mkdirs() }
            val destFile = File(coversDir, "cover_${System.currentTimeMillis()}.jpg")

            FileOutputStream(destFile).use { out ->
                inputStream.copyTo(out)
            }
            inputStream.close()

            selectedCoverPath = destFile.absolutePath

            // Show the chosen image as a live preview
            imgCoverPreview.visibility = android.view.View.VISIBLE
            tvCoverDefaultLabel.visibility = android.view.View.GONE
            tvCoverHint.text = "Tap to change cover photo"

            Glide.with(this)
                .load(destFile)
                .centerCrop()
                .into(imgCoverPreview)

        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBottomNavigation() {
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }

    private fun clearFields() {
        etClassName.text.clear()
        etSection.text.clear()
        etRoomNumber.text.clear()
        spinnerAcademicLevel.setSelection(0)
        spinnerMonth.setSelection(0)
        spinnerDate.setSelection(0)
        spinnerDateNumber.setSelection(0)
        spinnerTime.setSelection(0)

        // Reset cover picker to default state
        selectedCoverPath = ""
        imgCoverPreview.visibility = android.view.View.GONE
        tvCoverDefaultLabel.visibility = android.view.View.VISIBLE
        tvCoverHint.text = "Optional — tap to upload a cover photo"
    }

    private fun createClass() {
        val className = etClassName.text.toString().trim()
        val section = etSection.text.toString().trim()
        val roomNumber = etRoomNumber.text.toString().trim()
        val academicLevel = spinnerAcademicLevel.selectedItem.toString()
        val classCode = tvClassCode.text.toString().replace("Class Code: ", "")

        val schedule = "${spinnerDate.selectedItem}, ${spinnerMonth.selectedItem} ${spinnerDateNumber.selectedItem}, ${spinnerTime.selectedItem}"

        if (className.isEmpty()) {
            Toast.makeText(this, "Enter class name", Toast.LENGTH_SHORT).show()
            return
        }

        if (section.isEmpty()) {
            Toast.makeText(this, "Enter section", Toast.LENGTH_SHORT).show()
            return
        }

        if (roomNumber.isEmpty()) {
            Toast.makeText(this, "Enter room number", Toast.LENGTH_SHORT).show()
            return
        }

        val newClass = ClassData(
            className = className,
            section = section,
            schedule = schedule,
            roomNumber = roomNumber,
            academicLevel = academicLevel,
            classCode = classCode,
            coverImagePath = selectedCoverPath   // NEW: empty string = show name as cover
        )

        DataManager.addClass(this, newClass)

        Toast.makeText(this, "Class '$className' created successfully!", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MyClassesActivity::class.java))
        finish()
    }
}
