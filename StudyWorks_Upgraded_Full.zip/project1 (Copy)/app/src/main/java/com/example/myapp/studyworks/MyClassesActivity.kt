package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)

        val imgFilipinoCard = findViewById<ImageView>(R.id.imgFilipinoCard)
        val imgMathCard = findViewById<ImageView>(R.id.imgMathCard)
        val imgPeCard = findViewById<ImageView>(R.id.imgPeCard)
        val imgEnglishCard = findViewById<ImageView>(R.id.imgEnglishCard)

        val tvFilipino = findViewById<TextView>(R.id.tvFilipino)
        val tvMath = findViewById<TextView>(R.id.tvMath)
        val tvPe = findViewById<TextView>(R.id.tvPe)
        val tvEnglish = findViewById<TextView>(R.id.tvEnglish)

        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        setupClassClicks(
            imgFilipinoCard, imgMathCard, imgPeCard, imgEnglishCard,
            tvFilipino, tvMath, tvPe, tvEnglish
        )
        setupBottomNavigation()
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    /**
     * Inflates item_dynamic_class for every created class.
     *
     * Cover logic:
     *   • classData.coverImagePath is non-empty and the file exists
     *       → hide tvCoverName, show imgClassCard, load with Glide
     *   • otherwise
     *       → show tvCoverName with the class name, hide imgClassCard
     */
    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()
        val classes = DataManager.getClasses(this)

        for (classData in classes) {
            val cardView = layoutInflater.inflate(
                R.layout.item_dynamic_class, dynamicClassesContainer, false
            )

            val tvCoverName = cardView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = cardView.findViewById<ImageView>(R.id.imgClassCard)
            val tvName = cardView.findViewById<TextView>(R.id.tvClassName)
            val tvSection = cardView.findViewById<TextView>(R.id.tvClassSection)

            tvName.text = classData.className
            tvSection.text = classData.section

            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                // ── Custom photo cover ──────────────────────────────────────
                tvCoverName.visibility = android.view.View.GONE
                imgClassCard.visibility = android.view.View.VISIBLE

                Glide.with(this)
                    .load(coverFile)
                    .centerCrop()
                    .placeholder(R.drawable.bg_subject_card)
                    .into(imgClassCard)
            } else {
                // ── Default: subject-name text cover ────────────────────────
                imgClassCard.visibility = android.view.View.GONE
                tvCoverName.visibility = android.view.View.VISIBLE
                tvCoverName.text = classData.className

                // Pick a background colour from a palette based on the class name
                tvCoverName.setBackgroundColor(pickCoverColor(classData.className))
            }

            cardView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("class_id", classData.id)
                intent.putExtra("subject_name", classData.className)
                startActivity(intent)
            }

            dynamicClassesContainer.addView(cardView)
        }
    }

    /**
     * Returns a consistent, visually distinct colour for a class name.
     * Uses the name's hashCode so the same subject always gets the same colour.
     */
    private fun pickCoverColor(name: String): Int {
        val palette = listOf(
            0xFF3A7D44.toInt(),  // Forest Green
            0xFF1565C0.toInt(),  // Deep Blue
            0xFF6A1B9A.toInt(),  // Purple
            0xFFBF360C.toInt(),  // Deep Orange
            0xFF00695C.toInt(),  // Teal
            0xFF4527A0.toInt(),  // Deep Purple
            0xFF558B2F.toInt(),  // Olive Green
            0xFF283593.toInt()   // Indigo
        )
        val index = Math.abs(name.hashCode()) % palette.size
        return palette[index]
    }

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnAddClass.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupClassClicks(
        imgFilipinoCard: ImageView,
        imgMathCard: ImageView,
        imgPeCard: ImageView,
        imgEnglishCard: ImageView,
        tvFilipino: TextView,
        tvMath: TextView,
        tvPe: TextView,
        tvEnglish: TextView
    ) {
        imgFilipinoCard.setOnClickListener { openSubjectDetails("Filipino") }
        imgMathCard.setOnClickListener { openSubjectDetails("Mathematics") }
        imgPeCard.setOnClickListener { openSubjectDetails("Physical Education") }
        imgEnglishCard.setOnClickListener { openSubjectDetails("English") }

        tvFilipino.setOnClickListener { openSubjectDetails("Filipino") }
        tvMath.setOnClickListener { openSubjectDetails("Mathematics") }
        tvPe.setOnClickListener { openSubjectDetails("Physical Education") }
        tvEnglish.setOnClickListener { openSubjectDetails("English") }
    }

    private fun openSubjectDetails(subjectName: String) {
        val intent = Intent(this, ClassDetailsActivity::class.java)
        intent.putExtra("subject_name", subjectName)
        startActivity(intent)
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener { }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
