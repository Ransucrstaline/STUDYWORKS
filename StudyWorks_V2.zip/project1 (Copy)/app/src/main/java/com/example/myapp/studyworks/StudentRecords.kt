package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout
    private var classId: String = ""

    private val hardcodedStudents = listOf(
        StudentInfo(
            name = "Hannah Isabelle",
            section = "BSCS 3A",
            attendanceList = listOf(
                AttendanceInfo("Present - 28", 30, listOf("April 10, 2026", "April 12, 2026")),
                AttendanceInfo("Late - 2", 30, listOf("April 11, 2026", "April 18, 2026")),
                AttendanceInfo("Absent - 1", 30, listOf("April 20, 2026"))
            )
        ),
        StudentInfo(
            name = "John Cruz",
            section = "BSCS 3B",
            attendanceList = listOf(
                AttendanceInfo("Present - 25", 27, listOf("April 10, 2026")),
                AttendanceInfo("Absent - 2", 27, listOf("April 14, 2026"))
            )
        ),
        StudentInfo(
            name = "Maria Santos",
            section = "BSIT 2A",
            attendanceList = listOf(
                AttendanceInfo("Present - 32", 35, listOf("April 09, 2026")),
                AttendanceInfo("Late - 1", 35, listOf("April 17, 2026"))
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        classId = intent.getStringExtra("class_id") ?: ""

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)
        val btnBack = findViewById<ImageView>(R.id.btnBack)

        // ===== INPUTS =====
        etSearch = findViewById(R.id.etSearch)
        tableBody = findViewById(R.id.tableBody)

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            finish()
        }

        // ===== INITIAL DATA LOAD =====
        loadAndRenderData()

        // ===== SEARCH =====
        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString().trim().lowercase()
            loadAndRenderData(query)
            Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun loadAndRenderData(query: String = "") {
        val dynamicStudents = if (classId.isNotEmpty()) {
            DataManager.getStudentsByClass(this,classId).map {
                StudentInfo(it.studentName, it.section, emptyList())
            }
        } else {
            emptyList()
        }

        val allStudents = hardcodedStudents + dynamicStudents
        
        val filtered = if (query.isEmpty()) {
            allStudents
        } else {
            allStudents.filter {
                it.name.lowercase().contains(query) ||
                it.section.lowercase().contains(query)
            }
        }
        
        renderStudentRows(filtered)
    }

    private fun renderStudentRows(list: List<StudentInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No student records found"
                textSize = 15f
                setPadding(32, 32, 32, 32)
                gravity = android.view.Gravity.CENTER
            }
            tableBody.addView(emptyText)
            return
        }

        list.forEachIndexed { index, item ->

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
                isClickable = true
                isFocusable = true
                setBackgroundResource(android.R.color.white)
            }

            val nameText = TextView(this).apply {
                text = item.name
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setTextColor(android.graphics.Color.BLACK)
            }

            val sectionText = TextView(this).apply {
                text = item.section
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setTextColor(android.graphics.Color.BLACK)
                gravity = android.view.Gravity.CENTER
            }

            row.addView(nameText)
            row.addView(sectionText)

            row.setOnClickListener {
                val intent = Intent(this, StudentRecordsAttendance::class.java)
                intent.putExtra("student_name", item.name)
                intent.putExtra("student_section", item.section)
                startActivity(intent)
            }

            tableBody.addView(row)

            if (index != list.lastIndex) {
                val divider = android.view.View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#D9D9D9"))
                }
                tableBody.addView(divider)
            }
        }
    }
}