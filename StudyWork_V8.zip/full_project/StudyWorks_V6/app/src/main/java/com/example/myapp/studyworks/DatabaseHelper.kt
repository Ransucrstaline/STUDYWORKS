package com.example.myapp.studyworks

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "StudyWorks.db"
        private const val DATABASE_VERSION = 4  // bumped: v3 → v4 adds role column to users

        // Users table
        private const val TABLE_USERS = "users"
        private const val COL_ID = "id"
        private const val COL_FIRST_NAME = "first_name"
        private const val COL_LAST_NAME = "last_name"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"
        private const val COL_ROLE = "role"   // NEW: "TEACHER" or "STUDENT"

        // Classes table
        private const val TABLE_CLASSES = "classes"
        private const val COL_CLASS_ID = "class_id"
        private const val COL_CLASS_NAME = "class_name"
        private const val COL_SECTION = "section"
        private const val COL_SCHEDULE = "schedule"
        private const val COL_ROOM = "room"
        private const val COL_LEVEL = "level"
        private const val COL_CODE = "code"
        private const val COL_COVER_IMAGE = "cover_image"

        // Enrollments table
        private const val TABLE_ENROLLMENTS = "enrollments"
        private const val COL_ENROLL_ID = "enroll_id"
        private const val COL_ENROLL_STUDENT = "student_name"
        private const val COL_ENROLL_CLASS_ID = "class_id"
        private const val COL_ENROLL_SECTION = "section"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE $TABLE_USERS ("
                    + "$COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "$COL_FIRST_NAME TEXT,"
                    + "$COL_LAST_NAME TEXT,"
                    + "$COL_USERNAME TEXT UNIQUE,"
                    + "$COL_PASSWORD TEXT,"
                    + "$COL_ROLE TEXT DEFAULT 'STUDENT')"
        )

        db.execSQL(
            "CREATE TABLE $TABLE_CLASSES ("
                    + "$COL_CLASS_ID TEXT PRIMARY KEY,"
                    + "$COL_CLASS_NAME TEXT,"
                    + "$COL_SECTION TEXT,"
                    + "$COL_SCHEDULE TEXT,"
                    + "$COL_ROOM TEXT,"
                    + "$COL_LEVEL TEXT,"
                    + "$COL_CODE TEXT,"
                    + "$COL_COVER_IMAGE TEXT DEFAULT '')"
        )

        db.execSQL(
            "CREATE TABLE $TABLE_ENROLLMENTS ("
                    + "$COL_ENROLL_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + "$COL_ENROLL_STUDENT TEXT,"
                    + "$COL_ENROLL_CLASS_ID TEXT,"
                    + "$COL_ENROLL_SECTION TEXT,"
                    + "UNIQUE($COL_ENROLL_STUDENT, $COL_ENROLL_CLASS_ID))"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // v3 → v4: add role column to users (preserves all existing data)
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE $TABLE_USERS ADD COLUMN $COL_ROLE TEXT DEFAULT 'STUDENT'")
        }
        // v2 → v3: add cover_image column to classes
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE $TABLE_CLASSES ADD COLUMN $COL_COVER_IMAGE TEXT DEFAULT ''")
        }
        // v1 → v2 or any fresh start: recreate
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_CLASSES")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_ENROLLMENTS")
            onCreate(db)
        }
    }

    // ============== USER OPERATIONS ==============

    fun addUser(user: UserData): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_FIRST_NAME, user.firstName)
            put(COL_LAST_NAME, user.lastName)
            put(COL_USERNAME, user.username)
            put(COL_PASSWORD, user.passwordHash)
            put(COL_ROLE, user.role)
        }
        val success = db.insert(TABLE_USERS, null, values)
        db.close()
        return success != -1L
    }

    fun checkUser(username: String, passwordHash: String): UserData? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_USERS, null,
            "$COL_USERNAME=? AND $COL_PASSWORD=?",
            arrayOf(username, passwordHash),
            null, null, null
        )
        var user: UserData? = null
        if (cursor.moveToFirst()) {
            val roleIdx = cursor.getColumnIndex(COL_ROLE)
            val role = if (roleIdx >= 0) cursor.getString(roleIdx) ?: "STUDENT" else "STUDENT"
            user = UserData(
                firstName = cursor.getString(cursor.getColumnIndexOrThrow(COL_FIRST_NAME)),
                lastName = cursor.getString(cursor.getColumnIndexOrThrow(COL_LAST_NAME)),
                username = cursor.getString(cursor.getColumnIndexOrThrow(COL_USERNAME)),
                passwordHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD)),
                role = role
            )
        }
        cursor.close()
        db.close()
        return user
    }

    // ============== CLASS OPERATIONS ==============

    fun addClass(classData: ClassData) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_CLASS_ID, classData.id)
            put(COL_CLASS_NAME, classData.className)
            put(COL_SECTION, classData.section)
            put(COL_SCHEDULE, classData.schedule)
            put(COL_ROOM, classData.roomNumber)
            put(COL_LEVEL, classData.academicLevel)
            put(COL_CODE, classData.classCode)
            put(COL_COVER_IMAGE, classData.coverImagePath)
        }
        db.insert(TABLE_CLASSES, null, values)
        db.close()
    }

    fun getAllClasses(): List<ClassData> {
        val classList = mutableListOf<ClassData>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_CLASSES", null)
        if (cursor.moveToFirst()) {
            do {
                val coverIdx = cursor.getColumnIndex(COL_COVER_IMAGE)
                val coverPath = if (coverIdx >= 0) cursor.getString(coverIdx) ?: "" else ""
                classList.add(
                    ClassData(
                        id = cursor.getString(cursor.getColumnIndexOrThrow(COL_CLASS_ID)),
                        className = cursor.getString(cursor.getColumnIndexOrThrow(COL_CLASS_NAME)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_SECTION)),
                        schedule = cursor.getString(cursor.getColumnIndexOrThrow(COL_SCHEDULE)),
                        roomNumber = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROOM)),
                        academicLevel = cursor.getString(cursor.getColumnIndexOrThrow(COL_LEVEL)),
                        classCode = cursor.getString(cursor.getColumnIndexOrThrow(COL_CODE)),
                        coverImagePath = coverPath
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return classList
    }

    fun updateClass(classData: ClassData) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_CLASS_NAME, classData.className)
            put(COL_SECTION, classData.section)
            put(COL_SCHEDULE, classData.schedule)
            put(COL_ROOM, classData.roomNumber)
            put(COL_LEVEL, classData.academicLevel)
            put(COL_CODE, classData.classCode)
            put(COL_COVER_IMAGE, classData.coverImagePath)
        }
        db.update(TABLE_CLASSES, values, "$COL_CLASS_ID=?", arrayOf(classData.id))
        db.close()
    }

    fun deleteClass(classId: String) {
        val db = this.writableDatabase
        db.delete(TABLE_CLASSES, "$COL_CLASS_ID=?", arrayOf(classId))
        db.close()
    }

    // ============== ENROLLMENT OPERATIONS ==============

    fun addEnrollment(enrollment: StudentEnrollment) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_ENROLL_STUDENT, enrollment.studentName)
            put(COL_ENROLL_CLASS_ID, enrollment.classId)
            put(COL_ENROLL_SECTION, enrollment.section)
        }
        db.insertWithOnConflict(TABLE_ENROLLMENTS, null, values, SQLiteDatabase.CONFLICT_IGNORE)
        db.close()
    }

    fun deleteEnrollment(studentName: String, classId: String) {
        val db = this.writableDatabase
        db.delete(
            TABLE_ENROLLMENTS,
            "$COL_ENROLL_STUDENT=? AND $COL_ENROLL_CLASS_ID=?",
            arrayOf(studentName, classId)
        )
        db.close()
    }

    fun isEnrolled(studentName: String, classId: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, arrayOf(COL_ENROLL_ID),
            "$COL_ENROLL_STUDENT=? AND $COL_ENROLL_CLASS_ID=?",
            arrayOf(studentName, classId),
            null, null, null
        )
        val enrolled = cursor.moveToFirst()
        cursor.close()
        db.close()
        return enrolled
    }

    fun getEnrollmentsByClass(classId: String): List<StudentEnrollment> {
        val list = mutableListOf<StudentEnrollment>()
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, null,
            "$COL_ENROLL_CLASS_ID=?",
            arrayOf(classId),
            null, null, null
        )
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    StudentEnrollment(
                        studentName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_STUDENT)),
                        classId = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_CLASS_ID)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_SECTION))
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }

    fun getEnrollmentsByStudent(studentName: String): List<StudentEnrollment> {
        val list = mutableListOf<StudentEnrollment>()
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_ENROLLMENTS, null,
            "$COL_ENROLL_STUDENT=?",
            arrayOf(studentName),
            null, null, null
        )
        if (cursor.moveToFirst()) {
            do {
                list.add(
                    StudentEnrollment(
                        studentName = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_STUDENT)),
                        classId = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_CLASS_ID)),
                        section = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENROLL_SECTION))
                    )
                )
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return list
    }
}
