package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class JoinClass : AppCompatActivity() {

    /** True when arriving directly from Login (student has no classes yet). */
    private var isFirstTime = false

    private lateinit var btnBack: ImageView
    private lateinit var etClassCode: EditText
    private lateinit var btnJoin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join_class)

        isFirstTime = intent.getBooleanExtra("FIRST_TIME", false)

        btnBack     = findViewById(R.id.btnClose)
        etClassCode = findViewById(R.id.etEnrollmentCode)
        btnJoin     = findViewById(R.id.btnJoin)

        // If first-time flow, back button goes to Login (not MyClasses)
        btnBack.setOnClickListener {
            if (isFirstTime) {
                // Allow students to skip joining for now and go to (empty) home
                startActivity(Intent(this, HomeActivity::class.java))
            }
            finish()
        }

        // Show a helpful banner for first-time students
        if (isFirstTime) {
            val tvHint = findViewById<TextView?>(R.id.tvJoinHint)
            tvHint?.text =
                "Welcome! Enter the class code provided by your teacher to get started."
        }

        btnJoin.setOnClickListener { joinClass() }

        // Bottom navigation (only shown when NOT first-time flow)
        if (!isFirstTime) {
            setupNav()
        }
    }

    private fun joinClass() {
        val classCode = etClassCode.text.toString().trim()

        if (classCode.isEmpty()) {
            Toast.makeText(this, "Enter class code", Toast.LENGTH_SHORT).show()
            return
        }

        val classToJoin = DataManager.getClassByCode(this, classCode)

        if (classToJoin == null) {
            Toast.makeText(this, "Invalid class code. Please try again.", Toast.LENGTH_SHORT).show()
            return
        }

        val currentUser = DataManager.getCurrentUser()
        if (currentUser == null) {
            Toast.makeText(this, "Session error. Please log in again.", Toast.LENGTH_SHORT).show()
            return
        }

        if (DataManager.isStudentEnrolled(this, currentUser.username, classToJoin.id)) {
            Toast.makeText(this, "You are already enrolled in this class.", Toast.LENGTH_SHORT).show()
            return
        }

        DataManager.enrollStudent(
            this,
            StudentEnrollment(
                studentName = currentUser.username,
                classId     = classToJoin.id,
                section     = classToJoin.section
            )
        )

        Toast.makeText(this, "Successfully joined: ${classToJoin.className}", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MyClassesActivity::class.java))
        finish()
    }

    private fun setupNav() {
        val navHome         = findViewById<LinearLayout?>(R.id.navHome)
        val navClasses      = findViewById<LinearLayout?>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout?>(R.id.navNotification)
        val navProfile      = findViewById<LinearLayout?>(R.id.navProfile)
        val navMore         = findViewById<LinearLayout?>(R.id.navMore)

        navHome?.setOnClickListener         { startActivity(Intent(this, HomeActivity::class.java)); finish() }
        navClasses?.setOnClickListener      { startActivity(Intent(this, MyClassesActivity::class.java)); finish() }
        navNotification?.setOnClickListener { startActivity(Intent(this, Notification::class.java)); finish() }
        navProfile?.setOnClickListener      { startActivity(Intent(this, Profile::class.java)); finish() }
        navMore?.setOnClickListener         { startActivity(Intent(this, MoreActivity::class.java)); finish() }
    }
}
