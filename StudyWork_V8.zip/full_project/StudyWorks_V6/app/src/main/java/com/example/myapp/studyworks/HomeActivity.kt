package com.example.myapp.studyworks

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class HomeActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout
    private lateinit var todoContainer: LinearLayout
    private lateinit var announcementContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)
        todoContainer           = findViewById(R.id.todoContainer)
        announcementContainer   = findViewById(R.id.announcementContainer)

        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgMenu   = findViewById<ImageView>(R.id.imgMenu)
        val tvViewAll = findViewById<TextView>(R.id.tvViewAll)

        imgSearch.setOnClickListener {
            Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
        }

        imgMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        tvViewAll.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.HOME)

        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()
    }

    /**
     * Teachers see all classes.
     * Students see only classes they are enrolled in.
     * If a Student has no enrolled classes yet, shows a prompt to join one.
     */
    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()

        // Use role-aware helper – Teachers get all classes, Students get enrolled only
        val classes = DataManager.getClassesForCurrentUser(this)
        val isStudent = DataManager.isStudent()

        if (classes.isNotEmpty()) {
            val titleView = TextView(this).apply {
                text = "My Classes"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                setPadding(0, 16, 0, 12)
            }
            dynamicClassesContainer.addView(titleView)

            for (i in classes.indices step 2) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.bottomMargin = 12.dpToPx() }
                }

                val card1 = createClassCard(classes[i])
                row.addView(card1)

                if (i + 1 < classes.size) {
                    val card2 = createClassCard(classes[i + 1])
                    row.addView(card2)
                } else {
                    // spacer for odd item
                    val spacer = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 0, 1f)
                    }
                    row.addView(spacer)
                }

                dynamicClassesContainer.addView(row)
            }
        } else {
            // Empty state — differs by role
            val emptyTv = TextView(this).apply {
                if (isStudent) {
                    text = "You haven't joined any class yet.\nAsk your teacher for a class code."
                } else {
                    text = "No classes yet.\nTap '+' to create your first class."
                }
                textSize = 14f
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
                gravity = Gravity.CENTER
                setPadding(0, 32, 0, 32)
            }
            dynamicClassesContainer.addView(emptyTv)

            // Students get a quick-join button in the empty state
            if (isStudent) {
                val joinBtn = TextView(this).apply {
                    text = "Join a Class"
                    textSize = 14f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.white))
                    setBackgroundResource(R.drawable.bg_signup_button)
                    gravity = Gravity.CENTER
                    setPadding(24, 12, 24, 12)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also {
                        it.gravity = Gravity.CENTER_HORIZONTAL
                        it.topMargin = 8.dpToPx()
                    }
                }
                joinBtn.setOnClickListener {
                    startActivity(Intent(this@HomeActivity, JoinClass::class.java))
                }
                dynamicClassesContainer.addView(joinBtn)
            }
        }
    }

    private fun createClassCard(classData: ClassData): FrameLayout {
        val card = layoutInflater.inflate(R.layout.item_dynamic_class, null) as FrameLayout
        card.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).also {
            it.marginEnd = 8.dpToPx()
        }

        val tvCoverName = card.findViewById<TextView>(R.id.tvCoverName)
        val imgClassCard = card.findViewById<ImageView>(R.id.imgClassCard)
        val tvClassName = card.findViewById<TextView>(R.id.tvClassName)
        val tvSection = card.findViewById<TextView>(R.id.tvSection)

        tvClassName?.text = classData.className
        tvSection?.text = classData.section

        if (classData.coverImagePath.isNotEmpty() && File(classData.coverImagePath).exists()) {
            tvCoverName?.visibility = View.GONE
            imgClassCard?.visibility = View.VISIBLE
            imgClassCard?.let { Glide.with(this).load(File(classData.coverImagePath)).into(it) }
        } else {
            tvCoverName?.visibility = View.VISIBLE
            imgClassCard?.visibility = View.GONE
            tvCoverName?.text = classData.className
        }

        card.setOnClickListener {
            val intent = Intent(this, ClassDetailsActivity::class.java)
            intent.putExtra("CLASS_DATA", classData)
            startActivity(intent)
        }

        return card
    }

    private fun loadTodos() {
        todoContainer.removeAllViews()
        val todos = DataManager.getTodos()
        if (todos.isEmpty()) return

        val titleView = TextView(this).apply {
            text = "To-Do"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            setPadding(0, 16, 0, 8)
        }
        todoContainer.addView(titleView)

        todos.take(3).forEach { todo ->
            val tv = TextView(this).apply {
                text = "• ${todo.title}  (${todo.dueDate})"
                textSize = 13f
                setPadding(0, 4, 0, 4)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            }
            todoContainer.addView(tv)
        }
    }

    private fun loadAnnouncements() {
        announcementContainer.removeAllViews()
        val announcements = DataManager.getAllAnnouncements()
        if (announcements.isEmpty()) return

        val titleView = TextView(this).apply {
            text = "Announcements"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            setPadding(0, 16, 0, 8)
        }
        announcementContainer.addView(titleView)

        announcements.take(3).forEach { ann ->
            val tv = TextView(this).apply {
                text = "• ${ann.title}"
                textSize = 13f
                setPadding(0, 4, 0, 4)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            }
            announcementContainer.addView(tv)
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()
}
