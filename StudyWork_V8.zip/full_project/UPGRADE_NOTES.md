# StudyWorks V8 — Role-Based Upgrade

## What changed

### 1. `DataManager.kt`
- `UserData` now has a `role: String` field (`"TEACHER"` or `"STUDENT"`, default `"STUDENT"`)
- Added `isTeacher()` / `isStudent()` helpers
- Added `getClassesForCurrentUser(context)` — returns ALL classes for teachers, enrolled-only for students
- Added `getClassByCode(context, code)` helper used by JoinClass
- Added `hasAnyEnrolledClass(context)` — used by Login routing
- `saveRoleToPrefs` / `getRoleFromPrefs` — persists role to SharedPreferences for quick access
- `getNotifications()` now calls `getClassesForCurrentUser` (students only see their class notifications)
- `clearAllData()` now also clears `currentUser`
- `loginUser()` automatically saves role to prefs

### 2. `DatabaseHelper.kt`  ← DB version bumped **3 → 4**
- `users` table gains a `role TEXT DEFAULT 'STUDENT'` column
- `onUpgrade`: v3→v4 migration uses `ALTER TABLE` so **existing user data is preserved**
- `addUser()` persists the role field
- `checkUser()` reads the role field back (null-safe for old rows)

### 3. `activity_sign_up.xml`
- Added a **Teacher / Student toggle** (two pill buttons) below the "Sign up" title
- Teacher is selected by default (filled style), Student switches via tap

### 4. `SignUp.kt`
- Tracks `selectedRole` ("TEACHER" / "STUDENT")
- `selectRole()` updates pill visual states (filled vs ghost)
- Passes role into `UserData` on registration
- Toast confirms which role was registered

### 5. `Login.kt`
- After successful login, checks `user.role`:
  - **Teacher** → `HomeActivity` (unchanged full access)
  - **Student with enrolled classes** → `HomeActivity`
  - **Student with NO classes** → `JoinClass` (with `FIRST_TIME = true` extra)

### 6. `HomeActivity.kt`
- Calls `DataManager.getClassesForCurrentUser()` instead of `getClasses()`
- Empty-state message is role-aware:
  - Teacher: "Create your first class"
  - Student: "Ask your teacher for a class code" + a **Join a Class** button shortcut

### 7. `MyClassesActivity.kt`
- Top bar is role-aware:
  - **Teacher**: "Add Class" button → `CreateClassActivity` (same as before)
  - **Student**: same button repurposed as "Join Class" → `JoinClass`
- Long-press on a class card:
  - **Teacher**: Edit / Delete (same as before)
  - **Student**: Leave Class (removes enrollment, can rejoin with code)
- List source is `getClassesForCurrentUser()` — students only see their enrolled classes

### 8. `JoinClass.kt`
- Accepts `FIRST_TIME` boolean extra from Login
- Back button in first-time flow goes to `HomeActivity` (allows skipping join)
- Optional `tvJoinHint` TextView shown for first-time welcome message
- Uses `DataManager.getClassByCode()` (cleaner lookup)

---

## How to integrate

Copy each file into its matching path inside your Android project:

```
app/src/main/java/com/example/myapp/studyworks/
    DataManager.kt
    DatabaseHelper.kt
    SignUp.kt
    Login.kt
    HomeActivity.kt
    MyClassesActivity.kt
    JoinClass.kt

app/src/main/res/layout/
    activity_sign_up.xml
```

The database version bump (3→4) triggers an `ALTER TABLE` migration automatically
on first launch after install — existing users and classes are **not lost**.

---

## User flows after upgrade

### Teacher
1. Sign up → select **Teacher** → register
2. Login → goes to Home with **all classes**
3. "My Classes" → can create, edit, delete classes
4. Share the 4-digit class code with students

### Student
1. Sign up → select **Student** → register
2. Login → if no classes joined → lands on **Join Class** screen
3. Enter teacher's code → enrolled → goes to My Classes
4. Home & My Classes show **only enrolled classes**
5. Long-press a class card → **Leave Class** option
