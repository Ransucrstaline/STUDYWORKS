package com.example.myapp.studyworks

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class ClassDetailsActivity : AppCompatActivity() {

    private lateinit var materialsContainer: LinearLayout
    private lateinit var tvNoMaterials: TextView
    private var currentClassId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class_details)

        // ── Determine current user role ──────────────────────────────
        DataManager.restoreSessionIfNeeded(this)
        val isTeacher = DataManager.isTeacher(this)

        // ── Get ClassData from parcelable (preferred) or fall back to extras ──
        val classData: ClassData? = intent.getParcelableExtra("CLASS_DATA")
            ?: run {
                // Legacy path: some callers pass individual string extras
                val classId  = intent.getStringExtra("class_id") ?: ""
                val className = intent.getStringExtra("class_name")
                val subjectName = intent.getStringExtra("subject_name")
                val idToSearch = classId.ifEmpty {
                    val nameToSearch = className ?: subjectName
                    DataManager.getClasses(this).find { it.className == nameToSearch }?.id ?: ""
                }
                DataManager.getClassById(this, idToSearch)
            }

        currentClassId = classData?.id ?: ""

        // ===== BIND VIEWS =====
        val btnAdd          = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu         = findViewById<ImageView>(R.id.btnMenu)
        val btnBack         = findViewById<ImageView>(R.id.btnBack)
        val btnCalendar     = findViewById<LinearLayout>(R.id.btnCalendar)

        val tvSubjectName   = findViewById<TextView>(R.id.tvSubjectName)
        val tvSectionName   = findViewById<TextView>(R.id.tvSectionName)
        val tvSchedule      = findViewById<TextView>(R.id.tvSchedule)
        val tvRoomNumber    = findViewById<TextView>(R.id.tvRoomNumber)
        val tvBannerName    = findViewById<TextView>(R.id.tvBannerName)
        val imgSubjectBanner= findViewById<ImageView>(R.id.imgSubjectBanner)
        val tvTotalStudents = findViewById<TextView>(R.id.tvTotalStudents)

        // Enrollment code row — teacher-only
        val tvEnrollmentCode = findViewById<TextView>(R.id.tvEnrollmentCode)
        val btnCopyCode      = findViewById<LinearLayout>(R.id.btnCopyCode)

        materialsContainer = findViewById(R.id.materialsContainer)
        tvNoMaterials      = findViewById(R.id.tvNoMaterials)

        // ===== ACTION BUTTONS =====
        val btnAnnouncements  = findViewById<LinearLayout>(R.id.btnAnnouncements)
        val btnAttendance     = findViewById<LinearLayout>(R.id.btnAttendance)
        val btnDeadline       = findViewById<LinearLayout>(R.id.btnDeadline)
        val btnQuiz           = findViewById<LinearLayout>(R.id.btnQuiz)
        // Teacher-only buttons
        val btnStudentRecords = findViewById<LinearLayout>(R.id.btnStudentRecords)
        val btnUploadMaterial = findViewById<LinearLayout>(R.id.btnUploadMaterial)
        val btnCreateQuiz     = findViewById<LinearLayout>(R.id.btnCreateQuiz)

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)

        // ===== POPULATE CLASS INFO =====
        val displayTitle = classData?.className ?: "Class Details"
        tvSubjectName.text = displayTitle

        if (classData != null) {
            tvSectionName.text    = classData.section
            tvSchedule.text       = classData.schedule
            tvRoomNumber.text     = classData.roomNumber
            tvBannerName.text     = classData.className

            val coverFile = classData.coverImagePath
                .takeIf { it.isNotEmpty() }?.let { File(it) }

            if (coverFile != null && coverFile.exists()) {
                tvBannerName.visibility     = View.GONE
                imgSubjectBanner.visibility = View.VISIBLE
                Glide.with(this).load(coverFile).centerCrop()
                    .placeholder(R.drawable.bg_subject_card_empty).into(imgSubjectBanner)
            } else {
                imgSubjectBanner.visibility = View.GONE
                tvBannerName.visibility     = View.VISIBLE
            }

            val enrolledCount = DataManager.getStudentsByClass(this, currentClassId).size
            tvTotalStudents.text = "$enrolledCount enrolled"
        } else {
            tvBannerName.text           = displayTitle
            tvBannerName.visibility     = View.VISIBLE
            imgSubjectBanner.visibility = View.GONE
            tvTotalStudents.text        = "0 enrolled"
        }

        // ===== ROLE-BASED UI VISIBILITY =====
        if (isTeacher) {
            // Teachers see the enrollment code so they can share it
            tvEnrollmentCode.text = classData?.classCode ?: ""
            btnCopyCode.visibility = View.VISIBLE

            // Teacher-only action buttons
            btnStudentRecords.visibility = View.VISIBLE
            btnUploadMaterial.visibility = View.VISIBLE
            btnCreateQuiz.visibility     = View.VISIBLE

            // Teachers can add classes from here
            btnAdd.setOnClickListener {
                startActivity(Intent(this, AddClassOrJoinActivity::class.java))
            }
        } else {
            // Students do NOT see the enrollment code section
            tvEnrollmentCode.visibility = View.GONE
            btnCopyCode.visibility      = View.GONE

            // Students do NOT see teacher-only buttons
            btnStudentRecords.visibility = View.GONE
            btnUploadMaterial.visibility = View.GONE
            btnCreateQuiz.visibility     = View.GONE

            // Students have no meaningful action for btnAdd in class detail
            btnAdd.visibility = View.GONE
        }

        // ===== COMMON BUTTON ACTIONS =====
        btnMenu.setOnClickListener { startActivity(Intent(this, Profile::class.java)) }
        btnBack.setOnClickListener { finish() }
        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        btnCopyCode.setOnClickListener {
            val code = tvEnrollmentCode.text.toString()
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Enrollment Code", code))
            Toast.makeText(this, "Copied: $code", Toast.LENGTH_SHORT).show()
        }

        btnAnnouncements.setOnClickListener {
            startActivity(Intent(this, Announcements::class.java).apply {
                putExtra("class_id", currentClassId)
            })
        }

        btnAttendance.setOnClickListener {
            startActivity(Intent(this, AttendanceActivity::class.java).apply {
                putExtra("class_id", currentClassId)
            })
        }

        btnDeadline.setOnClickListener {
            startActivity(Intent(this, Deadline::class.java))
        }

        btnQuiz.setOnClickListener {
            startActivity(Intent(this, Quiz::class.java))
        }

        // Teacher-only actions (safe — buttons are GONE for students)
        btnStudentRecords.setOnClickListener {
            startActivity(Intent(this, StudentRecords::class.java).apply {
                putExtra("class_id", currentClassId)
            })
        }

        btnUploadMaterial.setOnClickListener {
            startActivity(Intent(this, UploadMaterialActivity::class.java).apply {
                putExtra("class_id", currentClassId)
            })
        }

        btnCreateQuiz.setOnClickListener {
            startActivity(Intent(this, CreateQuiz::class.java))
        }

        loadMaterials()
    }

    override fun onResume() {
        super.onResume()
        loadMaterials()
    }

    private fun loadMaterials() {
        materialsContainer.removeAllViews()
        val materials = DataManager.getMaterialsByClass(currentClassId)

        if (materials.isEmpty()) {
            tvNoMaterials.visibility = View.VISIBLE
        } else {
            tvNoMaterials.visibility = View.GONE
            for (material in materials) {
                val materialView = layoutInflater.inflate(R.layout.item_material, materialsContainer, false)
                materialView.findViewById<TextView>(R.id.tvMaterialTitle).text = material.title
                materialView.findViewById<TextView>(R.id.tvFileName).text = material.fileName
                materialView.findViewById<TextView>(R.id.tvUploadDate).text =
                    "Uploaded: ${material.uploadDate}"
                materialView.setOnClickListener {
                    Toast.makeText(this, "Opening ${material.fileName}", Toast.LENGTH_SHORT).show()
                }
                materialsContainer.addView(materialView)
            }
        }
    }
}
