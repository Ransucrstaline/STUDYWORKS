package com.example.myapp.studyworks

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Login : AppCompatActivity() {

    private var isPasswordVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername       = findViewById<EditText>(R.id.etUsername)
        val etPasswordMain   = findViewById<EditText>(R.id.etPassword)
        val cbRemember       = findViewById<CheckBox>(R.id.cbRemember)
        val btnLogin         = findViewById<Button>(R.id.btnLogin)
        val tvSignUp         = findViewById<TextView>(R.id.btnSignup)
        val imgBack          = findViewById<ImageView>(R.id.btnBack)
        val imgEye           = findViewById<ImageView>(R.id.imgEye)
        val tvForgotPassword = findViewById<TextView>(R.id.tvForgotPassword)

        val sharedPref   = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val isRemembered = sharedPref.getBoolean("RememberMe", false)

        if (isRemembered) {
            etUsername.setText(sharedPref.getString("LastUsername", ""))
            cbRemember.isChecked = true
        }

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPasswordMain.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = DataManager.loginUser(this, username, password)

            if (user != null) {
                // Persist remember-me preference
                with(sharedPref.edit()) {
                    putBoolean("RememberMe", cbRemember.isChecked)
                    putString("LastUsername", if (cbRemember.isChecked) username else "")
                    apply()
                }

                Toast.makeText(this, "Welcome, ${user.firstName}!", Toast.LENGTH_SHORT).show()

                // ── Role-based routing ─────────────────────────────────
                if (user.role == "TEACHER") {
                    // Teachers go directly to the full HomeActivity
                    startActivity(Intent(this, HomeActivity::class.java))
                } else {
                    // Students: if they have no enrolled class, send them to
                    // Join Class first so they have something to see.
                    val destination = if (DataManager.hasAnyEnrolledClass(this)) {
                        HomeActivity::class.java
                    } else {
                        JoinClass::class.java
                    }
                    val intent = Intent(this, destination).apply {
                        if (destination == JoinClass::class.java) {
                            // Let JoinClass know this is a first-time flow
                            putExtra("FIRST_TIME", true)
                        }
                    }
                    startActivity(intent)
                }
                // ──────────────────────────────────────────────────────
                finish()
            } else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show()
            }
        }

        tvSignUp.setOnClickListener {
            startActivity(Intent(this, SignUp::class.java))
        }

        imgBack.setOnClickListener { finish() }

        imgEye.setOnClickListener {
            if (isPasswordVisible) {
                etPasswordMain.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off)
            } else {
                etPasswordMain.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_on)
            }
            etPasswordMain.setSelection(etPasswordMain.text.length)
            isPasswordVisible = !isPasswordVisible
        }

        tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Redirecting to help center...", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, HelpCenterForgotPassword::class.java))
        }
    }
}
