package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Announcements : AppCompatActivity() {

    private var selectedFilter = "All"
    private var classId = ""

    private lateinit var chipAll: TextView
    private lateinit var chipImportant: TextView
    private lateinit var chipUpdate: TextView
    private lateinit var chipDeadline: TextView
    private lateinit var announcementContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcements)

        classId = intent.getStringExtra("class_id") ?: ""

        DataManager.restoreSessionIfNeeded(this)
        val isTeacher = DataManager.isTeacher(this)

        val btnAdd             = findViewById<ImageView>(R.id.btnAdd)
        val btnBack            = findViewById<ImageView>(R.id.btnBack)
        val etSearch           = findViewById<EditText>(R.id.etSearch)
        val btnCalendar        = findViewById<ImageView>(R.id.btnCalendar)
        val btnAddAnnouncement = findViewById<LinearLayout>(R.id.btnAddAnnouncement)

        chipAll       = findViewById(R.id.chipAll)
        chipImportant = findViewById(R.id.chipImportant)
        chipUpdate    = findViewById(R.id.chipUpdate)
        chipDeadline  = findViewById(R.id.chipDeadline)
        announcementContainer = findViewById(R.id.announcementContainer)

        // ── Role-based: only teachers can post announcements ──────────
        if (isTeacher) {
            btnAdd.visibility             = View.VISIBLE
            btnAddAnnouncement.visibility = View.VISIBLE

            btnAdd.setOnClickListener {
                startActivity(Intent(this, AnnouncementActivity::class.java).apply {
                    putExtra("class_id", classId)
                })
            }
            btnAddAnnouncement.setOnClickListener {
                startActivity(Intent(this, AnnouncementActivity::class.java).apply {
                    putExtra("class_id", classId)
                })
            }
        } else {
            // Students: hide post buttons entirely
            btnAdd.visibility             = View.GONE
            btnAddAnnouncement.visibility = View.GONE
        }
        // ─────────────────────────────────────────────────────────────

        btnBack.setOnClickListener { finish() }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        chipAll.setOnClickListener       { selectedFilter = "All";       updateChipUI(); displayAnnouncements() }
        chipImportant.setOnClickListener { selectedFilter = "Important"; updateChipUI(); displayAnnouncements() }
        chipUpdate.setOnClickListener    { selectedFilter = "Update";    updateChipUI(); displayAnnouncements() }
        chipDeadline.setOnClickListener  { selectedFilter = "Deadline";  updateChipUI(); displayAnnouncements() }

        etSearch.setOnEditorActionListener { _, _, _ ->
            val searchText = etSearch.text.toString().trim()
            if (searchText.isEmpty()) displayAnnouncements() else filterAnnouncementsBySearch(searchText)
            true
        }

        displayAnnouncements()
    }

    override fun onResume() {
        super.onResume()
        displayAnnouncements()
    }

    private fun displayAnnouncements() {
        announcementContainer.removeAllViews()

        val announcements = if (classId.isEmpty()) {
            DataManager.getAllAnnouncements()
        } else {
            DataManager.getAnnouncementsByClass(classId)
        }

        val filtered = if (selectedFilter == "All") announcements
                       else announcements.filter { it.category == selectedFilter }

        if (filtered.isEmpty()) {
            announcementContainer.addView(TextView(this).apply {
                text = "No announcements yet"
                textSize = 16f
                setPadding(16, 16, 16, 16)
            })
        } else {
            filtered.forEach { announcementContainer.addView(createAnnouncementView(it)) }
        }
    }

    private fun filterAnnouncementsBySearch(searchText: String) {
        announcementContainer.removeAllViews()

        val announcements = if (classId.isEmpty()) {
            DataManager.getAllAnnouncements()
        } else {
            DataManager.getAnnouncementsByClass(classId)
        }

        val filtered = announcements.filter {
            it.title.contains(searchText, ignoreCase = true) ||
            it.description.contains(searchText, ignoreCase = true)
        }

        if (filtered.isEmpty()) {
            announcementContainer.addView(TextView(this).apply {
                text = "No announcements found"
                textSize = 16f
                setPadding(16, 16, 16, 16)
            })
        } else {
            filtered.forEach { announcementContainer.addView(createAnnouncementView(it)) }
        }
    }

    private fun createAnnouncementView(announcement: AnnouncementData): LinearLayout {
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 16, 16, 16)
            setBackgroundColor(resources.getColor(android.R.color.white, null))
        }

        view.addView(TextView(this).apply {
            text = announcement.category
            textSize = 12f
            setPadding(8, 4, 8, 4)
            setBackgroundColor(getCategoryColor(announcement.category))
            setTextColor(resources.getColor(android.R.color.white, null))
        })

        view.addView(TextView(this).apply {
            text = announcement.title
            textSize = 18f
            setPadding(0, 8, 0, 4)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })

        view.addView(TextView(this).apply {
            text = announcement.description
            textSize = 14f
            setPadding(0, 4, 0, 8)
        })

        view.addView(TextView(this).apply {
            text = "Posted: ${announcement.postDate}"
            textSize = 12f
            setPadding(0, 4, 0, 0)
            setTextColor(resources.getColor(android.R.color.darker_gray, null))
        })

        view.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 2)
            setBackgroundColor(resources.getColor(android.R.color.darker_gray, null))
        })

        return view
    }

    private fun getCategoryColor(category: String): Int = when (category) {
        "Important" -> resources.getColor(android.R.color.holo_red_light, null)
        "Update"    -> resources.getColor(android.R.color.holo_blue_light, null)
        "Deadline"  -> resources.getColor(android.R.color.holo_orange_light, null)
        else        -> resources.getColor(android.R.color.darker_gray, null)
    }

    private fun updateChipUI() {
        listOf(chipAll, chipImportant, chipUpdate, chipDeadline).forEach {
            it.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        }
        when (selectedFilter) {
            "All"       -> chipAll.setBackgroundColor(resources.getColor(android.R.color.darker_gray, null))
            "Important" -> chipImportant.setBackgroundColor(resources.getColor(android.R.color.holo_red_light, null))
            "Update"    -> chipUpdate.setBackgroundColor(resources.getColor(android.R.color.holo_blue_light, null))
            "Deadline"  -> chipDeadline.setBackgroundColor(resources.getColor(android.R.color.holo_orange_light, null))
        }
    }
}
