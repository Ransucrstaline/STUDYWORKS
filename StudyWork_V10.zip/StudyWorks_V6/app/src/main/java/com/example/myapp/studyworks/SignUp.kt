package com.example.myapp.studyworks

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.studyworks.R

class SignUp : AppCompatActivity() {

    private var isPasswordVisible = false
    private var selectedRole = "TEACHER"   // default selection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val imgBack      = findViewById<ImageView>(R.id.btnBack)
        val imgEye       = findViewById<ImageView>(R.id.imgEye)
        val etFirstName  = findViewById<EditText>(R.id.etFirstName)
        val etLastName   = findViewById<EditText>(R.id.etLastName)
        val etUsername   = findViewById<EditText>(R.id.etUsername)
        val etPassword   = findViewById<EditText>(R.id.etPassword)
        val btnSignUp    = findViewById<Button>(R.id.btnSignUp)
        val tvLogin      = findViewById<TextView>(R.id.tvLogin)
        val btnTeacher   = findViewById<TextView>(R.id.btnRoleTeacher)
        val btnStudent   = findViewById<TextView>(R.id.btnRoleStudent)

        // ── Role toggle logic ──────────────────────────────────────────
        fun selectRole(role: String) {
            selectedRole = role
            if (role == "TEACHER") {
                // Teacher pill: filled
                btnTeacher.setBackgroundResource(R.drawable.bg_signup_button)
                btnTeacher.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                btnTeacher.setTypeface(null, Typeface.BOLD)
                // Student pill: ghost
                btnStudent.setBackgroundResource(android.R.color.transparent)
                btnStudent.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
                btnStudent.setTypeface(null, Typeface.NORMAL)
            } else {
                // Student pill: filled
                btnStudent.setBackgroundResource(R.drawable.bg_signup_button)
                btnStudent.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                btnStudent.setTypeface(null, Typeface.BOLD)
                // Teacher pill: ghost
                btnTeacher.setBackgroundResource(android.R.color.transparent)
                btnTeacher.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
                btnTeacher.setTypeface(null, Typeface.NORMAL)
            }
        }

        // Start with Teacher selected
        selectRole("TEACHER")

        btnTeacher.setOnClickListener { selectRole("TEACHER") }
        btnStudent.setOnClickListener { selectRole("STUDENT") }
        // ──────────────────────────────────────────────────────────────

        imgBack.setOnClickListener { finish() }

        tvLogin.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }

        imgEye.setOnClickListener {
            if (isPasswordVisible) {
                etPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_off)
            } else {
                etPassword.inputType =
                    InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                imgEye.setImageResource(R.drawable.ic_eye_on)
            }
            etPassword.setSelection(etPassword.text.length)
            isPasswordVisible = !isPasswordVisible
        }

        btnSignUp.setOnClickListener {
            val firstName = etFirstName.text.toString().trim()
            val lastName  = etLastName.text.toString().trim()
            val username  = etUsername.text.toString().trim()
            val password  = etPassword.text.toString().trim()

            if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newUser = UserData(
                firstName    = firstName,
                lastName     = lastName,
                username     = username,
                passwordHash = password,   // hash in production!
                role         = selectedRole
            )

            if (DataManager.registerUser(this, newUser)) {
                val roleLabel = if (selectedRole == "TEACHER") "Teacher" else "Student"
                Toast.makeText(
                    this,
                    "Registration successful as $roleLabel!",
                    Toast.LENGTH_SHORT
                ).show()
                startActivity(Intent(this, Login::class.java))
                finish()
            } else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
