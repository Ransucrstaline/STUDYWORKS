package com.example.myapp.studyworks

import android.content.Context
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ============== DATA MODELS ==============

@Parcelize
data class UserData(
    val firstName: String = "",
    val lastName: String = "",
    val username: String = "",
    val passwordHash: String = "",
    val role: String = "STUDENT"   // "TEACHER" or "STUDENT"
) : Parcelable

@Parcelize
data class ClassData(
    val id: String = "",
    val className: String = "",
    val section: String = "",
    val schedule: String = "",
    val roomNumber: String = "",
    val academicLevel: String = "",
    val classCode: String = "",
    val coverImagePath: String = ""
) : Parcelable

@Parcelize
data class MaterialData(
    val id: String = "",
    val classId: String = "",
    val title: String = "",
    val description: String = "",
    val fileName: String = "",
    val uploadDate: String = ""
) : Parcelable

@Parcelize
data class AnnouncementData(
    val id: String = "",
    val classId: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val postDate: String = ""
) : Parcelable

@Parcelize
data class AttendanceData(
    val id: String = "",
    val classId: String = "",
    val studentName: String = "",
    val date: String = "",
    val status: String = ""
) : Parcelable

@Parcelize
data class StudentEnrollment(
    val studentName: String = "",
    val classId: String = "",
    val section: String = ""
) : Parcelable

@Parcelize
data class TodoData(
    val id: String = "",
    val title: String = "",
    val dueDate: String = "",
    val type: String = ""
) : Parcelable

@Parcelize
data class NotificationData(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val time: String = "",
    val type: String = ""
) : Parcelable

// ============== DATA MANAGER SINGLETON ==============

object DataManager {
    private var currentUser: UserData? = null

    private val materials = mutableListOf<MaterialData>()
    private val announcements = mutableListOf<AnnouncementData>()
    private val attendance = mutableListOf<AttendanceData>()
    private val todos = mutableListOf<TodoData>()

    private var materialIdCounter = 1
    private var announcementIdCounter = 1
    private var attendanceIdCounter = 1
    private var todoIdCounter = 1

    // ============== ROLE HELPERS ==============

    /**
     * Returns true if the current user is a TEACHER.
     * Falls back to SharedPreferences so role survives process death.
     * Call restoreSessionIfNeeded(context) at Activity start if currentUser may be null.
     */
    fun isTeacher(context: android.content.Context? = null): Boolean {
        val role = currentUser?.role
            ?: context?.let { getRoleFromPrefs(it) }
            ?: return false
        return role == "TEACHER"
    }

    fun isStudent(context: android.content.Context? = null): Boolean {
        val role = currentUser?.role
            ?: context?.let { getRoleFromPrefs(it) }
            ?: return false
        return role == "STUDENT"
    }

    /**
     * Restores currentUser from SharedPreferences + DB after process death.
     * Safe to call multiple times; no-op if currentUser is already set.
     */
    fun restoreSessionIfNeeded(context: android.content.Context) {
        if (currentUser != null) return
        val prefs = context.getSharedPreferences("UserPrefs", android.content.Context.MODE_PRIVATE)
        val savedUsername = prefs.getString("LastUsername", null) ?: return
        val savedRole     = prefs.getString("UserRole", null) ?: return
        // Re-hydrate a minimal UserData so role checks work without full DB lookup
        currentUser = UserData(username = savedUsername, role = savedRole)
    }

    fun saveRoleToPrefs(context: Context, role: String) {
        context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            .edit().putString("UserRole", role).apply()
    }

    fun getRoleFromPrefs(context: Context): String {
        return context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            .getString("UserRole", "STUDENT") ?: "STUDENT"
    }

    // ============== USER OPERATIONS ==============

    fun registerUser(context: Context, user: UserData): Boolean {
        val db = DatabaseHelper(context)
        return db.addUser(user)
    }

    fun loginUser(context: Context, username: String, passwordHash: String): UserData? {
        val db = DatabaseHelper(context)
        val user = db.checkUser(username, passwordHash)
        currentUser = user
        if (user != null) saveRoleToPrefs(context, user.role)
        return user
    }

    fun getCurrentUser(): UserData? = currentUser

    fun setCurrentUser(user: UserData?) {
        currentUser = user
    }

    // ============== CLASS OPERATIONS ==============

    fun addClass(context: Context, classData: ClassData) {
        val db = DatabaseHelper(context)
        val finalClass = if (classData.id.isEmpty()) {
            classData.copy(id = "class_${System.currentTimeMillis()}")
        } else classData
        db.addClass(finalClass)
    }

    fun getClasses(context: Context): List<ClassData> {
        val db = DatabaseHelper(context)
        return db.getAllClasses()
    }

    /**
     * For students: returns only the classes they are enrolled in.
     * For teachers: returns all classes (same as getClasses).
     */
    fun getClassesForCurrentUser(context: Context): List<ClassData> {
        return if (isTeacher()) {
            getClasses(context)
        } else {
            val user = currentUser ?: return emptyList()
            getEnrolledClasses(context, user.username)
        }
    }

    fun getClassById(context: Context, classId: String): ClassData? {
        return getClasses(context).find { it.id == classId }
    }

    fun getClassByCode(context: Context, code: String): ClassData? {
        return getClasses(context).find { it.classCode == code }
    }

    fun updateClass(context: Context, classData: ClassData) {
        val db = DatabaseHelper(context)
        db.updateClass(classData)
    }

    fun deleteClass(context: Context, classId: String) {
        val db = DatabaseHelper(context)
        db.deleteClass(classId)
    }

    // ============== ENROLLMENT OPERATIONS ==============

    fun enrollStudent(context: Context, enrollment: StudentEnrollment) {
        val db = DatabaseHelper(context)
        if (!db.isEnrolled(enrollment.studentName, enrollment.classId)) {
            db.addEnrollment(enrollment)
        }
    }

    fun isStudentEnrolled(context: Context, studentName: String, classId: String): Boolean {
        val db = DatabaseHelper(context)
        return db.isEnrolled(studentName, classId)
    }

    fun getStudentsByClass(context: Context, classId: String): List<StudentEnrollment> {
        val db = DatabaseHelper(context)
        return db.getEnrollmentsByClass(classId)
    }

    fun getEnrolledClasses(context: Context, studentName: String): List<ClassData> {
        val db = DatabaseHelper(context)
        val enrollments = db.getEnrollmentsByStudent(studentName)
        return enrollments.mapNotNull { getClassById(context, it.classId) }
    }

    fun hasAnyEnrolledClass(context: Context): Boolean {
        val user = currentUser ?: return false
        return getEnrolledClasses(context, user.username).isNotEmpty()
    }

    // ============== MATERIAL OPERATIONS ==============

    fun addMaterial(materialData: MaterialData) {
        val newMaterial = materialData.copy(id = "material_${materialIdCounter++}")
        materials.add(newMaterial)
    }

    fun getMaterialsByClass(classId: String): List<MaterialData> =
        materials.filter { it.classId == classId }

    // ============== ANNOUNCEMENT OPERATIONS ==============

    fun addAnnouncement(announcementData: AnnouncementData) {
        val newAnnouncement = announcementData.copy(id = "announcement_${announcementIdCounter++}")
        announcements.add(newAnnouncement)
    }

    fun getAnnouncementsByClass(classId: String): List<AnnouncementData> =
        announcements.filter { it.classId == classId || it.classId == "all" }

    fun getAllAnnouncements(): List<AnnouncementData> = announcements.toList()

    // ============== TODO OPERATIONS ==============

    fun getTodos(): List<TodoData> = todos.toList()

    fun addTodo(todo: TodoData) {
        val newTodo = if (todo.id.isEmpty()) {
            todo.copy(id = "todo_${todoIdCounter++}")
        } else todo
        todos.add(newTodo)
    }

    // ============== NOTIFICATION OPERATIONS ==============

    fun getNotifications(context: Context): List<NotificationData> {
        val list = mutableListOf<NotificationData>()

        getClassesForCurrentUser(context).forEach {
            list.add(NotificationData(
                id = "notif_class_${it.id}",
                title = "Upcoming Class: ${it.className}",
                description = "Section: ${it.section} | Room: ${it.roomNumber}",
                time = it.schedule,
                type = "Class"
            ))
        }

        todos.forEach {
            list.add(NotificationData(
                id = "notif_todo_${it.id}",
                title = "Pending ${it.type}: ${it.title}",
                description = "Deadline is approaching. Please complete it soon.",
                time = it.dueDate,
                type = it.type
            ))
        }

        return list.reversed()
    }

    // ============== ATTENDANCE OPERATIONS ==============

    fun addAttendance(attendanceData: AttendanceData) {
        val newAttendance = attendanceData.copy(id = "attendance_${attendanceIdCounter++}")
        attendance.add(newAttendance)
    }

    fun getAttendanceByClass(classId: String): List<AttendanceData> =
        attendance.filter { it.classId == classId }

    // ============== UTILITY FUNCTIONS ==============

    fun clearAllData() {
        materials.clear()
        announcements.clear()
        attendance.clear()
        todos.clear()
        currentUser = null
    }

    fun generateUniqueClassCode(context: Context): String {
        val existingCodes = getClasses(context).map { it.classCode }
        var newCode: String
        do {
            newCode = (1000..9999).random().toString()
        } while (existingCodes.contains(newCode))
        return newCode
    }

    @Deprecated("Use generateUniqueClassCode(context) instead", ReplaceWith("generateUniqueClassCode(context)"))
    fun generateClassCode(): String {
        return (1000..9999).random().toString()
    }
}
