package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class AddClassOrJoinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_class_or_join)

        val btnAdd        = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu       = findViewById<ImageView>(R.id.btnMenu)
        val btnCreateClass = findViewById<LinearLayout>(R.id.btnCreateClass)
        val btnJoinClass  = findViewById<LinearLayout>(R.id.btnJoinClass)
        val btnClose      = findViewById<ImageView>(R.id.btnClose)
        val navHome         = findViewById<LinearLayout>(R.id.navHome)
        val navClasses      = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        DataManager.restoreSessionIfNeeded(this)
        val isTeacher = DataManager.isTeacher(this)

        // ── Role-based visibility ─────────────────────────────────────
        // Teachers: can Create or Join a class
        // Students: can only Join a class
        if (isTeacher) {
            btnCreateClass.visibility = View.VISIBLE
        } else {
            btnCreateClass.visibility = View.GONE
        }

        btnCreateClass.setOnClickListener {
            // Extra guard — only teachers should reach this
            if (isTeacher) {
                startActivity(Intent(this, CreateClassActivity::class.java))
            }
        }

        btnJoinClass.setOnClickListener {
            startActivity(Intent(this, JoinClass::class.java))
        }

        btnClose.setOnClickListener { finish() }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java)); finish()
        }
        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java)); finish()
        }
        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java)); finish()
        }
    }
}
