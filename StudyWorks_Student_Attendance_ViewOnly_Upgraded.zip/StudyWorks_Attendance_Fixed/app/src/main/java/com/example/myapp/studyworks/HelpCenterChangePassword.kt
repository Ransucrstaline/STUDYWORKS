package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenterChangePassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center_change_password)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchHelp = findViewById<EditText>(R.id.etSearchHelp)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)
        val chipAccount = findViewById<TextView>(R.id.chipAccount)
        val chipClasses = findViewById<TextView>(R.id.chipClasses)
        val chipAppSettings = findViewById<TextView>(R.id.chipAppSettings)
        val tvSteps = findViewById<TextView>(R.id.tvSteps)

        btnBack.setOnClickListener { finish() }
        btnAdd.setOnClickListener { startActivity(Intent(this, Add::class.java)) }
        btnMenu.setOnClickListener { startActivity(Intent(this, Profile::class.java)) }
        tabFaq.setOnClickListener { startActivity(Intent(this, HelpCenter::class.java)) }
        tabContactUs.setOnClickListener { startActivity(Intent(this, HelpCenterContact::class.java)) }
        chipAccount.setOnClickListener { startActivity(Intent(this, HelpCenter::class.java)) }
        chipClasses.setOnClickListener { Toast.makeText(this, "Class help is available from Class Details", Toast.LENGTH_SHORT).show() }
        chipAppSettings.setOnClickListener { Toast.makeText(this, "App settings help is available from Profile and More", Toast.LENGTH_SHORT).show() }
        imgSearch?.setOnClickListener { searchHelp(etSearchHelp.text.toString()) }
        etSearchHelp.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                searchHelp(etSearchHelp.text.toString())
                true
            } else false
        }
        tvSteps.setOnClickListener { Toast.makeText(this, "How to change password details shown", Toast.LENGTH_SHORT).show() }
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)
    }

    private fun searchHelp(queryText: String) {
        val query = queryText.trim().lowercase()
        when {
            query.isEmpty() -> Toast.makeText(this, "Type a help topic first", Toast.LENGTH_SHORT).show()
            "account" in query || "create" in query || "sign" in query -> startActivity(Intent(this, HelpCenterExpanded::class.java))
            "login" in query -> startActivity(Intent(this, HelpCenterLogin::class.java))
            "forgot" in query || "reset" in query -> startActivity(Intent(this, HelpCenterForgotPassword::class.java))
            "change" in query || "password" in query -> startActivity(Intent(this, HelpCenterChangePassword::class.java))
            "contact" in query || "support" in query || "email" in query -> startActivity(Intent(this, HelpCenterContact::class.java))
            else -> Toast.makeText(this, "No exact result found. Please choose a FAQ topic.", Toast.LENGTH_SHORT).show()
        }
    }
}
