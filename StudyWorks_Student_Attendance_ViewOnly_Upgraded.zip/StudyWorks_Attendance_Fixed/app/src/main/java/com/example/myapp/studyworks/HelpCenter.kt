package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenter : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchHelp = findViewById<EditText>(R.id.etSearchHelp)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)

        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)

        val chipAccount = findViewById<TextView>(R.id.chipAccount)
        val chipClasses = findViewById<TextView>(R.id.chipClasses)
        val chipAppSettings = findViewById<TextView>(R.id.chipAppSettings)

        val itemFaq1 = findViewById<LinearLayout>(R.id.itemFaq1)
        val itemFaq2 = findViewById<LinearLayout>(R.id.itemFaq2)
        val itemFaq3 = findViewById<LinearLayout>(R.id.itemFaq3)
        val itemFaq4 = findViewById<LinearLayout>(R.id.itemFaq4)

        btnBack.setOnClickListener { finish() }
        btnAdd.setOnClickListener { startActivity(Intent(this, Add::class.java)) }
        btnMenu.setOnClickListener { startActivity(Intent(this, Profile::class.java)) }

        itemFaq1.setOnClickListener { openHelp(HelpCenterExpanded::class.java) }
        itemFaq2.setOnClickListener { openHelp(HelpCenterLogin::class.java) }
        itemFaq3.setOnClickListener { openHelp(HelpCenterForgotPassword::class.java) }
        itemFaq4.setOnClickListener { openHelp(HelpCenterChangePassword::class.java) }

        tabFaq.setOnClickListener { Toast.makeText(this, "You are already viewing FAQs", Toast.LENGTH_SHORT).show() }
        tabContactUs.setOnClickListener { openHelp(HelpCenterContact::class.java) }

        chipAccount.setOnClickListener { Toast.makeText(this, "Account FAQs shown", Toast.LENGTH_SHORT).show() }
        chipClasses.setOnClickListener { Toast.makeText(this, "Class help is available in your class screens", Toast.LENGTH_SHORT).show() }
        chipAppSettings.setOnClickListener { Toast.makeText(this, "App settings help is available from Profile and More", Toast.LENGTH_SHORT).show() }

        imgSearch.setOnClickListener { searchHelp(etSearchHelp.text.toString()) }
        etSearchHelp.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                searchHelp(etSearchHelp.text.toString())
                true
            } else {
                false
            }
        }

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)
    }

    private fun openHelp(screen: Class<*>) {
        startActivity(Intent(this, screen))
    }

    private fun searchHelp(queryText: String) {
        val query = queryText.trim().lowercase()
        when {
            query.isEmpty() -> Toast.makeText(this, "Type a help topic first", Toast.LENGTH_SHORT).show()
            "account" in query || "create" in query || "sign" in query -> openHelp(HelpCenterExpanded::class.java)
            "login" in query -> openHelp(HelpCenterLogin::class.java)
            "forgot" in query || "reset" in query -> openHelp(HelpCenterForgotPassword::class.java)
            "change" in query || "password" in query -> openHelp(HelpCenterChangePassword::class.java)
            "contact" in query || "support" in query || "email" in query -> openHelp(HelpCenterContact::class.java)
            else -> Toast.makeText(this, "No exact result found. Please choose a FAQ below.", Toast.LENGTH_SHORT).show()
        }
    }
}
