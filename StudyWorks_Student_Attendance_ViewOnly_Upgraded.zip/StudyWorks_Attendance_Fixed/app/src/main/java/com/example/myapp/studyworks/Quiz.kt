package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Quiz : AppCompatActivity() {

    private var currentClassId: String = ""
    private lateinit var tvQuizTitle: TextView
    private lateinit var tvClassName: TextView
    private lateinit var tvDescription: TextView
    private lateinit var tvDueDate: TextView
    private lateinit var tvPoints: TextView
    
    // Quiz type buttons
    private lateinit var btnIdentification: LinearLayout
    private lateinit var btnMultipleChoice: LinearLayout
    private lateinit var btnTrueFalse: LinearLayout
    private lateinit var tvIdentification: TextView
    private lateinit var tvMultipleChoice: TextView
    private lateinit var tvTrueFalse: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        currentClassId = intent.getStringExtra("class_id") ?: ""

        // ===== HEADER BUTTONS =====
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        // ===== EXTRA BUTTONS =====
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== QUIZ INFO =====
        tvQuizTitle = findViewById(R.id.tvQuizTitle)
        tvClassName = findViewById(R.id.tvClassName)
        tvDescription = findViewById(R.id.tvDescription)
        tvDueDate = findViewById(R.id.tvDueDate)
        tvPoints = findViewById(R.id.tvPoints)

        // ===== QUIZ TYPE BUTTONS =====
        btnIdentification = findViewById(R.id.btnIdentification)
        btnMultipleChoice = findViewById(R.id.btnMultipleChoice)
        btnTrueFalse = findViewById(R.id.btnTrueFalse)
        
        // Get text views with proper IDs
        tvIdentification = findViewById(R.id.tvIdentification)
        tvMultipleChoice = findViewById(R.id.tvMultipleChoice)
        tvTrueFalse = findViewById(R.id.tvTrueFalse)


        // ===== HEADER ACTIONS =====
        btnBack.setOnClickListener {
            finish()
        }

        btnAdd.setOnClickListener {
            // Teachers can add a new quiz
            if (DataManager.isTeacher()) {
                val intent = Intent(this, CreateQuiz::class.java)
                intent.putExtra("class_id", currentClassId)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Only teachers can create quizzes", Toast.LENGTH_SHORT).show()
            }
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        // ===== QUIZ TYPE BUTTONS - Start quiz filtered by type =====
        btnIdentification.setOnClickListener {
            startQuizByType("identification")
        }

        btnMultipleChoice.setOnClickListener {
            startQuizByType("multiple_choice")
        }

        btnTrueFalse.setOnClickListener {
            startQuizByType("true_false")
        }

        // Load quizzes
        loadQuizzes()
    }

    override fun onResume() {
        super.onResume()
        loadQuizzes()
    }

    private fun loadQuizzes() {
        val quizzes = if (currentClassId.isNotEmpty()) {
            DataManager.getQuizzesByClass(currentClassId)
        } else {
            DataManager.getAllQuizzes()
        }

        // Count quizzes by type based on their questions
        var multipleChoiceCount = 0
        var trueFalseCount = 0
        var identificationCount = 0

        quizzes.forEach { quiz ->
            val questions = DataManager.getQuestionsByQuiz(quiz.id)
            questions.forEach { question ->
                when (question.questionType) {
                    "multiple_choice" -> multipleChoiceCount++
                    "true_false" -> trueFalseCount++
                    "identification" -> identificationCount++
                }
            }
        }

        // Update button labels with counts
        tvMultipleChoice.text = "Multiple Choice ($multipleChoiceCount)"
        tvTrueFalse.text = "True or False ($trueFalseCount)"
        tvIdentification.text = "Identification ($identificationCount)"

        if (quizzes.isNotEmpty()) {
            // Display the latest quiz info in the main card
            val latestQuiz = quizzes.last()
            tvQuizTitle.text = latestQuiz.title
            
            val className = if (currentClassId.isNotEmpty()) {
                DataManager.getClassById(this, currentClassId)?.className ?: "Class"
            } else {
                DataManager.getClassById(this, latestQuiz.classId)?.className ?: "Class"
            }
            tvClassName.text = className
            
            // Get question count for description
            val questionCount = DataManager.getQuestionsByQuiz(latestQuiz.id).size
            tvDescription.text = if (latestQuiz.description.isNotEmpty()) {
                "${latestQuiz.description}\n\nThis quiz has $questionCount question(s). Select a quiz type below to start!"
            } else {
                "This quiz has $questionCount question(s). Select a quiz type below to start!"
            }
            
            tvDueDate.text = if (latestQuiz.dueDate.isNotEmpty()) {
                "Due: ${latestQuiz.dueDate}"
            } else {
                "Created: ${latestQuiz.createdDate}"
            }
            
            tvPoints.text = "${latestQuiz.points} points"

            // Check if current user already took the quiz
            val currentUser = DataManager.getCurrentUser()
            if (currentUser != null && DataManager.isStudent()) {
                val result = DataManager.getStudentQuizResult(latestQuiz.id, currentUser.username)
                if (result != null) {
                    val percentage = (result.score * 100) / result.totalQuestions
                    tvDescription.text = "You scored ${result.score}/${result.totalQuestions} (${percentage}%) on this quiz!\nTaken on: ${result.dateTaken}"
                }
            }
        } else {
            // No quizzes available
            tvQuizTitle.text = "No Quizzes Yet"
            tvClassName.text = if (currentClassId.isNotEmpty()) {
                DataManager.getClassById(this, currentClassId)?.className ?: "This Class"
            } else {
                "Any Class"
            }
            tvDescription.text = if (DataManager.isTeacher()) {
                "Create your first quiz by tapping the + button above!"
            } else {
                "No quizzes available yet. Check back later!"
            }
            tvDueDate.text = ""
            tvPoints.text = ""
        }
    }

    private fun startQuizByType(filterType: String) {
        val quizzes = if (currentClassId.isNotEmpty()) {
            DataManager.getQuizzesByClass(currentClassId)
        } else {
            DataManager.getAllQuizzes()
        }

        if (quizzes.isEmpty()) {
            Toast.makeText(this, "No quizzes available yet", Toast.LENGTH_SHORT).show()
            return
        }

        // Find a quiz that has questions of the selected type
        var targetQuiz: QuizData? = null
        for (quiz in quizzes.reversed()) {
            val questions = DataManager.getQuestionsByQuiz(quiz.id)
            val hasMatchingType = questions.any { it.questionType == filterType }
            if (hasMatchingType) {
                targetQuiz = quiz
                break
            }
        }

        if (targetQuiz == null) {
            val typeName = when (filterType) {
                "multiple_choice" -> "Multiple Choice"
                "true_false" -> "True or False"
                "identification" -> "Identification"
                else -> filterType
            }
            Toast.makeText(this, "No $typeName questions available", Toast.LENGTH_SHORT).show()
            return
        }

        val currentUser = DataManager.getCurrentUser()

        // Check if student has already taken this quiz
        if (DataManager.isStudent() && currentUser != null) {
            if (DataManager.hasStudentTakenQuiz(targetQuiz.id, currentUser.username)) {
                val result = DataManager.getStudentQuizResult(targetQuiz.id, currentUser.username)
                Toast.makeText(
                    this,
                    "You already completed this quiz! Score: ${result?.score}/${result?.totalQuestions}",
                    Toast.LENGTH_LONG
                ).show()
                return
            }
        }

        // Get questions for this quiz
        val questions = DataManager.getQuestionsByQuiz(targetQuiz.id)
        if (questions.isEmpty()) {
            Toast.makeText(this, "This quiz has no questions yet", Toast.LENGTH_SHORT).show()
            return
        }

        // Start TakeQuiz activity
        val intent = Intent(this, TakeQuiz::class.java)
        intent.putExtra("quiz_id", targetQuiz.id)
        intent.putExtra("class_id", currentClassId)
        intent.putExtra("filter_type", filterType)
        startActivity(intent)
    }
}
