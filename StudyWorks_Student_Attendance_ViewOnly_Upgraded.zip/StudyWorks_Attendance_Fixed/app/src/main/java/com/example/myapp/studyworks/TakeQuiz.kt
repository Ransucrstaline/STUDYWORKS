package com.example.myapp.studyworks

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TakeQuiz : AppCompatActivity() {

    private var quizId: String = ""
    private var currentQuestionIndex: Int = 0
    private var score: Int = 0
    private var questions: List<QuizQuestionData> = emptyList()
    
    // Store answers for different question types
    private var selectedAnswers: MutableMap<Int, Int> = mutableMapOf()  // For multiple choice & true/false
    private var textAnswers: MutableMap<Int, String> = mutableMapOf()   // For identification

    // Views
    private lateinit var tvQuizTitle: TextView
    private lateinit var tvQuestionNumber: TextView
    private lateinit var tvQuestion: TextView
    private lateinit var tvQuestionType: TextView
    private lateinit var tvProgress: TextView
    
    // Multiple Choice views
    private lateinit var multipleChoiceAnswers: LinearLayout
    private lateinit var radioGroup: RadioGroup
    private lateinit var radioOption1: RadioButton
    private lateinit var radioOption2: RadioButton
    private lateinit var radioOption3: RadioButton
    private lateinit var radioOption4: RadioButton
    
    // True/False views
    private lateinit var trueFalseAnswers: LinearLayout
    private lateinit var btnAnswerTrue: Button
    private lateinit var btnAnswerFalse: Button
    
    // Identification views
    private lateinit var identificationAnswers: LinearLayout
    private lateinit var etIdentificationAnswer: EditText
    
    // Navigation
    private lateinit var btnPrevious: Button
    private lateinit var btnNext: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_take_quiz)

        quizId = intent.getStringExtra("quiz_id") ?: ""

        // Initialize views
        tvQuizTitle = findViewById(R.id.tvQuizTitle)
        tvQuestionNumber = findViewById(R.id.tvQuestionNumber)
        tvQuestion = findViewById(R.id.tvQuestion)
        tvQuestionType = findViewById(R.id.tvQuestionType)
        tvProgress = findViewById(R.id.tvProgress)
        
        // Multiple Choice
        multipleChoiceAnswers = findViewById(R.id.multipleChoiceAnswers)
        radioGroup = findViewById(R.id.radioGroup)
        radioOption1 = findViewById(R.id.radioOption1)
        radioOption2 = findViewById(R.id.radioOption2)
        radioOption3 = findViewById(R.id.radioOption3)
        radioOption4 = findViewById(R.id.radioOption4)
        
        // True/False
        trueFalseAnswers = findViewById(R.id.trueFalseAnswers)
        btnAnswerTrue = findViewById(R.id.btnAnswerTrue)
        btnAnswerFalse = findViewById(R.id.btnAnswerFalse)
        
        // Identification
        identificationAnswers = findViewById(R.id.identificationAnswers)
        etIdentificationAnswer = findViewById(R.id.etIdentificationAnswer)
        
        // Navigation
        btnPrevious = findViewById(R.id.btnPrevious)
        btnNext = findViewById(R.id.btnNext)

        val btnBack = findViewById<ImageView>(R.id.btnBack)

        btnBack.setOnClickListener {
            showExitConfirmation()
        }

        // Handle system back button
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                showExitConfirmation()
            }
        })

        // Load quiz data
        val quiz = DataManager.getQuizById(quizId)
        if (quiz == null) {
            Toast.makeText(this, "Quiz not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        tvQuizTitle.text = quiz.title
        questions = DataManager.getQuestionsByQuiz(quizId)

        if (questions.isEmpty()) {
            Toast.makeText(this, "This quiz has no questions", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Setup True/False button listeners
        btnAnswerTrue.setOnClickListener {
            selectedAnswers[currentQuestionIndex] = 1
            updateTrueFalseSelection()
        }

        btnAnswerFalse.setOnClickListener {
            selectedAnswers[currentQuestionIndex] = 2
            updateTrueFalseSelection()
        }

        // Setup navigation buttons
        btnPrevious.setOnClickListener {
            saveCurrentAnswer()
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--
                displayQuestion()
            }
        }

        btnNext.setOnClickListener {
            saveCurrentAnswer()
            if (currentQuestionIndex < questions.size - 1) {
                currentQuestionIndex++
                displayQuestion()
            } else {
                // Last question - submit quiz
                submitQuiz()
            }
        }

        // Display first question
        displayQuestion()
    }

    private fun displayQuestion() {
        val question = questions[currentQuestionIndex]

        tvQuestionNumber.text = "Question ${currentQuestionIndex + 1} of ${questions.size}"
        tvQuestion.text = question.question
        tvProgress.text = "${currentQuestionIndex + 1}/${questions.size}"

        // Hide all answer containers first
        multipleChoiceAnswers.visibility = View.GONE
        trueFalseAnswers.visibility = View.GONE
        identificationAnswers.visibility = View.GONE

        // Show appropriate answer container based on question type
        when (question.questionType) {
            "multiple_choice" -> {
                tvQuestionType.text = "Multiple Choice"
                multipleChoiceAnswers.visibility = View.VISIBLE
                
                radioOption1.text = "A. ${question.option1}"
                radioOption2.text = "B. ${question.option2}"
                radioOption3.text = "C. ${question.option3}"
                radioOption4.text = "D. ${question.option4}"

                // Clear selection
                radioGroup.clearCheck()

                // Restore previous answer if exists
                selectedAnswers[currentQuestionIndex]?.let { previousAnswer ->
                    when (previousAnswer) {
                        1 -> radioOption1.isChecked = true
                        2 -> radioOption2.isChecked = true
                        3 -> radioOption3.isChecked = true
                        4 -> radioOption4.isChecked = true
                    }
                }
            }
            "true_false" -> {
                tvQuestionType.text = "True or False"
                trueFalseAnswers.visibility = View.VISIBLE
                
                // Reset button styles
                updateTrueFalseSelection()
            }
            "identification" -> {
                tvQuestionType.text = "Identification"
                identificationAnswers.visibility = View.VISIBLE
                
                // Restore previous answer if exists
                etIdentificationAnswer.setText(textAnswers[currentQuestionIndex] ?: "")
            }
        }

        // Update button states
        btnPrevious.visibility = if (currentQuestionIndex == 0) View.INVISIBLE else View.VISIBLE
        btnNext.text = if (currentQuestionIndex == questions.size - 1) "Submit" else "Next"
    }

    private fun updateTrueFalseSelection() {
        val selectedAnswer = selectedAnswers[currentQuestionIndex]
        
        if (selectedAnswer == 1) {
            btnAnswerTrue.setBackgroundResource(R.drawable.bg_role_selected)
            btnAnswerTrue.setTextColor(0xFFFFFFFF.toInt())
            btnAnswerFalse.setBackgroundResource(R.drawable.bg_answer_button)
            btnAnswerFalse.setTextColor(0xFF333333.toInt())
        } else if (selectedAnswer == 2) {
            btnAnswerFalse.setBackgroundResource(R.drawable.bg_role_selected)
            btnAnswerFalse.setTextColor(0xFFFFFFFF.toInt())
            btnAnswerTrue.setBackgroundResource(R.drawable.bg_answer_button)
            btnAnswerTrue.setTextColor(0xFF333333.toInt())
        } else {
            // No selection yet
            btnAnswerTrue.setBackgroundResource(R.drawable.bg_answer_button)
            btnAnswerTrue.setTextColor(0xFF333333.toInt())
            btnAnswerFalse.setBackgroundResource(R.drawable.bg_answer_button)
            btnAnswerFalse.setTextColor(0xFF333333.toInt())
        }
    }

    private fun saveCurrentAnswer() {
        val question = questions[currentQuestionIndex]
        
        when (question.questionType) {
            "multiple_choice" -> {
                val selectedId = radioGroup.checkedRadioButtonId
                if (selectedId != -1) {
                    val selectedAnswer = when (selectedId) {
                        R.id.radioOption1 -> 1
                        R.id.radioOption2 -> 2
                        R.id.radioOption3 -> 3
                        R.id.radioOption4 -> 4
                        else -> 0
                    }
                    selectedAnswers[currentQuestionIndex] = selectedAnswer
                }
            }
            "true_false" -> {
                // Already saved via button clicks
            }
            "identification" -> {
                val answer = etIdentificationAnswer.text.toString().trim()
                if (answer.isNotEmpty()) {
                    textAnswers[currentQuestionIndex] = answer
                }
            }
        }
    }

    private fun submitQuiz() {
        // Make sure to save the last answer
        saveCurrentAnswer()

        // Count unanswered questions
        var unansweredCount = 0
        for (i in questions.indices) {
            val question = questions[i]
            when (question.questionType) {
                "multiple_choice", "true_false" -> {
                    if (!selectedAnswers.containsKey(i)) {
                        unansweredCount++
                    }
                }
                "identification" -> {
                    if (!textAnswers.containsKey(i) || textAnswers[i].isNullOrBlank()) {
                        unansweredCount++
                    }
                }
            }
        }

        // Check if all questions are answered
        if (unansweredCount > 0) {
            AlertDialog.Builder(this)
                .setTitle("Incomplete Quiz")
                .setMessage("You have $unansweredCount unanswered question(s). Do you want to submit anyway?")
                .setPositiveButton("Submit") { _, _ -> calculateAndSaveScore() }
                .setNegativeButton("Review") { dialog, _ -> dialog.dismiss() }
                .show()
        } else {
            calculateAndSaveScore()
        }
    }

    private fun calculateAndSaveScore() {
        score = 0
        val wrongAnswers = mutableListOf<String>()
        
        for (i in questions.indices) {
            val question = questions[i]
            var isCorrect = false
            
            when (question.questionType) {
                "multiple_choice" -> {
                    val userAnswer = selectedAnswers[i] ?: 0
                    isCorrect = userAnswer == question.correctAnswer
                    if (!isCorrect) {
                        val correctOption = when (question.correctAnswer) {
                            1 -> "A. ${question.option1}"
                            2 -> "B. ${question.option2}"
                            3 -> "C. ${question.option3}"
                            4 -> "D. ${question.option4}"
                            else -> ""
                        }
                        wrongAnswers.add("Q${i + 1}: Correct answer was $correctOption")
                    }
                }
                "true_false" -> {
                    val userAnswer = selectedAnswers[i] ?: 0
                    isCorrect = userAnswer == question.correctAnswer
                    if (!isCorrect) {
                        val correctAnswer = if (question.correctAnswer == 1) "True" else "False"
                        wrongAnswers.add("Q${i + 1}: Correct answer was $correctAnswer")
                    }
                }
                "identification" -> {
                    val userAnswer = textAnswers[i]?.trim()?.lowercase() ?: ""
                    val correctAnswer = question.correctAnswerText.trim().lowercase()
                    isCorrect = userAnswer == correctAnswer
                    if (!isCorrect) {
                        wrongAnswers.add("Q${i + 1}: Correct answer was \"${question.correctAnswerText}\"")
                    }
                }
            }
            
            if (isCorrect) {
                score++
            }
        }

        // Save result
        val currentUser = DataManager.getCurrentUser()
        val currentDate = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date())

        val result = QuizResultData(
            quizId = quizId,
            studentName = currentUser?.username ?: "Unknown",
            score = score,
            totalQuestions = questions.size,
            dateTaken = currentDate
        )
        DataManager.addQuizResult(result)

        // Show result
        val percentage = (score * 100) / questions.size
        val message = buildString {
            append(when {
                percentage >= 90 -> "Excellent! "
                percentage >= 70 -> "Good job! "
                percentage >= 50 -> "You passed! "
                else -> "Keep practicing! "
            })
            append("You scored $score out of ${questions.size} (${percentage}%)")
            
            if (wrongAnswers.isNotEmpty() && wrongAnswers.size <= 5) {
                append("\n\nReview these answers:")
                wrongAnswers.forEach { append("\n$it") }
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Quiz Complete!")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun showExitConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Exit Quiz?")
            .setMessage("Are you sure you want to exit? Your progress will be lost.")
            .setPositiveButton("Exit") { _, _ -> finish() }
            .setNegativeButton("Continue Quiz") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
