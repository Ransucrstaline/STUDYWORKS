package com.example.myapp.studyworks

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class HomeActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout
    private lateinit var todoContainer: LinearLayout
    private lateinit var announcementContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)
        todoContainer           = findViewById(R.id.todoContainer)
        announcementContainer   = findViewById(R.id.announcementContainer)

        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgMenu   = findViewById<ImageView>(R.id.imgMenu)
        val tvViewAll = findViewById<TextView>(R.id.tvViewAll)

        imgSearch.setOnClickListener {
            Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
        }

        imgMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        tvViewAll.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }

        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.HOME)

        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()

        // ── Show Join Class dialog for Students right after login ──────────
        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val shouldShow = sharedPref.getBoolean("ShowJoinClassOnOpen", false)
        if (shouldShow && DataManager.isStudent()) {
            sharedPref.edit().putBoolean("ShowJoinClassOnOpen", false).apply()
            showJoinClassDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
        loadTodos()
        loadAnnouncements()
    }

    // ── Join Class Dialog ──────────────────────────────────────────────────

    private fun showJoinClassDialog() {
        val currentUser = DataManager.getCurrentUser() ?: return

        // Build dialog layout programmatically (no extra XML needed)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 40, 64, 16)
        }

        val tvTitle = TextView(this).apply {
            text = "Join a Class"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            gravity = Gravity.CENTER
        }

        val tvSubtitle = TextView(this).apply {
            text = "Enter the class code provided by your teacher to join a subject."
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }

        val etClassCode = EditText(this).apply {
            hint = "Class Code (e.g. 1234)"
            textSize = 16f
            setPadding(24, 20, 24, 20)
            setBackgroundResource(R.drawable.bg_field_rounded)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        container.addView(tvTitle)
        container.addView(tvSubtitle)
        container.addView(etClassCode)

        val enrolledClasses = DataManager.getEnrolledClasses(this, currentUser.username)
        val isCancelable = enrolledClasses.isNotEmpty()  // can only dismiss if already in a class

        val dialog = AlertDialog.Builder(this)
            .setView(container)
            .setCancelable(isCancelable)
            .create()

        // ── Buttons ────────────────────────────────────────────────────────
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(64, 16, 64, 24)
        }

        if (isCancelable) {
            val btnCancel = Button(this).apply {
                text = "Later"
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
            }
            btnCancel.setOnClickListener { dialog.dismiss() }
            btnRow.addView(btnCancel)
        }

        val btnJoin = Button(this).apply {
            text = "Join Class"
            setBackgroundResource(R.drawable.bg_role_selected)
            setTextColor(android.graphics.Color.WHITE)
        }

        btnJoin.setOnClickListener {
            val code = etClassCode.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Please enter a class code", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val classToJoin = DataManager.getClasses(this).find { it.classCode == code }
            if (classToJoin == null) {
                Toast.makeText(this, "Invalid class code. Please try again.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val alreadyEnrolled = DataManager.isStudentEnrolled(this, currentUser.username, classToJoin.id)
            if (alreadyEnrolled) {
                Toast.makeText(this, "You are already in this class.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                return@setOnClickListener
            }

            DataManager.enrollStudent(
                this,
                StudentEnrollment(
                    studentName = currentUser.username,
                    classId     = classToJoin.id,
                    section     = classToJoin.section
                )
            )

            Toast.makeText(this, "Joined: ${classToJoin.className} ✓", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            loadDynamicClasses()   // refresh cards
        }

        btnRow.addView(btnJoin)
        container.addView(btnRow)

        dialog.show()
    }

    // ── Class cards ────────────────────────────────────────────────────────

    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()

        val currentUser = DataManager.getCurrentUser()

        // Each logged-in account sees only its own classes.
        // A newly created teacher account starts with no class subjects.
        val classes: List<ClassData> = DataManager.getClassesForCurrentUser(this)

        if (classes.isNotEmpty()) {
            val titleView = TextView(this).apply {
                text = "My Classes"
                textSize = 16f
                setTypeface(null, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                setPadding(0, 16, 0, 12)
            }
            dynamicClassesContainer.addView(titleView)

            for (i in classes.indices step 2) {
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 10) }
                }

                row.addView(createClassCard(classes[i]))

                val spacer = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        (20 * resources.displayMetrics.density).toInt(), 1
                    )
                }
                row.addView(spacer)

                if (i + 1 < classes.size) {
                    row.addView(createClassCard(classes[i + 1]))
                } else {
                    val invisibleCard = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
                    }
                    row.addView(invisibleCard)
                }

                dynamicClassesContainer.addView(row)
            }
        } else if (currentUser?.role == "Student") {
            // Student has no classes → prompt to join
            val emptyTv = TextView(this).apply {
                text = "You haven't joined any classes yet.\nTap \"Join Class\" to get started."
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(8, 24, 8, 8)
                setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
            }
            val btnJoinPrompt = Button(this).apply {
                text = "Join a Class"
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = 16
                    gravity = Gravity.CENTER_HORIZONTAL
                }
                setBackgroundResource(R.drawable.bg_role_selected)
                setTextColor(android.graphics.Color.WHITE)
            }
            btnJoinPrompt.setOnClickListener { showJoinClassDialog() }
            dynamicClassesContainer.addView(emptyTv)
            dynamicClassesContainer.addView(btnJoinPrompt)
        }
    }

    private fun createClassCard(classData: ClassData): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(0, 0, 0, 16)
        }

        val coverHeightPx = (78 * resources.displayMetrics.density).toInt()

        val coverFrame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, coverHeightPx
            )
            setBackgroundResource(R.drawable.bg_subject_card_empty)
            clipToOutline = true
        }

        val tvCover = TextView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
            )
            text = classData.className
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(android.graphics.Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 8)
            maxLines = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            setBackgroundResource(R.drawable.bg_subject_card_empty)
        }

        val imgCover = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.CENTER_CROP
            visibility = View.GONE
        }

        coverFrame.addView(tvCover)
        coverFrame.addView(imgCover)

        val coverFile = if (classData.coverImagePath.isNotEmpty()) File(classData.coverImagePath) else null
        if (coverFile != null && coverFile.exists()) {
            tvCover.visibility = View.GONE
            imgCover.visibility = View.VISIBLE
            Glide.with(this).load(coverFile).centerCrop()
                .placeholder(R.drawable.bg_subject_card).into(imgCover)
        }

        val textView = TextView(this).apply {
            text = classData.className
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
            setPadding(0, 6, 0, 0)
        }

        card.addView(coverFrame)
        card.addView(textView)

        card.setOnClickListener {
            val intent = Intent(this, ClassDetailsActivity::class.java)
            intent.putExtra("class_id", classData.id)
            intent.putExtra("subject_name", classData.className)
            startActivity(intent)
        }

        return card
    }

    // ── Todos & Announcements (unchanged) ──────────────────────────────────

    private fun loadTodos() {
        todoContainer.removeAllViews()
        val todos = DataManager.getTodos()

        if (todos.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No pending tasks"
                textSize = 12f
                setPadding(8, 8, 8, 8)
            }
            todoContainer.addView(emptyTv)
        } else {
            todos.forEach { todo ->
                val todoView = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 8, 8, 8)
                    setBackgroundResource(R.drawable.bg_white_strip)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 8) }
                }
                val titleTv = TextView(this).apply {
                    text = todo.title
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                }
                val dateTv = TextView(this).apply {
                    text = todo.dueDate
                    textSize = 11f
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
                }
                todoView.addView(titleTv)
                todoView.addView(dateTv)
                todoContainer.addView(todoView)
            }
        }
    }

    private fun loadAnnouncements() {
        announcementContainer.removeAllViews()
        val announcements = DataManager.getAllAnnouncements()

        if (announcements.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = "No announcements"
                textSize = 12f
                setPadding(8, 8, 8, 8)
            }
            announcementContainer.addView(emptyTv)
        } else {
            announcements.forEach { announcement ->
                val annView = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(8, 8, 8, 8)
                    setBackgroundResource(R.drawable.bg_white_strip)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, 0, 0, 8) }
                }
                val titleTv = TextView(this).apply {
                    text = announcement.title
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    maxLines = 1
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.black))
                }
                val descTv = TextView(this).apply {
                    text = announcement.description
                    textSize = 11f
                    maxLines = 2
                    setTextColor(ContextCompat.getColor(this@HomeActivity, android.R.color.darker_gray))
                }
                annView.addView(titleTv)
                annView.addView(descTv)
                annView.setOnClickListener {
                    val intent = Intent(this, AnnouncementActivity::class.java)
                    intent.putExtra("announcement_id", announcement.id)
                    startActivity(intent)
                }
                announcementContainer.addView(annView)
            }
        }
    }
}
