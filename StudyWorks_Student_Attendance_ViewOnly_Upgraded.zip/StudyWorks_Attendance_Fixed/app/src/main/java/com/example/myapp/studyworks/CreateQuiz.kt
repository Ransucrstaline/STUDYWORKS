package com.example.myapp.studyworks

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CreateQuiz : AppCompatActivity() {

    private var currentClassId: String = ""
    private var selectedQuizType: String = "multiple_choice"  // multiple_choice, true_false, identification
    private var selectedCorrectAnswer: Int = 1  // 1-4 for multiple choice, 1=True/2=False for true_false
    
    // Question list to store multiple questions
    private val questionsList = mutableListOf<QuizQuestionData>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_quiz)

        // Get class ID from intent
        currentClassId = intent.getStringExtra("class_id") ?: ""

        // Quiz info fields
        val etQuizTitle = findViewById<EditText>(R.id.etQuizTitle)
        val etQuizDescription = findViewById<EditText>(R.id.etQuizDescription)
        val etQuestion = findViewById<EditText>(R.id.etQuestion)

        // Multiple choice options
        val opt1 = findViewById<EditText>(R.id.option1)
        val opt2 = findViewById<EditText>(R.id.option2)
        val opt3 = findViewById<EditText>(R.id.option3)
        val opt4 = findViewById<EditText>(R.id.option4)

        // Identification answer
        val etCorrectAnswer = findViewById<EditText>(R.id.etCorrectAnswer)

        // Quiz type buttons
        val btnTypeMultipleChoice = findViewById<LinearLayout>(R.id.btnTypeMultipleChoice)
        val btnTypeTrueFalse = findViewById<LinearLayout>(R.id.btnTypeTrueFalse)
        val btnTypeIdentification = findViewById<LinearLayout>(R.id.btnTypeIdentification)

        val tvTypeMultipleChoice = findViewById<TextView>(R.id.tvTypeMultipleChoice)
        val tvTypeTrueFalse = findViewById<TextView>(R.id.tvTypeTrueFalse)
        val tvTypeIdentification = findViewById<TextView>(R.id.tvTypeIdentification)

        // Question type containers
        val multipleChoiceContainer = findViewById<LinearLayout>(R.id.multipleChoiceContainer)
        val trueFalseContainer = findViewById<LinearLayout>(R.id.trueFalseContainer)
        val identificationContainer = findViewById<LinearLayout>(R.id.identificationContainer)

        // Multiple choice answer buttons
        val btnAnswerA = findViewById<Button>(R.id.btnAnswerA)
        val btnAnswerB = findViewById<Button>(R.id.btnAnswerB)
        val btnAnswerC = findViewById<Button>(R.id.btnAnswerC)
        val btnAnswerD = findViewById<Button>(R.id.btnAnswerD)

        // True/False buttons
        val btnTrue = findViewById<Button>(R.id.btnTrue)
        val btnFalse = findViewById<Button>(R.id.btnFalse)

        // Action buttons
        val btnSaveQuiz = findViewById<Button>(R.id.btnUpload)
        val btnBack = findViewById<ImageButton>(R.id.btnClose)
        val btnAddQuestion = findViewById<Button>(R.id.btnAddQuestion)

        // Function to update quiz type UI
        fun updateQuizTypeUI() {
            // Reset all type buttons
            btnTypeMultipleChoice.setBackgroundResource(R.drawable.bg_role_unselected)
            btnTypeTrueFalse.setBackgroundResource(R.drawable.bg_role_unselected)
            btnTypeIdentification.setBackgroundResource(R.drawable.bg_role_unselected)
            tvTypeMultipleChoice.setTextColor(0xFF666666.toInt())
            tvTypeTrueFalse.setTextColor(0xFF666666.toInt())
            tvTypeIdentification.setTextColor(0xFF666666.toInt())

            // Hide all containers
            multipleChoiceContainer.visibility = View.GONE
            trueFalseContainer.visibility = View.GONE
            identificationContainer.visibility = View.GONE

            // Show selected type
            when (selectedQuizType) {
                "multiple_choice" -> {
                    btnTypeMultipleChoice.setBackgroundResource(R.drawable.bg_role_selected)
                    tvTypeMultipleChoice.setTextColor(0xFFFFFFFF.toInt())
                    multipleChoiceContainer.visibility = View.VISIBLE
                }
                "true_false" -> {
                    btnTypeTrueFalse.setBackgroundResource(R.drawable.bg_role_selected)
                    tvTypeTrueFalse.setTextColor(0xFFFFFFFF.toInt())
                    trueFalseContainer.visibility = View.VISIBLE
                }
                "identification" -> {
                    btnTypeIdentification.setBackgroundResource(R.drawable.bg_role_selected)
                    tvTypeIdentification.setTextColor(0xFFFFFFFF.toInt())
                    identificationContainer.visibility = View.VISIBLE
                }
            }
        }

        // Function to update answer selection UI for multiple choice
        fun updateAnswerSelectionUI() {
            val buttons = listOf(btnAnswerA, btnAnswerB, btnAnswerC, btnAnswerD)
            buttons.forEachIndexed { index, button ->
                if (index + 1 == selectedCorrectAnswer) {
                    button.setBackgroundResource(R.drawable.bg_role_selected)
                    button.setTextColor(0xFFFFFFFF.toInt())
                } else {
                    button.setBackgroundResource(R.drawable.bg_role_unselected)
                    button.setTextColor(0xFF666666.toInt())
                }
            }
        }

        // Function to update True/False selection UI
        fun updateTrueFalseUI() {
            if (selectedCorrectAnswer == 1) {
                btnTrue.setBackgroundResource(R.drawable.bg_role_selected)
                btnTrue.setTextColor(0xFFFFFFFF.toInt())
                btnFalse.setBackgroundResource(R.drawable.bg_role_unselected)
                btnFalse.setTextColor(0xFF666666.toInt())
            } else {
                btnFalse.setBackgroundResource(R.drawable.bg_role_selected)
                btnFalse.setTextColor(0xFFFFFFFF.toInt())
                btnTrue.setBackgroundResource(R.drawable.bg_role_unselected)
                btnTrue.setTextColor(0xFF666666.toInt())
            }
        }

        // Quiz type button click handlers
        btnTypeMultipleChoice.setOnClickListener {
            selectedQuizType = "multiple_choice"
            selectedCorrectAnswer = 1
            updateQuizTypeUI()
            updateAnswerSelectionUI()
        }

        btnTypeTrueFalse.setOnClickListener {
            selectedQuizType = "true_false"
            selectedCorrectAnswer = 1
            updateQuizTypeUI()
            updateTrueFalseUI()
        }

        btnTypeIdentification.setOnClickListener {
            selectedQuizType = "identification"
            updateQuizTypeUI()
        }

        // Multiple choice answer selection
        btnAnswerA.setOnClickListener {
            selectedCorrectAnswer = 1
            updateAnswerSelectionUI()
        }
        btnAnswerB.setOnClickListener {
            selectedCorrectAnswer = 2
            updateAnswerSelectionUI()
        }
        btnAnswerC.setOnClickListener {
            selectedCorrectAnswer = 3
            updateAnswerSelectionUI()
        }
        btnAnswerD.setOnClickListener {
            selectedCorrectAnswer = 4
            updateAnswerSelectionUI()
        }

        // True/False selection
        btnTrue.setOnClickListener {
            selectedCorrectAnswer = 1
            updateTrueFalseUI()
        }
        btnFalse.setOnClickListener {
            selectedCorrectAnswer = 2
            updateTrueFalseUI()
        }

        // Back button
        btnBack.setOnClickListener {
            finish()
        }

        // Add another question button
        btnAddQuestion.setOnClickListener {
            // Validate current question first
            val quizQuestion = etQuestion.text.toString().trim()
            
            if (quizQuestion.isEmpty()) {
                Toast.makeText(this, "Please enter a question first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Validate based on question type
            when (selectedQuizType) {
                "multiple_choice" -> {
                    val answer1 = opt1.text.toString().trim()
                    val answer2 = opt2.text.toString().trim()
                    val answer3 = opt3.text.toString().trim()
                    val answer4 = opt4.text.toString().trim()

                    if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty() || answer4.isEmpty()) {
                        Toast.makeText(this, "Please fill in all answer options", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }

                    // Add question to list
                    questionsList.add(QuizQuestionData(
                        questionType = "multiple_choice",
                        question = quizQuestion,
                        option1 = answer1,
                        option2 = answer2,
                        option3 = answer3,
                        option4 = answer4,
                        correctAnswer = selectedCorrectAnswer
                    ))
                }
                "true_false" -> {
                    questionsList.add(QuizQuestionData(
                        questionType = "true_false",
                        question = quizQuestion,
                        option1 = "True",
                        option2 = "False",
                        correctAnswer = selectedCorrectAnswer
                    ))
                }
                "identification" -> {
                    val correctAnswerText = etCorrectAnswer.text.toString().trim()
                    if (correctAnswerText.isEmpty()) {
                        Toast.makeText(this, "Please enter the correct answer", Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }

                    questionsList.add(QuizQuestionData(
                        questionType = "identification",
                        question = quizQuestion,
                        correctAnswerText = correctAnswerText
                    ))
                }
            }

            // Clear fields for next question
            etQuestion.text.clear()
            opt1.text.clear()
            opt2.text.clear()
            opt3.text.clear()
            opt4.text.clear()
            etCorrectAnswer.text.clear()
            selectedCorrectAnswer = 1
            updateAnswerSelectionUI()
            updateTrueFalseUI()

            Toast.makeText(this, "Question added! Total: ${questionsList.size} question(s)", Toast.LENGTH_SHORT).show()
        }

        // Save quiz button
        btnSaveQuiz.setOnClickListener {
            val quizTitle = etQuizTitle.text.toString().trim()
            val quizDescription = etQuizDescription.text.toString().trim()
            val quizQuestion = etQuestion.text.toString().trim()

            // Validate required fields
            if (quizTitle.isEmpty()) {
                Toast.makeText(this, "Please enter a quiz title", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // If there's a current question being edited, add it first
            if (quizQuestion.isNotEmpty()) {
                when (selectedQuizType) {
                    "multiple_choice" -> {
                        val answer1 = opt1.text.toString().trim()
                        val answer2 = opt2.text.toString().trim()
                        val answer3 = opt3.text.toString().trim()
                        val answer4 = opt4.text.toString().trim()

                        if (answer1.isEmpty() || answer2.isEmpty() || answer3.isEmpty() || answer4.isEmpty()) {
                            Toast.makeText(this, "Please fill in all answer options", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }

                        questionsList.add(QuizQuestionData(
                            questionType = "multiple_choice",
                            question = quizQuestion,
                            option1 = answer1,
                            option2 = answer2,
                            option3 = answer3,
                            option4 = answer4,
                            correctAnswer = selectedCorrectAnswer
                        ))
                    }
                    "true_false" -> {
                        questionsList.add(QuizQuestionData(
                            questionType = "true_false",
                            question = quizQuestion,
                            option1 = "True",
                            option2 = "False",
                            correctAnswer = selectedCorrectAnswer
                        ))
                    }
                    "identification" -> {
                        val correctAnswerText = etCorrectAnswer.text.toString().trim()
                        if (correctAnswerText.isEmpty()) {
                            Toast.makeText(this, "Please enter the correct answer", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }

                        questionsList.add(QuizQuestionData(
                            questionType = "identification",
                            question = quizQuestion,
                            correctAnswerText = correctAnswerText
                        ))
                    }
                }
            }

            // Check if we have at least one question
            if (questionsList.isEmpty()) {
                Toast.makeText(this, "Please add at least one question", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Get current user info
            val currentUser = DataManager.getCurrentUser()
            val createdBy = currentUser?.username ?: "Unknown"
            val currentDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())

            // Create quiz data
            val quizData = QuizData(
                classId = currentClassId,
                title = quizTitle,
                description = quizDescription,
                createdBy = createdBy,
                createdDate = currentDate,
                dueDate = "",
                points = questionsList.size * 10
            )

            // Add quiz and get the generated ID
            val quizId = DataManager.addQuiz(quizData)

            // Add all questions to the quiz
            questionsList.forEach { question ->
                val questionData = question.copy(quizId = quizId)
                DataManager.addQuizQuestion(questionData)
            }

            Toast.makeText(this, "Quiz created with ${questionsList.size} question(s)!", Toast.LENGTH_SHORT).show()
            finish()
        }

        // Initialize UI
        updateQuizTypeUI()
        updateAnswerSelectionUI()
    }
}
