package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenterContact : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center_contact)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchHelp = findViewById<EditText>(R.id.etSearchHelp)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)
        val tvEmailValue = findViewById<TextView>(R.id.tvEmailValue)
        val tvInstagramValue = findViewById<TextView>(R.id.tvInstagramValue)
        val tvFacebookValue = findViewById<TextView>(R.id.tvFacebookValue)

        btnBack.setOnClickListener { finish() }
        btnAdd.setOnClickListener { startActivity(Intent(this, Add::class.java)) }
        btnMenu.setOnClickListener { startActivity(Intent(this, Profile::class.java)) }
        tabFaq.setOnClickListener { startActivity(Intent(this, HelpCenter::class.java)) }
        tabContactUs.setOnClickListener { Toast.makeText(this, "Contact details shown", Toast.LENGTH_SHORT).show() }

        tvEmailValue.setOnClickListener { Toast.makeText(this, "Email: ${tvEmailValue.text}", Toast.LENGTH_SHORT).show() }
        tvInstagramValue.setOnClickListener { Toast.makeText(this, "Instagram: ${tvInstagramValue.text}", Toast.LENGTH_SHORT).show() }
        tvFacebookValue.setOnClickListener { Toast.makeText(this, "Facebook: ${tvFacebookValue.text}", Toast.LENGTH_SHORT).show() }

        imgSearch?.setOnClickListener { searchHelp(etSearchHelp.text.toString()) }
        etSearchHelp.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                searchHelp(etSearchHelp.text.toString())
                true
            } else false
        }
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.NONE)
    }

    private fun searchHelp(queryText: String) {
        val query = queryText.trim().lowercase()
        when {
            query.isEmpty() -> Toast.makeText(this, "Type a help topic first", Toast.LENGTH_SHORT).show()
            "account" in query || "create" in query || "sign" in query -> startActivity(Intent(this, HelpCenterExpanded::class.java))
            "login" in query -> startActivity(Intent(this, HelpCenterLogin::class.java))
            "forgot" in query || "reset" in query -> startActivity(Intent(this, HelpCenterForgotPassword::class.java))
            "change" in query || "password" in query -> startActivity(Intent(this, HelpCenterChangePassword::class.java))
            "faq" in query -> startActivity(Intent(this, HelpCenter::class.java))
            else -> Toast.makeText(this, "Contact details are shown below.", Toast.LENGTH_SHORT).show()
        }
    }
}
