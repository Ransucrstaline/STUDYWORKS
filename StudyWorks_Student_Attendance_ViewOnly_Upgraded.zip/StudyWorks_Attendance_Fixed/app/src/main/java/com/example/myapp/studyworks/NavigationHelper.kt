package com.example.myapp.studyworks

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.studyworks.R

object NavigationHelper {

    enum class Tab {
        HOME, CLASSES, NOTIFICATION, PROFILE, MORE, NONE
    }

    fun setupBottomNavigation(activity: Activity, activeTab: Tab) {
        val navHome = activity.findViewById<LinearLayout>(R.id.navHome)
        val navClasses = activity.findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = activity.findViewById<LinearLayout>(R.id.navNotification)
        val navProfile = activity.findViewById<LinearLayout>(R.id.navProfile)
        val navMore = activity.findViewById<LinearLayout>(R.id.navMore)

        when (activeTab) {
            Tab.HOME -> setActiveStyle(activity, R.id.ivNavHome, R.id.tvNavHome)
            Tab.CLASSES -> setActiveStyle(activity, R.id.ivNavClasses, R.id.tvNavClasses)
            Tab.NOTIFICATION -> setActiveStyle(activity, R.id.ivNavNotification, R.id.tvNavNotification)
            Tab.PROFILE -> { }
            Tab.MORE -> { }
            Tab.NONE -> { }
        }

        navHome?.setOnClickListener {
            if (activeTab != Tab.HOME) {
                activity.startActivity(Intent(activity, HomeActivity::class.java))
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navClasses?.setOnClickListener {
            if (activeTab != Tab.CLASSES) {
                activity.startActivity(Intent(activity, MyClassesActivity::class.java))
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navNotification?.setOnClickListener {
            if (activeTab != Tab.NOTIFICATION) {
                activity.startActivity(Intent(activity, Notification::class.java))
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navProfile?.setOnClickListener {
            if (activeTab != Tab.PROFILE) {
                activity.startActivity(Intent(activity, Profile::class.java))
                if (activeTab != Tab.NONE) activity.finish()
            }
        }

        navMore?.setOnClickListener {
            if (activeTab != Tab.MORE) {
                activity.startActivity(Intent(activity, MoreActivity::class.java))
                if (activeTab != Tab.NONE) activity.finish()
            }
        }
    }

    private fun setActiveStyle(activity: Activity, iconId: Int, textId: Int) {
        val icon = activity.findViewById<ImageView>(iconId)
        val text = activity.findViewById<TextView>(textId)
        val activeColor = ContextCompat.getColor(activity, R.color.active_tab_color)

        icon?.setColorFilter(activeColor)
        text?.setTextColor(activeColor)
        text?.setTypeface(null, Typeface.BOLD)
    }
}
