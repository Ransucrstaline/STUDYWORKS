package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd      = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu     = findViewById<ImageView>(R.id.btnMenu)
        val etSearch    = findViewById<EditText>(R.id.etSearch)
        val imgSearch   = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter   = findViewById<ImageView>(R.id.imgFilter)
        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.CLASSES)
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    // ── Load classes based on role ─────────────────────────────────────────

    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()

        val currentUser = DataManager.getCurrentUser()
        val isStudent   = currentUser?.role == "Student"

        // Each logged-in account sees only its own classes.
        // A newly created teacher account starts with no class subjects.
        val classes: List<ClassData> = DataManager.getClassesForCurrentUser(this)

        if (classes.isEmpty()) {
            val emptyMsg = if (isStudent)
                "You haven't joined any classes yet.\nAsk your teacher for a class code."
            else
                "No classes yet. Tap + to create one."

            val emptyTv = TextView(this).apply {
                text = emptyMsg
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, 24, 0, 16)
                setTextColor(resources.getColor(android.R.color.darker_gray, null))
            }
            dynamicClassesContainer.addView(emptyTv)

            // Students get a Join Class button in the empty state
            if (isStudent) {
                val btnJoinPrompt = Button(this).apply {
                    text = "Join a Class"
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = 8
                        gravity = Gravity.CENTER_HORIZONTAL
                    }
                    setBackgroundResource(R.drawable.bg_role_selected)
                    setTextColor(android.graphics.Color.WHITE)
                }
                btnJoinPrompt.setOnClickListener { showJoinClassDialog() }
                dynamicClassesContainer.addView(btnJoinPrompt)
            }
            return
        }

        for (classData in classes) {
            val cardView = layoutInflater.inflate(
                R.layout.item_dynamic_class, dynamicClassesContainer, false
            )

            val tvCoverName = cardView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = cardView.findViewById<ImageView>(R.id.imgClassCard)
            val tvName       = cardView.findViewById<TextView>(R.id.tvClassName)
            val tvSection    = cardView.findViewById<TextView>(R.id.tvClassSection)
            val btnEdit      = cardView.findViewById<TextView>(R.id.btnEditClass)
            val btnDelete    = cardView.findViewById<TextView>(R.id.btnDeleteClass)

            tvName.text    = classData.className
            tvSection.text = classData.section

            // ── Cover image logic ──────────────────────────────────────────
            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                tvCoverName.visibility   = View.GONE
                imgClassCard.visibility  = View.VISIBLE
                Glide.with(this).load(coverFile).centerCrop()
                    .placeholder(R.drawable.bg_subject_card).into(imgClassCard)
            } else {
                imgClassCard.visibility  = View.GONE
                tvCoverName.visibility   = View.VISIBLE
                tvCoverName.text         = classData.className
            }

            // ── Role-specific controls ─────────────────────────────────────
            if (isStudent) {
                // Students: hide teacher-only actions
                btnEdit.visibility   = View.GONE
                btnDelete.visibility = View.GONE
            } else {
                // Teachers: full edit / delete
                btnEdit.visibility   = View.VISIBLE
                btnDelete.visibility = View.VISIBLE

                btnEdit.setOnClickListener {
                    val intent = Intent(this, CreateClassActivity::class.java)
                    intent.putExtra("edit_mode", true)
                    intent.putExtra("class_id", classData.id)
                    startActivity(intent)
                }

                btnDelete.setOnClickListener {
                    showDeleteConfirmation(classData)
                }
            }

            // ── Card tap → class details (both roles) ──────────────────────
            cardView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("class_id", classData.id)
                intent.putExtra("subject_name", classData.className)
                startActivity(intent)
            }

            dynamicClassesContainer.addView(cardView)
        }
    }

    // ── Join Class Dialog (Styled) ──────────────────────────────────────────

    private fun showJoinClassDialog() {
        val currentUser = DataManager.getCurrentUser() ?: return

        // Inflate custom dialog layout
        val dialogView = layoutInflater.inflate(R.layout.dialog_join_class, null)

        val etClassCode        = dialogView.findViewById<EditText>(R.id.etClassCode)
        val btnFindClass       = dialogView.findViewById<Button>(R.id.btnFindClass)
        val layoutClassPreview = dialogView.findViewById<LinearLayout>(R.id.layoutClassPreview)
        val tvPreviewClassName = dialogView.findViewById<TextView>(R.id.tvPreviewClassName)
        val tvPreviewSection   = dialogView.findViewById<TextView>(R.id.tvPreviewSection)
        val tvPreviewTeacher   = dialogView.findViewById<TextView>(R.id.tvPreviewTeacher)
        val tvPreviewSchedule  = dialogView.findViewById<TextView>(R.id.tvPreviewSchedule)
        val btnCancelJoin      = dialogView.findViewById<TextView>(R.id.btnCancelJoin)
        val btnConfirmJoin     = dialogView.findViewById<Button>(R.id.btnConfirmJoin)

        // Track the found class to join on confirm
        var foundClass: ClassData? = null

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        // Make dialog background transparent so our custom card shows rounded corners
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        // ── Find Class ────────────────────────────────────────────────────
        btnFindClass.setOnClickListener {
            val code = etClassCode.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Please enter a class code", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val cls = DataManager.getClasses(this).find { it.classCode == code }
            if (cls == null) {
                layoutClassPreview.visibility = View.GONE
                btnConfirmJoin.isEnabled = false
                btnConfirmJoin.alpha = 0.5f
                foundClass = null
                Toast.makeText(this, "❌ Class code not found. Please check and try again.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if already enrolled
            if (DataManager.isStudentEnrolled(this, currentUser.username, cls.id)) {
                layoutClassPreview.visibility = View.GONE
                btnConfirmJoin.isEnabled = false
                btnConfirmJoin.alpha = 0.5f
                foundClass = null
                Toast.makeText(this, "You are already enrolled in this class.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ── Populate preview card ─────────────────────────────────────
            foundClass = cls
            tvPreviewClassName.text = cls.className
            tvPreviewSection.text   = cls.section
            tvPreviewSchedule.text  = cls.schedule.ifEmpty { "Not specified" }

            // Show teacher name — fall back gracefully
            val displayTeacher = when {
                cls.teacherName.isNotEmpty() -> cls.teacherName
                else -> "Not assigned"
            }
            tvPreviewTeacher.text = displayTeacher

            layoutClassPreview.visibility = View.VISIBLE
            btnConfirmJoin.isEnabled = true
            btnConfirmJoin.alpha = 1.0f
        }

        // ── Confirm Join ──────────────────────────────────────────────────
        btnConfirmJoin.setOnClickListener {
            val cls = foundClass ?: return@setOnClickListener

            DataManager.enrollStudent(
                this,
                StudentEnrollment(
                    studentName = currentUser.username,
                    classId     = cls.id,
                    section     = cls.section
                )
            )

            val teacherLabel = if (cls.teacherName.isNotEmpty())
                "Teacher: ${cls.teacherName}" else ""

            Toast.makeText(
                this,
                "✓ Joined ${cls.className}${if (teacherLabel.isNotEmpty()) "\n$teacherLabel" else ""}",
                Toast.LENGTH_LONG
            ).show()

            dialog.dismiss()
            loadDynamicClasses()
        }

        // ── Cancel ────────────────────────────────────────────────────────
        btnCancelJoin.setOnClickListener { dialog.dismiss() }

        dialog.show()

        // Set dialog width to 90% of screen
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.90).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    // ── Delete confirmation (Teachers only) ────────────────────────────────

    private fun showDeleteConfirmation(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle("Delete Class")
            .setMessage("Are you sure you want to delete \"${classData.className}\"? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                DataManager.deleteClass(this, classData.id)
                Toast.makeText(this, "\"${classData.className}\" deleted.", Toast.LENGTH_SHORT).show()
                loadDynamicClasses()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Top buttons ────────────────────────────────────────────────────────

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        val isStudent = DataManager.isStudent()

        // The + icon and the "Add Class" card button both respect the role
        val addAction: () -> Unit = if (isStudent) {
            { showJoinClassDialog() }
        } else {
            { startActivity(Intent(this, Add::class.java)) }
        }

        btnAdd.setOnClickListener { addAction() }
        btnAddClass.setOnClickListener { addAction() }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }
        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
