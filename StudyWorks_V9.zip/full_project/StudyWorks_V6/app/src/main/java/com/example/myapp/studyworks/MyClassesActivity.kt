package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd    = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu   = findViewById<ImageView>(R.id.btnMenu)
        val etSearch  = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        val isTeacher = DataManager.isTeacher()

        // ── Role-based top-bar behaviour ────────────────────────────────
        if (isTeacher) {
            // Teachers: show "Add Class" button (existing behaviour)
            btnAddClass.visibility = View.VISIBLE
            btnAdd.setOnClickListener {
                startActivity(Intent(this, AddClassOrJoinActivity::class.java))
            }
            btnAddClass.setOnClickListener {
                startActivity(Intent(this, CreateClassActivity::class.java))
            }
        } else {
            // Students: repurpose the add button as "Join Class"
            btnAddClass.visibility = View.VISIBLE
            // Change label text if the layout has a tvAddClass label
            val tvAddLabel = btnAddClass.getChildAt(1) as? TextView
            tvAddLabel?.text = "Join Class"

            btnAdd.setOnClickListener {
                startActivity(Intent(this, JoinClass::class.java))
            }
            btnAddClass.setOnClickListener {
                startActivity(Intent(this, JoinClass::class.java))
            }
        }
        // ────────────────────────────────────────────────────────────────

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        setupSearch(etSearch, imgSearch, imgFilter)
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.CLASSES)
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    /**
     * Teachers see ALL classes with edit/delete options.
     * Students see ONLY their enrolled classes with a "Leave" option.
     */
    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()

        val classes   = DataManager.getClassesForCurrentUser(this)
        val isTeacher = DataManager.isTeacher()

        if (classes.isEmpty()) {
            val emptyTv = TextView(this).apply {
                text = if (isTeacher)
                    "No classes yet. Tap '+' to create one."
                else
                    "You haven't joined any class yet.\nUse '+' or 'Join Class' and enter the code from your teacher."
                textSize = 14f
                setPadding(16, 32, 16, 32)
            }
            dynamicClassesContainer.addView(emptyTv)
            return
        }

        for (classData in classes) {
            val itemView = layoutInflater.inflate(R.layout.item_dynamic_class, null)

            val tvCoverName  = itemView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = itemView.findViewById<ImageView>(R.id.imgClassCard)
            val tvClassName  = itemView.findViewById<TextView>(R.id.tvClassName)
            val tvSection    = itemView.findViewById<TextView>(R.id.tvClassSection)

            tvClassName?.text = classData.className
            tvSection?.text   = classData.section

            if (classData.coverImagePath.isNotEmpty() && File(classData.coverImagePath).exists()) {
                tvCoverName?.visibility  = View.GONE
                imgClassCard?.visibility = View.VISIBLE
                imgClassCard?.let { Glide.with(this).load(File(classData.coverImagePath)).into(it) }
            } else {
                tvCoverName?.visibility  = View.VISIBLE
                imgClassCard?.visibility = View.GONE
                tvCoverName?.text = classData.className
            }

            // Long-press menu
            itemView.setOnLongClickListener {
                if (isTeacher) {
                    showTeacherClassOptions(classData)
                } else {
                    showStudentClassOptions(classData)
                }
                true
            }

            itemView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("CLASS_DATA", classData)
                startActivity(intent)
            }

            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = 12.dpToPx() }
            itemView.layoutParams = lp
            dynamicClassesContainer.addView(itemView)
        }
    }

    // ── Teacher actions (existing: edit / delete) ────────────────────────
    private fun showTeacherClassOptions(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle(classData.className)
            .setItems(arrayOf("Edit", "Delete")) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(this, CreateClassActivity::class.java)
                        intent.putExtra("CLASS_DATA", classData)
                        startActivity(intent)
                    }
                    1 -> confirmDeleteClass(classData)
                }
            }
            .show()
    }

    private fun confirmDeleteClass(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle("Delete Class")
            .setMessage("Delete '${classData.className}'? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                DataManager.deleteClass(this, classData.id)
                Toast.makeText(this, "Class deleted", Toast.LENGTH_SHORT).show()
                loadDynamicClasses()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Student actions (leave class) ────────────────────────────────────
    private fun showStudentClassOptions(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle(classData.className)
            .setItems(arrayOf("Leave Class")) { _, _ ->
                confirmLeaveClass(classData)
            }
            .show()
    }

    private fun confirmLeaveClass(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle("Leave Class")
            .setMessage("Leave '${classData.className}'? You can re-join with the class code.")
            .setPositiveButton("Leave") { _, _ ->
                val user = DataManager.getCurrentUser() ?: return@setPositiveButton
                val db = DatabaseHelper(this)
                db.deleteEnrollment(user.username, classData.id)
                Toast.makeText(this, "You left ${classData.className}", Toast.LENGTH_SHORT).show()
                loadDynamicClasses()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Search ───────────────────────────────────────────────────────────
    private fun setupSearch(etSearch: EditText, imgSearch: ImageView, imgFilter: ImageView) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Enter a class name to search", Toast.LENGTH_SHORT).show()
            } else {
                filterClasses(query)
            }
        }
        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun filterClasses(query: String) {
        dynamicClassesContainer.removeAllViews()
        val all = DataManager.getClassesForCurrentUser(this)
        val filtered = all.filter { it.className.contains(query, ignoreCase = true) }
        if (filtered.isEmpty()) {
            val tv = TextView(this).apply { text = "No classes match \"$query\"" }
            dynamicClassesContainer.addView(tv)
        } else {
            filtered.forEach { /* reuse loadDynamicClasses rendering */ }
            loadDynamicClasses()
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density).toInt()
}
