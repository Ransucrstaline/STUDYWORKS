package com.example.myapp.studyworks

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.studyworks.R
import java.io.File

class MyClassesActivity : AppCompatActivity() {

    private lateinit var dynamicClassesContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        dynamicClassesContainer = findViewById(R.id.dynamicClassesContainer)

        val btnAdd      = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu     = findViewById<ImageView>(R.id.btnMenu)
        val etSearch    = findViewById<EditText>(R.id.etSearch)
        val imgSearch   = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter   = findViewById<ImageView>(R.id.imgFilter)
        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        NavigationHelper.setupBottomNavigation(this, NavigationHelper.Tab.CLASSES)
        loadDynamicClasses()
    }

    override fun onResume() {
        super.onResume()
        loadDynamicClasses()
    }

    // ── Load classes based on role ─────────────────────────────────────────

    private fun loadDynamicClasses() {
        dynamicClassesContainer.removeAllViews()

        val currentUser = DataManager.getCurrentUser()
        val isStudent   = currentUser?.role == "Student"

        val classes: List<ClassData> = if (isStudent) {
            DataManager.getEnrolledClasses(this, currentUser!!.username)
        } else {
            DataManager.getClasses(this)
        }

        if (classes.isEmpty()) {
            val emptyMsg = if (isStudent)
                "You haven't joined any classes yet.\nAsk your teacher for a class code."
            else
                "No classes yet. Tap + to create one."

            val emptyTv = TextView(this).apply {
                text = emptyMsg
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(0, 24, 0, 16)
                setTextColor(resources.getColor(android.R.color.darker_gray, null))
            }
            dynamicClassesContainer.addView(emptyTv)

            // Students get a Join Class button in the empty state
            if (isStudent) {
                val btnJoinPrompt = Button(this).apply {
                    text = "Join a Class"
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        topMargin = 8
                        gravity = Gravity.CENTER_HORIZONTAL
                    }
                    setBackgroundResource(R.drawable.bg_role_selected)
                    setTextColor(android.graphics.Color.WHITE)
                }
                btnJoinPrompt.setOnClickListener { showJoinClassDialog() }
                dynamicClassesContainer.addView(btnJoinPrompt)
            }
            return
        }

        for (classData in classes) {
            val cardView = layoutInflater.inflate(
                R.layout.item_dynamic_class, dynamicClassesContainer, false
            )

            val tvCoverName = cardView.findViewById<TextView>(R.id.tvCoverName)
            val imgClassCard = cardView.findViewById<ImageView>(R.id.imgClassCard)
            val tvName       = cardView.findViewById<TextView>(R.id.tvClassName)
            val tvSection    = cardView.findViewById<TextView>(R.id.tvClassSection)
            val btnEdit      = cardView.findViewById<TextView>(R.id.btnEditClass)
            val btnDelete    = cardView.findViewById<TextView>(R.id.btnDeleteClass)

            tvName.text    = classData.className
            tvSection.text = classData.section

            // ── Cover image logic ──────────────────────────────────────────
            val coverFile = if (classData.coverImagePath.isNotEmpty())
                File(classData.coverImagePath) else null

            if (coverFile != null && coverFile.exists()) {
                tvCoverName.visibility   = View.GONE
                imgClassCard.visibility  = View.VISIBLE
                Glide.with(this).load(coverFile).centerCrop()
                    .placeholder(R.drawable.bg_subject_card).into(imgClassCard)
            } else {
                imgClassCard.visibility  = View.GONE
                tvCoverName.visibility   = View.VISIBLE
                tvCoverName.text         = classData.className
            }

            // ── Role-specific controls ─────────────────────────────────────
            if (isStudent) {
                // Students: hide teacher-only actions
                btnEdit.visibility   = View.GONE
                btnDelete.visibility = View.GONE
            } else {
                // Teachers: full edit / delete
                btnEdit.visibility   = View.VISIBLE
                btnDelete.visibility = View.VISIBLE

                btnEdit.setOnClickListener {
                    val intent = Intent(this, CreateClassActivity::class.java)
                    intent.putExtra("edit_mode", true)
                    intent.putExtra("class_id", classData.id)
                    startActivity(intent)
                }

                btnDelete.setOnClickListener {
                    showDeleteConfirmation(classData)
                }
            }

            // ── Card tap → class details (both roles) ──────────────────────
            cardView.setOnClickListener {
                val intent = Intent(this, ClassDetailsActivity::class.java)
                intent.putExtra("class_id", classData.id)
                intent.putExtra("subject_name", classData.className)
                startActivity(intent)
            }

            dynamicClassesContainer.addView(cardView)
        }
    }

    // ── Join Class Dialog ──────────────────────────────────────────────────

    private fun showJoinClassDialog() {
        val currentUser = DataManager.getCurrentUser() ?: return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 40, 64, 16)
        }

        val tvTitle = TextView(this).apply {
            text = "Join a Class"
            textSize = 20f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(this@MyClassesActivity, android.R.color.black))
            gravity = Gravity.CENTER
        }

        val tvSubtitle = TextView(this).apply {
            text = "Enter the class code provided by your teacher."
            textSize = 13f
            setTextColor(ContextCompat.getColor(this@MyClassesActivity, android.R.color.darker_gray))
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }

        val etClassCode = EditText(this).apply {
            hint = "Class Code (e.g. 1234)"
            textSize = 16f
            setPadding(24, 20, 24, 20)
            setBackgroundResource(R.drawable.bg_field_rounded)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }

        container.addView(tvTitle)
        container.addView(tvSubtitle)
        container.addView(etClassCode)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, 24, 0, 8)
        }

        val btnCancel = Button(this).apply {
            text = "Cancel"
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            setTextColor(ContextCompat.getColor(this@MyClassesActivity, android.R.color.darker_gray))
        }

        val btnJoin = Button(this).apply {
            text = "Join Class"
            setBackgroundResource(R.drawable.bg_role_selected)
            setTextColor(android.graphics.Color.WHITE)
        }

        btnRow.addView(btnCancel)
        btnRow.addView(btnJoin)
        container.addView(btnRow)

        val dialog = AlertDialog.Builder(this)
            .setView(container)
            .setCancelable(true)
            .create()

        btnCancel.setOnClickListener { dialog.dismiss() }

        btnJoin.setOnClickListener {
            val code = etClassCode.text.toString().trim()
            if (code.isEmpty()) {
                Toast.makeText(this, "Please enter a class code", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val classToJoin = DataManager.getClasses(this).find { it.classCode == code }
            if (classToJoin == null) {
                Toast.makeText(this, "Invalid class code. Please try again.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val alreadyEnrolled = DataManager.isStudentEnrolled(this, currentUser.username, classToJoin.id)
            if (alreadyEnrolled) {
                Toast.makeText(this, "You are already enrolled in this class.", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                return@setOnClickListener
            }

            DataManager.enrollStudent(
                this,
                StudentEnrollment(
                    studentName = currentUser.username,
                    classId     = classToJoin.id,
                    section     = classToJoin.section
                )
            )

            Toast.makeText(this, "Joined: ${classToJoin.className} ✓", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
            loadDynamicClasses()
        }

        dialog.show()
    }

    // ── Delete confirmation (Teachers only) ────────────────────────────────

    private fun showDeleteConfirmation(classData: ClassData) {
        AlertDialog.Builder(this)
            .setTitle("Delete Class")
            .setMessage("Are you sure you want to delete \"${classData.className}\"? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                DataManager.deleteClass(this, classData.id)
                Toast.makeText(this, "\"${classData.className}\" deleted.", Toast.LENGTH_SHORT).show()
                loadDynamicClasses()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Top buttons ────────────────────────────────────────────────────────

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        val isStudent = DataManager.isStudent()

        // The + icon and the "Add Class" card button both respect the role
        val addAction: () -> Unit = if (isStudent) {
            { showJoinClassDialog() }
        } else {
            { startActivity(Intent(this, Add::class.java)) }
        }

        btnAdd.setOnClickListener { addAction() }
        btnAddClass.setOnClickListener { addAction() }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }
        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
