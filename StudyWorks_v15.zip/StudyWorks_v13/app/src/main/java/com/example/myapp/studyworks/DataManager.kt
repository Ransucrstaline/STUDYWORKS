package com.example.myapp.studyworks

import android.content.Context
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ============== DATA MODELS ==============

@Parcelize
data class UserData(
    val firstName: String = "",
    val lastName: String = "",
    val username: String = "",
    val passwordHash: String = "",
    val role: String = ""   // NEW: "Teacher" or "Student"
) : Parcelable

@Parcelize
data class ClassData(
    val id: String = "",
    val className: String = "",
    val section: String = "",
    val schedule: String = "",
    val roomNumber: String = "",
    val academicLevel: String = "",
    val classCode: String = "",
    val coverImagePath: String = "",
    val teacherName: String = ""   // Username of the teacher who created this class
) : Parcelable

@Parcelize
data class MaterialData(
    val id: String = "",
    val classId: String = "",
    val title: String = "",
    val description: String = "",
    val fileName: String = "",
    val uploadDate: String = ""
) : Parcelable

@Parcelize
data class AnnouncementData(
    val id: String = "",
    val classId: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val postDate: String = ""
) : Parcelable

@Parcelize
data class AttendanceData(
    val id: String = "",
    val classId: String = "",
    val studentName: String = "",
    val date: String = "",
    val status: String = ""
) : Parcelable

@Parcelize
data class StudentEnrollment(
    val studentName: String = "",
    val classId: String = "",
    val section: String = ""
) : Parcelable

@Parcelize
data class TodoData(
    val id: String = "",
    val title: String = "",
    val dueDate: String = "",
    val type: String = ""
) : Parcelable

@Parcelize
data class NotificationData(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val time: String = "",
    val type: String = ""
) : Parcelable

@Parcelize
data class QuizData(
    val id: String = "",
    val classId: String = "",
    val title: String = "",
    val description: String = "",
    val createdBy: String = "",
    val createdDate: String = "",
    val dueDate: String = "",
    val points: Int = 10
) : Parcelable

@Parcelize
data class QuizQuestionData(
    val id: String = "",
    val quizId: String = "",
    val questionType: String = "multiple_choice",  // "multiple_choice", "true_false", "identification"
    val question: String = "",
    val option1: String = "",
    val option2: String = "",
    val option3: String = "",
    val option4: String = "",
    val correctAnswer: Int = 1,  // 1-4 for multiple choice, 1=True/2=False for true_false
    val correctAnswerText: String = ""  // For identification type questions
) : Parcelable

@Parcelize
data class QuizResultData(
    val id: String = "",
    val quizId: String = "",
    val studentName: String = "",
    val score: Int = 0,
    val totalQuestions: Int = 0,
    val dateTaken: String = ""
) : Parcelable

// ============== DATA MANAGER SINGLETON ==============

object DataManager {
    private var currentUser: UserData? = null

    private val materials = mutableListOf<MaterialData>()
    private val announcements = mutableListOf<AnnouncementData>()
    private val attendance = mutableListOf<AttendanceData>()
    private val todos = mutableListOf<TodoData>()

    private var materialIdCounter = 1
    private var announcementIdCounter = 1
    private var attendanceIdCounter = 1
    private var todoIdCounter = 1
    private var quizIdCounter = 1
    private var questionIdCounter = 1
    private var resultIdCounter = 1

    private val quizzes = mutableListOf<QuizData>()
    private val quizQuestions = mutableListOf<QuizQuestionData>()
    private val quizResults = mutableListOf<QuizResultData>()

    // ============== USER OPERATIONS ==============

    fun registerUser(context: Context, user: UserData): Boolean {
        val db = DatabaseHelper(context)
        return db.addUser(user)
    }

    fun loginUser(context: Context, username: String, passwordHash: String): UserData? {
        val db = DatabaseHelper(context)
        val user = db.checkUser(username, passwordHash)
        currentUser = user
        return user
    }

    fun getCurrentUser(): UserData? = currentUser

    fun setCurrentUser(user: UserData?) {
        currentUser = user
    }

    /** Convenience: returns true if the currently logged-in user is a Teacher. */
    fun isTeacher(): Boolean = currentUser?.role == "Teacher"

    /** Convenience: returns true if the currently logged-in user is a Student. */
    fun isStudent(): Boolean = currentUser?.role == "Student"

    // ============== CLASS OPERATIONS ==============

    fun addClass(context: Context, classData: ClassData) {
        val db = DatabaseHelper(context)
        val finalClass = if (classData.id.isEmpty()) {
            classData.copy(id = "class_${System.currentTimeMillis()}")
        } else classData
        db.addClass(finalClass)
    }

    fun getClasses(context: Context): List<ClassData> {
        val db = DatabaseHelper(context)
        return db.getAllClasses()
    }

    fun getClassById(context: Context, classId: String): ClassData? {
        return getClasses(context).find { it.id == classId }
    }

    fun updateClass(context: Context, classData: ClassData) {
        val db = DatabaseHelper(context)
        db.updateClass(classData)
    }

    fun deleteClass(context: Context, classId: String) {
        val db = DatabaseHelper(context)
        db.deleteClass(classId)
    }

    // ============== ENROLLMENT OPERATIONS ==============

    fun enrollStudent(context: Context, enrollment: StudentEnrollment) {
        val db = DatabaseHelper(context)
        if (!db.isEnrolled(enrollment.studentName, enrollment.classId)) {
            db.addEnrollment(enrollment)
        }
    }

    fun isStudentEnrolled(context: Context, studentName: String, classId: String): Boolean {
        val db = DatabaseHelper(context)
        return db.isEnrolled(studentName, classId)
    }

    fun getStudentsByClass(context: Context, classId: String): List<StudentEnrollment> {
        val db = DatabaseHelper(context)
        return db.getEnrollmentsByClass(classId)
    }

    fun getEnrolledClasses(context: Context, studentName: String): List<ClassData> {
        val db = DatabaseHelper(context)
        val enrollments = db.getEnrollmentsByStudent(studentName)
        return enrollments.mapNotNull { getClassById(context, it.classId) }
    }

    // ============== MATERIAL OPERATIONS ==============

    fun addMaterial(materialData: MaterialData) {
        val newMaterial = materialData.copy(id = "material_${materialIdCounter++}")
        materials.add(newMaterial)
    }

    fun getMaterialsByClass(classId: String): List<MaterialData> =
        materials.filter { it.classId == classId }

    // ============== ANNOUNCEMENT OPERATIONS ==============

    fun addAnnouncement(announcementData: AnnouncementData) {
        val newAnnouncement = announcementData.copy(id = "announcement_${announcementIdCounter++}")
        announcements.add(newAnnouncement)
    }

    fun getAnnouncementsByClass(classId: String): List<AnnouncementData> =
        announcements.filter { it.classId == classId || it.classId == "all" }

    fun getAllAnnouncements(): List<AnnouncementData> = announcements.toList()

    // ============== TODO OPERATIONS ==============

    fun getTodos(): List<TodoData> = todos.toList()

    fun addTodo(todo: TodoData) {
        val newTodo = if (todo.id.isEmpty()) {
            todo.copy(id = "todo_${todoIdCounter++}")
        } else todo
        todos.add(newTodo)
    }

    // ============== NOTIFICATION OPERATIONS ==============

    fun getNotifications(context: Context): List<NotificationData> {
        val list = mutableListOf<NotificationData>()

        getClasses(context).forEach {
            list.add(NotificationData(
                id = "notif_class_${it.id}",
                title = "Upcoming Class: ${it.className}",
                description = "Section: ${it.section} | Room: ${it.roomNumber}",
                time = it.schedule,
                type = "Class"
            ))
        }

        todos.forEach {
            list.add(NotificationData(
                id = "notif_todo_${it.id}",
                title = "Pending ${it.type}: ${it.title}",
                description = "Deadline is approaching. Please complete it soon.",
                time = it.dueDate,
                type = it.type
            ))
        }

        return list.reversed()
    }

    // ============== ATTENDANCE OPERATIONS ==============

    fun addAttendance(attendanceData: AttendanceData) {
        saveOrUpdateAttendance(attendanceData)
    }

    fun saveOrUpdateAttendance(attendanceData: AttendanceData) {
        val existingIndex = attendance.indexOfFirst {
            it.classId == attendanceData.classId &&
                it.studentName.equals(attendanceData.studentName, ignoreCase = true) &&
                it.date == attendanceData.date
        }

        if (existingIndex >= 0) {
            attendance[existingIndex] = attendance[existingIndex].copy(status = attendanceData.status)
        } else {
            val newAttendance = attendanceData.copy(id = "attendance_${attendanceIdCounter++}")
            attendance.add(newAttendance)
        }
    }

    fun getAttendanceByClass(classId: String): List<AttendanceData> =
        attendance.filter { it.classId == classId }

    fun getAttendanceForStudent(classId: String, studentName: String): List<AttendanceData> =
        attendance.filter {
            it.classId == classId && it.studentName.equals(studentName, ignoreCase = true)
        }

    fun getAttendanceForStudentOnDate(classId: String, studentName: String, date: String): AttendanceData? =
        attendance.firstOrNull {
            it.classId == classId &&
                it.studentName.equals(studentName, ignoreCase = true) &&
                it.date == date
        }

    // ============== QUIZ OPERATIONS ==============

    fun addQuiz(quiz: QuizData): String {
        val newId = "quiz_${quizIdCounter++}"
        val newQuiz = quiz.copy(id = newId)
        quizzes.add(newQuiz)
        return newId
    }

    fun addQuizQuestion(question: QuizQuestionData) {
        val newQuestion = question.copy(id = "question_${questionIdCounter++}")
        quizQuestions.add(newQuestion)
    }

    fun getQuizzesByClass(classId: String): List<QuizData> =
        quizzes.filter { it.classId == classId }

    fun getAllQuizzes(): List<QuizData> = quizzes.toList()

    fun getQuizById(quizId: String): QuizData? =
        quizzes.find { it.id == quizId }

    fun getQuestionsByQuiz(quizId: String): List<QuizQuestionData> =
        quizQuestions.filter { it.quizId == quizId }

    fun addQuizResult(result: QuizResultData) {
        val newResult = result.copy(id = "result_${resultIdCounter++}")
        quizResults.add(newResult)
    }

    fun getQuizResultsByStudent(studentName: String): List<QuizResultData> =
        quizResults.filter { it.studentName == studentName }

    fun getQuizResultsByQuiz(quizId: String): List<QuizResultData> =
        quizResults.filter { it.quizId == quizId }

    fun hasStudentTakenQuiz(quizId: String, studentName: String): Boolean =
        quizResults.any { it.quizId == quizId && it.studentName == studentName }

    fun getStudentQuizResult(quizId: String, studentName: String): QuizResultData? =
        quizResults.find { it.quizId == quizId && it.studentName == studentName }

    // ============== UTILITY FUNCTIONS ==============

    fun clearAllData() {
        materials.clear()
        announcements.clear()
        attendance.clear()
        todos.clear()
    }

    fun generateUniqueClassCode(context: Context): String {
        val existingCodes = getClasses(context).map { it.classCode }
        var newCode: String
        do {
            newCode = (1000..9999).random().toString()
        } while (existingCodes.contains(newCode))
        return newCode
    }

    @Deprecated("Use generateUniqueClassCode(context) instead", ReplaceWith("generateUniqueClassCode(context)"))
    fun generateClassCode(): String {
        return (1000..9999).random().toString()
    }
}
