package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenterExpanded : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center_expanded)

        // HEADER
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)

        // SEARCH
        val etSearch = findViewById<EditText>(R.id.etSearchHelp)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)

        // TABS
        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)

        // CHIPS
        val chipAccount = findViewById<TextView>(R.id.chipAccount)
        val chipClasses = findViewById<TextView>(R.id.chipClasses)
        val chipAppSettings = findViewById<TextView>(R.id.chipAppSettings)

        // FAQ ITEMS
        val itemFaq1 = findViewById<LinearLayout>(R.id.itemFaq1)
        val itemFaq2 = findViewById<LinearLayout>(R.id.itemFaq2)
        val itemFaq3 = findViewById<LinearLayout>(R.id.itemFaq3)
        val itemFaq4 = findViewById<LinearLayout>(R.id.itemFaq4)

        // NAV
        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // APPLIED YOUR SIMPLE BACK BUTTON
        btnBack.setOnClickListener {
            finish()
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()

            if (query.isEmpty()) {
                Toast.makeText(this, "Search is empty", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        tabFaq.setOnClickListener {
            Toast.makeText(this, "FAQ selected", Toast.LENGTH_SHORT).show()
        }

        tabContactUs.setOnClickListener {
            startActivity(Intent(this, HelpCenterContact::class.java))
        }

        chipAccount.setOnClickListener {
            Toast.makeText(this, "Account selected", Toast.LENGTH_SHORT).show()
        }

        chipClasses.setOnClickListener {
            Toast.makeText(this, "Classes selected", Toast.LENGTH_SHORT).show()
        }

        chipAppSettings.setOnClickListener {
            Toast.makeText(this, "App Settings selected", Toast.LENGTH_SHORT).show()
        }

        itemFaq1.setOnClickListener {
            Toast.makeText(this, "Already expanded", Toast.LENGTH_SHORT).show()
        }

        itemFaq2.setOnClickListener {
            startActivity(Intent(this, HelpCenter::class.java))
        }

        itemFaq3.setOnClickListener {
            startActivity(Intent(this, HelpCenter::class.java))
        }

        itemFaq4.setOnClickListener {
            startActivity(Intent(this, HelpCenterForgotPassword::class.java))
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}