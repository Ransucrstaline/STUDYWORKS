package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Quiz : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz)

        // ===== HEADER BUTTONS =====
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        // ===== EXTRA BUTTONS =====
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== QUIZ OPTIONS =====
        val btnIdentification = findViewById<LinearLayout>(R.id.btnIdentification)
        val btnMultipleChoice = findViewById<LinearLayout>(R.id.btnMultipleChoice)
        val btnTrueFalse = findViewById<LinearLayout>(R.id.btnTrueFalse)

        // ===== BOTTOM NAV =====
        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        // ===== HEADER ACTIONS =====
        btnBack.setOnClickListener {
            finish()
        }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        // ===== QUIZ NAVIGATION =====
        btnIdentification.setOnClickListener {
            startActivity(Intent(this, QuizIden::class.java))
        }

        btnMultipleChoice.setOnClickListener {
            startActivity(Intent(this, QuizMulti::class.java))
        }

        btnTrueFalse.setOnClickListener {
            startActivity(Intent(this, QuizTruFalse::class.java))
        }

        // ===== BOTTOM NAVIGATION =====
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}