package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecordsDate : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout
    private lateinit var tvTotalStudents: TextView

    private var dateList: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records_date)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        etSearch = findViewById(R.id.etSearch)
        tableBody = findViewById(R.id.tableBody)
        tvTotalStudents = findViewById(R.id.tvTotalStudents)

        val totalStudents = intent.getIntExtra("total_students", 0)
        dateList = intent.getStringArrayListExtra("date_list") ?: emptyList()

        tvTotalStudents.text = "Total Students: $totalStudents"

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        renderDateRows(dateList)

        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString().trim().lowercase()
            val filtered = dateList.filter { it.lowercase().contains(query) }
            renderDateRows(filtered)
            Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun renderDateRows(list: List<String>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No dates found"
                textSize = 15f
                setPadding(32, 32, 32, 32)
            }
            tableBody.addView(emptyText)
            return
        }

        list.forEachIndexed { index, date ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
                setBackgroundColor(android.graphics.Color.WHITE)
            }

            val dateText = TextView(this).apply {
                text = date
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            row.addView(dateText)
            tableBody.addView(row)

            if (index != list.lastIndex) {
                val divider = android.view.View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#D9D9D9"))
                }
                tableBody.addView(divider)
            }
        }
    }
}