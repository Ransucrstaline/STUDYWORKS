package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Announcements : AppCompatActivity() {

    private var selectedFilter = "All"
    private var classId = ""

    private lateinit var chipAll: TextView
    private lateinit var chipImportant: TextView
    private lateinit var chipUpdate: TextView
    private lateinit var chipDeadline: TextView
    private lateinit var announcementContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcements)

        // Get class ID from intent
        classId = intent.getStringExtra("class_id") ?: ""

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)

        // ===== SEARCH + FILTER =====
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)

        // ===== CALENDAR FLOAT BUTTON =====
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== CATEGORY CHIPS =====
        chipAll = findViewById(R.id.chipAll)
        chipImportant = findViewById(R.id.chipImportant)
        chipUpdate = findViewById(R.id.chipUpdate)
        chipDeadline = findViewById(R.id.chipDeadline)

        // ===== ANNOUNCEMENT ACTIONS =====
        val btnAddAnnouncement = findViewById<LinearLayout>(R.id.btnAddAnnouncement)
        announcementContainer = findViewById(R.id.announcementContainer)

        // ===== CLICK EVENTS =====
        btnBack.setOnClickListener {
            finish()
        }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        chipAll.setOnClickListener {
            selectedFilter = "All"
            updateChipUI()
            displayAnnouncements()
        }

        chipImportant.setOnClickListener {
            selectedFilter = "Important"
            updateChipUI()
            displayAnnouncements()
        }

        chipUpdate.setOnClickListener {
            selectedFilter = "Update"
            updateChipUI()
            displayAnnouncements()
        }

        chipDeadline.setOnClickListener {
            selectedFilter = "Deadline"
            updateChipUI()
            displayAnnouncements()
        }

        btnAddAnnouncement.setOnClickListener {
            val intent = Intent(this, AnnouncementActivity::class.java)
            intent.putExtra("class_id", classId)
            startActivity(intent)
        }

        // ===== SEARCH ACTION =====
        etSearch.setOnEditorActionListener { _, _, _ ->
            val searchText = etSearch.text.toString().trim()
            if (searchText.isEmpty()) {
                displayAnnouncements()
            } else {
                filterAnnouncementsBySearch(searchText)
            }
            true
        }

        // Load announcements on activity start
        displayAnnouncements()
    }

    override fun onResume() {
        super.onResume()
        // Refresh announcements when returning to this screen
        displayAnnouncements()
    }

    private fun displayAnnouncements() {
        announcementContainer.removeAllViews()

        val announcements = if (classId.isEmpty()) {
            DataManager.getAllAnnouncements()
        } else {
            DataManager.getAnnouncementsByClass(classId)
        }

        val filteredAnnouncements = if (selectedFilter == "All") {
            announcements
        } else {
            announcements.filter { it.category == selectedFilter }
        }

        if (filteredAnnouncements.isEmpty()) {
            val emptyView = TextView(this).apply {
                text = "No announcements yet"
                textSize = 16f
                setPadding(16, 16, 16, 16)
            }
            announcementContainer.addView(emptyView)
        } else {
            for (announcement in filteredAnnouncements) {
                val announcementView = createAnnouncementView(announcement)
                announcementContainer.addView(announcementView)
            }
        }
    }

    private fun filterAnnouncementsBySearch(searchText: String) {
        announcementContainer.removeAllViews()

        val announcements = if (classId.isEmpty()) {
            DataManager.getAllAnnouncements()
        } else {
            DataManager.getAnnouncementsByClass(classId)
        }

        val filteredAnnouncements = announcements.filter {
            it.title.contains(searchText, ignoreCase = true) ||
            it.description.contains(searchText, ignoreCase = true)
        }

        if (filteredAnnouncements.isEmpty()) {
            val emptyView = TextView(this).apply {
                text = "No announcements found"
                textSize = 16f
                setPadding(16, 16, 16, 16)
            }
            announcementContainer.addView(emptyView)
        } else {
            for (announcement in filteredAnnouncements) {
                val announcementView = createAnnouncementView(announcement)
                announcementContainer.addView(announcementView)
            }
        }
    }

    private fun createAnnouncementView(announcement: AnnouncementData): LinearLayout {
        val view = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(16, 16, 16, 16)
            setBackgroundColor(resources.getColor(android.R.color.white, null))
        }

        // Category badge
        val categoryBadge = TextView(this).apply {
            text = announcement.category
            textSize = 12f
            setPadding(8, 4, 8, 4)
            setBackgroundColor(getCategoryColor(announcement.category))
            setTextColor(resources.getColor(android.R.color.white, null))
        }
        view.addView(categoryBadge)

        // Title
        val titleView = TextView(this).apply {
            text = announcement.title
            textSize = 18f
            setPadding(0, 8, 0, 4)
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        view.addView(titleView)

        // Description
        val descriptionView = TextView(this).apply {
            text = announcement.description
            textSize = 14f
            setPadding(0, 4, 0, 8)
        }
        view.addView(descriptionView)

        // Date
        val dateView = TextView(this).apply {
            text = "Posted: ${announcement.postDate}"
            textSize = 12f
            setPadding(0, 4, 0, 0)
            setTextColor(resources.getColor(android.R.color.darker_gray, null))
        }
        view.addView(dateView)

        // Divider
        val divider = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                2
            )
            setBackgroundColor(resources.getColor(android.R.color.darker_gray, null))
        }
        view.addView(divider)

        return view
    }

    private fun getCategoryColor(category: String): Int {
        return when (category) {
            "Important" -> resources.getColor(android.R.color.holo_red_light, null)
            "Update" -> resources.getColor(android.R.color.holo_blue_light, null)
            "Deadline" -> resources.getColor(android.R.color.holo_orange_light, null)
            else -> resources.getColor(android.R.color.darker_gray, null)
        }
    }

    private fun updateChipUI() {
        chipAll.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        chipImportant.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        chipUpdate.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        chipDeadline.setBackgroundColor(resources.getColor(android.R.color.transparent, null))

        when (selectedFilter) {
            "All" -> chipAll.setBackgroundColor(
                resources.getColor(android.R.color.darker_gray, null)
            )
            "Important" -> chipImportant.setBackgroundColor(
                resources.getColor(android.R.color.holo_red_light, null)
            )
            "Update" -> chipUpdate.setBackgroundColor(
                resources.getColor(android.R.color.holo_blue_light, null)
            )
            "Deadline" -> chipDeadline.setBackgroundColor(
                resources.getColor(android.R.color.holo_orange_light, null)
            )
        }
    }
}
