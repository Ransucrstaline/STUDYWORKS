package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HelpCenterLogin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_center_login)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchHelp = findViewById<EditText>(R.id.etSearchHelp)

        val tabFaq = findViewById<TextView>(R.id.tabFaq)
        val tabContactUs = findViewById<TextView>(R.id.tabContactUs)

        val chipAccount = findViewById<TextView>(R.id.chipAccount)
        val chipClasses = findViewById<TextView>(R.id.chipClasses)
        val chipAppSettings = findViewById<TextView>(R.id.chipAppSettings)

        val tvSteps = findViewById<TextView>(R.id.tvSteps)

        // 🔙 SIMPLE BACK (YOUR CODE APPLIED)
        btnBack.setOnClickListener {
            finish()
        }

        // 🔝 HEADER ACTIONS
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // 🧭 TABS
        tabFaq.setOnClickListener {
            Toast.makeText(this, "FAQ selected", Toast.LENGTH_SHORT).show()
        }

        tabContactUs.setOnClickListener {
            startActivity(Intent(this, HelpCenterContact::class.java))
        }

        // 🏷️ CHIPS
        chipAccount.setOnClickListener {
            Toast.makeText(this, "Account selected", Toast.LENGTH_SHORT).show()
        }

        chipClasses.setOnClickListener {
            Toast.makeText(this, "Classes selected", Toast.LENGTH_SHORT).show()
        }

        chipAppSettings.setOnClickListener {
            Toast.makeText(this, "App Settings selected", Toast.LENGTH_SHORT).show()
        }

        // 🔍 SEARCH
        etSearchHelp.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearchHelp.text}", Toast.LENGTH_SHORT).show()
            true
        }

        // 📖 STEPS CLICK
        tvSteps.setOnClickListener {
            Toast.makeText(this, "Expanded: How to login", Toast.LENGTH_SHORT).show()
        }
    }
}