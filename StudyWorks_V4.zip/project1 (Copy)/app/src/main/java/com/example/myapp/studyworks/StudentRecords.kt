package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout
    private lateinit var tvStudentRecords: TextView
    private var classId: String = ""

    private val hardcodedStudents = listOf(
        StudentInfo(
            name = "Hannah Isabelle",
            section = "BSCS 3A",
            attendanceList = listOf(
                AttendanceInfo("Present - 28", 30, listOf("April 10, 2026", "April 12, 2026")),
                AttendanceInfo("Late - 2", 30, listOf("April 11, 2026", "April 18, 2026")),
                AttendanceInfo("Absent - 1", 30, listOf("April 20, 2026"))
            )
        ),
        StudentInfo(
            name = "John Cruz",
            section = "BSCS 3B",
            attendanceList = listOf(
                AttendanceInfo("Present - 25", 27, listOf("April 10, 2026")),
                AttendanceInfo("Absent - 2", 27, listOf("April 14, 2026"))
            )
        ),
        StudentInfo(
            name = "Maria Santos",
            section = "BSIT 2A",
            attendanceList = listOf(
                AttendanceInfo("Present - 32", 35, listOf("April 09, 2026")),
                AttendanceInfo("Late - 1", 35, listOf("April 17, 2026"))
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        classId = intent.getStringExtra("class_id") ?: ""

        // ===== VIEWS =====
        val btnAdd      = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu     = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter   = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)
        val btnBack     = findViewById<ImageView>(R.id.btnBack)
        tvStudentRecords = findViewById(R.id.tvStudentRecords)
        etSearch  = findViewById(R.id.etSearch)
        tableBody = findViewById(R.id.tableBody)

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener      { Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show() }
        btnMenu.setOnClickListener     { Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show() }
        btnFilter.setOnClickListener   { Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show() }
        btnCalendar.setOnClickListener { Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show() }
        btnBack.setOnClickListener     { finish() }

        // ===== BOTTOM NAV =====
        setupBottomNav()

        // ===== INITIAL LOAD =====
        loadAndRenderData()

        // ===== LIVE SEARCH =====
        etSearch.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                loadAndRenderData(s?.toString()?.trim()?.lowercase() ?: "")
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun loadAndRenderData(query: String = "") {
        val dynamicStudents = if (classId.isNotEmpty()) {
            DataManager.getStudentsByClass(this, classId).map {
                StudentInfo(it.studentName, it.section, emptyList())
            }
        } else {
            emptyList()
        }

        val allStudents = hardcodedStudents + dynamicStudents

        val filtered = if (query.isEmpty()) {
            allStudents
        } else {
            allStudents.filter {
                it.name.lowercase().contains(query) ||
                it.section.lowercase().contains(query)
            }
        }

        // Update title with count
        tvStudentRecords.text = "Student Records (${filtered.size})"

        renderStudentRows(filtered)
    }

    private fun renderStudentRows(list: List<StudentInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No student records found"
                textSize = 15f
                setPadding(32, 48, 32, 48)
                gravity = android.view.Gravity.CENTER
                setTextColor(android.graphics.Color.parseColor("#7C7281"))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }
            tableBody.addView(emptyText)
            return
        }

        val colorEven = android.graphics.Color.parseColor("#FFFFFF")
        val colorOdd  = android.graphics.Color.parseColor("#F7F7FB")
        val colorRipple = android.graphics.Color.parseColor("#E8F5E9")

        list.forEachIndexed { index, item ->
            val rowBg = if (index % 2 == 0) colorEven else colorOdd

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 20, 24, 20)
                isClickable = true
                isFocusable = true
                setBackgroundColor(rowBg)
            }

            // "Name" column — left-aligned, wraps text
            val nameText = TextView(this).apply {
                text = item.name
                textSize = 14f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
                setTextColor(android.graphics.Color.parseColor("#111111"))
                typeface = android.graphics.Typeface.DEFAULT
            }

            // "Section" column — centered, wraps text
            val sectionText = TextView(this).apply {
                text = item.section
                textSize = 14f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
                setTextColor(android.graphics.Color.parseColor("#444444"))
                gravity = android.view.Gravity.CENTER
            }

            row.addView(nameText)
            row.addView(sectionText)

            // Highlight on press
            row.setOnClickListener {
                row.setBackgroundColor(colorRipple)
                row.postDelayed({ row.setBackgroundColor(rowBg) }, 150)
                val intent = Intent(this, StudentRecordsAttendance::class.java)
                intent.putExtra("student_name", item.name)
                intent.putExtra("student_section", item.section)
                startActivity(intent)
            }

            tableBody.addView(row)

            // Divider between rows
            if (index != list.lastIndex) {
                val divider = android.view.View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#E0E0E0"))
                }
                tableBody.addView(divider)
            }
        }
    }

    private fun setupBottomNav() {
        findViewById<LinearLayout>(R.id.navHome)?.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.navClasses)?.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.navNotification)?.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
        }
        findViewById<LinearLayout>(R.id.navProfile)?.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
        findViewById<LinearLayout>(R.id.navMore)?.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
        }
    }
}
