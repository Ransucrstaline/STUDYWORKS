package com.example.myapp.studyworks

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout
    private lateinit var tvStudentRecords: TextView
    private lateinit var tvStudentCount: TextView
    private lateinit var dbHelper: DatabaseHelper

    private var classId: String = ""

    // ── No hardcoded students – data comes purely from SQLite ──

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        classId  = intent.getStringExtra("class_id") ?: ""
        dbHelper = DatabaseHelper(this)

        // ── Views ──
        val btnAdd      = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu     = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter   = findViewById<ImageView>(R.id.btnFilter)
        val btnBack     = findViewById<ImageView>(R.id.btnBack)
        tvStudentRecords = findViewById(R.id.tvStudentRecords)
        tvStudentCount   = findViewById(R.id.tvStudentCount)
        etSearch         = findViewById(R.id.etSearch)
        tableBody        = findViewById(R.id.tableBody)

        // ── Button actions ──
        btnAdd.setOnClickListener    { showAddStudentDialog() }
        btnMenu.setOnClickListener   { Toast.makeText(this, "Menu", Toast.LENGTH_SHORT).show() }
        btnFilter.setOnClickListener { Toast.makeText(this, "Filter", Toast.LENGTH_SHORT).show() }
        btnBack.setOnClickListener   { finish() }

        // ── Bottom nav ──
        setupBottomNav()

        // ── Live search ──
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {
                loadAndRenderData(s?.toString()?.trim()?.lowercase() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // ── Initial load ──
        loadAndRenderData()
    }

    // ════════════════════════════════════════════
    //  ADD STUDENT DIALOG
    // ════════════════════════════════════════════
    private fun showAddStudentDialog() {
        val ctx = this

        // Root container
        val container = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 32, 56, 16)
        }

        // Name field
        val labelName = TextView(ctx).apply {
            text = "Student Name"
            textSize = 13f
            setTextColor(Color.parseColor("#555555"))
            typeface = Typeface.DEFAULT_BOLD
        }
        val etName = EditText(ctx).apply {
            hint = "e.g. Juan dela Cruz"
            textSize = 14f
            setTextColor(Color.parseColor("#111111"))
            maxLines = 1
            filters = arrayOf(InputFilter.LengthFilter(60))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setBackgroundResource(R.drawable.bg_edittext)
            setPadding(24, 16, 24, 16)
        }

        // Section field
        val labelSection = TextView(ctx).apply {
            text = "Section"
            textSize = 13f
            setTextColor(Color.parseColor("#555555"))
            typeface = Typeface.DEFAULT_BOLD
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = 20
            layoutParams = lp
        }
        val etSection = EditText(ctx).apply {
            hint = "e.g. BSCS 3A"
            textSize = 14f
            setTextColor(Color.parseColor("#111111"))
            maxLines = 1
            filters = arrayOf(InputFilter.LengthFilter(30))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setBackgroundResource(R.drawable.bg_edittext)
            setPadding(24, 16, 24, 16)
        }

        container.addView(labelName)
        container.addView(etName)
        container.addView(labelSection)
        container.addView(etSection)

        AlertDialog.Builder(ctx)
            .setTitle("Add Student")
            .setView(container)
            .setPositiveButton("Save", null)   // set manually to prevent auto-dismiss on empty input
            .setNegativeButton("Cancel", null)
            .create()
            .also { dialog ->
                dialog.show()

                // Style the title
                dialog.setOnShowListener {
                    val btnSave   = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                    val btnCancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

                    btnSave.setTextColor(Color.parseColor("#2E7D32"))
                    btnCancel.setTextColor(Color.parseColor("#9E9E9E"))

                    btnSave.setOnClickListener {
                        val name    = etName.text.toString().trim()
                        val section = etSection.text.toString().trim()

                        // Validation
                        if (name.isEmpty()) {
                            etName.error = "Name is required"
                            etName.requestFocus()
                            return@setOnClickListener
                        }
                        if (section.isEmpty()) {
                            etSection.error = "Section is required"
                            etSection.requestFocus()
                            return@setOnClickListener
                        }

                        // Duplicate check
                        val existing = dbHelper.getEnrollmentsByClass(classId)
                        val isDuplicate = existing.any {
                            it.studentName.lowercase() == name.lowercase()
                        }
                        if (isDuplicate) {
                            etName.error = "Student already added"
                            etName.requestFocus()
                            return@setOnClickListener
                        }

                        // Save to SQLite
                        val enrollment = StudentEnrollment(
                            studentName = name,
                            classId     = classId.ifEmpty { "global" },
                            section     = section
                        )
                        dbHelper.addEnrollment(enrollment)

                        Toast.makeText(ctx, "✓ $name added", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                        loadAndRenderData(etSearch.text.toString().trim().lowercase())
                    }
                }
            }
    }

    // ════════════════════════════════════════════
    //  DATA LOAD
    // ════════════════════════════════════════════
    private fun loadAndRenderData(query: String = "") {
        val all = dbHelper.getEnrollmentsByClass(
            classId.ifEmpty { "global" }
        ).map { StudentInfo(it.studentName, it.section, emptyList()) }

        val filtered = if (query.isEmpty()) all else all.filter {
            it.name.lowercase().contains(query) ||
            it.section.lowercase().contains(query)
        }

        updateStudentCount(filtered.size, all.size, query)
        renderStudentRows(filtered)
    }

    private fun updateStudentCount(filtered: Int, total: Int, query: String) {
        tvStudentCount.text = if (query.isEmpty()) {
            "$total Student${if (total != 1) "s" else ""}"
        } else {
            "$filtered of $total Student${if (total != 1) "s" else ""}"
        }
    }

    // ════════════════════════════════════════════
    //  RENDER TABLE ROWS
    // ════════════════════════════════════════════
    private fun renderStudentRows(list: List<StudentInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            renderEmptyState()
            return
        }

        val colorEven  = Color.parseColor("#FFFFFF")
        val colorOdd   = Color.parseColor("#F7F9FC")
        val colorPress = Color.parseColor("#E8F5E9")

        list.forEachIndexed { index, item ->
            val rowBg = if (index % 2 == 0) colorEven else colorOdd

            // Row container
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = resources.getDimensionPixelSize(
                    android.R.dimen.app_icon_size  // ≈48dp touch target
                )
                setPadding(8, 14, 8, 14)
                isClickable = true
                isFocusable = true
                setBackgroundColor(rowBg)
            }

            // Column #1 — Row number
            val numText = TextView(this).apply {
                text = "${index + 1}"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#9E9E9E"))
                layoutParams = LinearLayout.LayoutParams(36.dp, LinearLayout.LayoutParams.WRAP_CONTENT)
            }

            // Vertical divider
            val div1 = divider()

            // Column #2 — Student name (weight 3)
            val nameText = TextView(this).apply {
                text = item.name
                textSize = 14f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.parseColor("#111111"))
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 3f)
                lp.setMargins(12, 0, 8, 0)
                layoutParams = lp
            }

            // Vertical divider
            val div2 = divider()

            // Column #3 — Section (weight 2)
            val sectionText = TextView(this).apply {
                text = item.section
                textSize = 13f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#444444"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f)
            }

            row.addView(numText)
            row.addView(div1)
            row.addView(nameText)
            row.addView(div2)
            row.addView(sectionText)

            // Tap → open attendance
            row.setOnClickListener {
                row.setBackgroundColor(colorPress)
                row.postDelayed({ row.setBackgroundColor(rowBg) }, 180)
                val intent = Intent(this, StudentRecordsAttendance::class.java)
                intent.putExtra("student_name", item.name)
                intent.putExtra("student_section", item.section)
                startActivity(intent)
            }

            // Long-press → delete confirmation
            row.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Remove Student")
                    .setMessage("Remove \"${item.name}\" from records?")
                    .setPositiveButton("Remove") { _, _ ->
                        dbHelper.deleteEnrollment(item.name, classId.ifEmpty { "global" })
                        Toast.makeText(this, "${item.name} removed", Toast.LENGTH_SHORT).show()
                        loadAndRenderData(etSearch.text.toString().trim().lowercase())
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }

            tableBody.addView(row)

            // Horizontal divider between rows
            if (index != list.lastIndex) {
                tableBody.addView(rowDivider())
            }
        }
    }

    // ── Empty State ──
    private fun renderEmptyState() {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 64, 32, 64)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val icon = TextView(this).apply {
            text = "👤"
            textSize = 40f
            gravity = Gravity.CENTER
        }
        val msg = TextView(this).apply {
            text = "No students yet"
            textSize = 16f
            textAlignment = android.view.View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.parseColor("#555555"))
            typeface = Typeface.DEFAULT_BOLD
        }
        val sub = TextView(this).apply {
            text = "Tap the  ＋  button above to add a student"
            textSize = 13f
            textAlignment = android.view.View.TEXT_ALIGNMENT_CENTER
            setTextColor(Color.parseColor("#9E9E9E"))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = 8
            layoutParams = lp
        }
        wrapper.addView(icon)
        wrapper.addView(msg)
        wrapper.addView(sub)
        tableBody.addView(wrapper)
    }

    // ── Helpers ──
    private fun divider() = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, LinearLayout.LayoutParams.MATCH_PARENT).also {
            it.setMargins(0, 4, 0, 4)
        }
        setBackgroundColor(Color.parseColor("#E0E0E0"))
    }

    private fun rowDivider() = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 1
        )
        setBackgroundColor(Color.parseColor("#EEEEEE"))
    }

    private val Int.dp: Int get() =
        (this * resources.displayMetrics.density).toInt()

    // ════════════════════════════════════════════
    //  BOTTOM NAV
    // ════════════════════════════════════════════
    private fun setupBottomNav() {
        findViewById<LinearLayout>(R.id.navHome)?.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.navClasses)?.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.navNotification)?.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
        }
        findViewById<LinearLayout>(R.id.navProfile)?.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
        findViewById<LinearLayout>(R.id.navMore)?.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
        }
    }
}
