package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Identification : AppCompatActivity() {

    private var answerValue: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_identification)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnQuestionType = findViewById<LinearLayout>(R.id.btnQuestionType)
        val switchRequired = findViewById<Switch>(R.id.switchRequired)
        val etQuestion = findViewById<EditText>(R.id.etQuestion)
        val etAnswer = findViewById<EditText>(R.id.etAnswer)
        val btnAddAnswer = findViewById<Button>(R.id.btnAddAnswer)
        val btnUpload = findViewById<Button>(R.id.btnUpload)
        val btnClose = findViewById<ImageView>(R.id.btnClose)

        etAnswer.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                answerValue = s.toString()
            }

            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnQuestionType.setOnClickListener {
            Toast.makeText(this, "Question type clicked", Toast.LENGTH_SHORT).show()
        }

        btnAddAnswer.setOnClickListener {
            val answer = etAnswer.text.toString().trim()

            if (answer.isEmpty()) {
                etAnswer.error = "Please enter an answer"
            } else {
                Toast.makeText(this, "Answer added: $answer", Toast.LENGTH_SHORT).show()
            }
        }

        btnUpload.setOnClickListener {
            val question = etQuestion.text.toString().trim()
            val answer = etAnswer.text.toString().trim()
            val required = switchRequired.isChecked

            when {
                question.isEmpty() -> etQuestion.error = "Please enter a question"
                answer.isEmpty() -> etAnswer.error = "Please enter an answer"
                else -> {
                    Toast.makeText(
                        this,
                        "Uploaded\nQuestion: $question\nAnswer: $answer\nRequired: $required",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }

        btnClose.setOnClickListener {
            finish()
        }
    }
}