package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class AddTodoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_todo)

        val etTitle = findViewById<EditText>(R.id.etTodoTitle)
        val etDate = findViewById<EditText>(R.id.etTodoDate)
        val btnSave = findViewById<Button>(R.id.btnSaveTodo)

        btnSave.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val date = etDate.text.toString().trim()

            if (title.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val newTodo = TodoData(
                title = title,
                dueDate = date,
                type = "Task"
            )

            DataManager.addTodo(newTodo)
            Toast.makeText(this, "Task added!", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
