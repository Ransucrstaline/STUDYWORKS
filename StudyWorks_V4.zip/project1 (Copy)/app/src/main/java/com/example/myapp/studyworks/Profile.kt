package com.example.myapp.studyworks

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Profile : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val tvName = findViewById<TextView>(R.id.tvName)
        val tvUsername = findViewById<TextView>(R.id.tvEmail)
        
        val user = DataManager.getCurrentUser()
        if (user != null) {
            tvName.text = "${user.firstName} ${user.lastName}"
            tvUsername.text = "@${user.username}"
        }

        val btnBack = findViewById<ImageView>(R.id.imgBack)
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val imgAvatar = findViewById<ImageView>(R.id.imgAvatar)
        val imgCamera = findViewById<ImageView>(R.id.imgCamera)

        val btnEditProfile = findViewById<LinearLayout>(R.id.itemEditProfile)
        val btnChangePassword = findViewById<LinearLayout>(R.id.itemChangePassword)
        val btnLanguage = findViewById<LinearLayout>(R.id.itemLanguage)
        val btnHelpCenter = findViewById<LinearLayout>(R.id.itemHelpCenter)

        val btnLogout = findViewById<Button>(R.id.btnLogout)

        btnBack.setOnClickListener { finish() }
        btnAdd.setOnClickListener { startActivity(Intent(this, Add::class.java)) }
        btnMenu.setOnClickListener { startActivity(Intent(this, MoreActivity::class.java)) }
        imgAvatar.setOnClickListener { startActivity(Intent(this, EditProfile::class.java)) }
        imgCamera.setOnClickListener { startActivity(Intent(this, EditProfile::class.java)) }
        btnEditProfile.setOnClickListener { startActivity(Intent(this, EditProfile::class.java)) }
        btnChangePassword.setOnClickListener { startActivity(Intent(this, ChangePassword::class.java)) }
        btnLanguage.setOnClickListener { startActivity(Intent(this, Language::class.java)) }
        btnHelpCenter.setOnClickListener { startActivity(Intent(this, HelpCenter::class.java)) }

        btnLogout.setOnClickListener {
            val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            with(sharedPref.edit()) {
                putBoolean("RememberMe", false)
                apply()
            }
            DataManager.setCurrentUser(null)
            val intent = Intent(this, Login::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome)?.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }
        findViewById<LinearLayout>(R.id.navClasses)?.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }
        findViewById<LinearLayout>(R.id.navNotification)?.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}
