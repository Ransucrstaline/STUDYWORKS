package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Important : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_importants)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)
        val etSearch = findViewById<EditText>(R.id.etSearch)

        val chipAll = findViewById<TextView>(R.id.chipAll)
        val chipImportant = findViewById<TextView>(R.id.chipImportant)
        val chipUpdate = findViewById<TextView>(R.id.chipUpdate)
        val chipDeadline = findViewById<TextView>(R.id.chipDeadline)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        chipAll.setOnClickListener {
            Toast.makeText(this, "All clicked", Toast.LENGTH_SHORT).show()
        }

        chipImportant.setOnClickListener {
            Toast.makeText(this, "Important clicked", Toast.LENGTH_SHORT).show()
        }

        chipUpdate.setOnClickListener {
            Toast.makeText(this, "Update clicked", Toast.LENGTH_SHORT).show()
        }

        chipDeadline.setOnClickListener {
            Toast.makeText(this, "Deadline clicked", Toast.LENGTH_SHORT).show()
        }

        etSearch.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearch.text}", Toast.LENGTH_SHORT).show()
            true
        }
    }
}