package com.example.myapp.studyworks

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AnnouncementActivity : AppCompatActivity() {

    private var selectedCategory = ""
    private var classId = ""

    private lateinit var tvImportant: TextView
    private lateinit var tvUpdate: TextView
    private lateinit var tvDeadline: TextView
    private lateinit var etTitle: EditText
    private lateinit var etDescription: EditText
    private lateinit var btnPost: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcement)

        // Get class ID from intent
        classId = intent.getStringExtra("class_id") ?: ""

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnBack = findViewById<ImageView>(R.id.btnClose)

        tvImportant = findViewById(R.id.tvImportant)
        tvUpdate = findViewById(R.id.tvUpdate)
        tvDeadline = findViewById(R.id.tvDeadline)

        etTitle = findViewById(R.id.etTitle)
        etDescription = findViewById(R.id.etDescription)

        btnPost = findViewById(R.id.btnUpload)

        val btnUndo = findViewById<ImageView>(R.id.btnUndo)
        val btnRedo = findViewById<ImageView>(R.id.btnRedo)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            finish()
        }

        tvImportant.setOnClickListener {
            selectCategory("Important")
        }

        tvUpdate.setOnClickListener {
            selectCategory("Update")
        }

        tvDeadline.setOnClickListener {
            selectCategory("Deadline")
        }

        btnUndo.setOnClickListener {
            Toast.makeText(this, "Undo clicked", Toast.LENGTH_SHORT).show()
        }

        btnRedo.setOnClickListener {
            Toast.makeText(this, "Redo clicked", Toast.LENGTH_SHORT).show()
        }

        btnPost.setOnClickListener {
            postAnnouncement()
        }
    }

    private fun selectCategory(category: String) {
        selectedCategory = category
        updateCategoryUI()
        Toast.makeText(this, "$category selected", Toast.LENGTH_SHORT).show()
    }

    private fun updateCategoryUI() {
        // Reset all category buttons
        tvImportant.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        tvUpdate.setBackgroundColor(resources.getColor(android.R.color.transparent, null))
        tvDeadline.setBackgroundColor(resources.getColor(android.R.color.transparent, null))

        // Highlight the selected category
        when (selectedCategory) {
            "Important" -> tvImportant.setBackgroundColor(
                resources.getColor(android.R.color.holo_red_light, null)
            )
            "Update" -> tvUpdate.setBackgroundColor(
                resources.getColor(android.R.color.holo_blue_light, null)
            )
            "Deadline" -> tvDeadline.setBackgroundColor(
                resources.getColor(android.R.color.holo_orange_light, null)
            )
        }
    }

    private fun postAnnouncement() {
        val title = etTitle.text.toString().trim()
        val description = etDescription.text.toString().trim()

        if (title.isEmpty()) {
            etTitle.error = "Please enter a title"
            return
        }

        if (description.isEmpty()) {
            etDescription.error = "Please enter a description"
            return
        }

        if (selectedCategory.isEmpty()) {
            Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show()
            return
        }

        // Create announcement data
        val postDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val announcement = AnnouncementData(
            classId = classId,
            title = title,
            description = description,
            category = selectedCategory,
            postDate = postDate
        )

        // Save to DataManager
        DataManager.addAnnouncement(announcement)

        Toast.makeText(this, "Announcement posted successfully!", Toast.LENGTH_SHORT).show()
        finish()
    }
}
