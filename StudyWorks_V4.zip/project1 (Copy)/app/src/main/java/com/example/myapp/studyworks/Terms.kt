package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Terms : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms)

        val btnBack = findViewById<ImageView>(R.id.imgBack) // matches your XML
        val cbAccept = findViewById<CheckBox>(R.id.cbAccept)
        val btnCancel = findViewById<Button>(R.id.btnCancel)
        val btnContinue = findViewById<Button>(R.id.btnContinue)

        // 🔙 APPLIED SIMPLE BACK LOGIC
        btnBack.setOnClickListener {
            finish()
        }

        btnCancel.setOnClickListener {
            finish()
        }

        // ✅ CONTINUE LOGIC
        btnContinue.setOnClickListener {
            if (cbAccept.isChecked) {
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            } else {
                cbAccept.error = "Please accept the terms first"
            }
        }
    }
}