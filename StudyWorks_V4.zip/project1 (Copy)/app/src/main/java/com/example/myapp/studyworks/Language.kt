package com.example.myapp.studyworks

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Language : AppCompatActivity() {

    private var selectedLanguage = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_language)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val etSearchLanguage = findViewById<EditText>(R.id.etSearchLanguage)

        val itemFilipino = findViewById<LinearLayout>(R.id.itemFilipino)
        val itemEnglish = findViewById<LinearLayout>(R.id.itemEnglish)
        val itemJapanese = findViewById<LinearLayout>(R.id.itemJapanese)
        val itemKorean = findViewById<LinearLayout>(R.id.itemKorean)
        val itemChinese = findViewById<LinearLayout>(R.id.itemChinese)

        val btnCancel = findViewById<Button>(R.id.btnCancel)
        val btnApply = findViewById<Button>(R.id.btnApply)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener {
            finish()
        }

        itemFilipino.setOnClickListener {
            selectedLanguage = "Filipino"
            Toast.makeText(this, "Filipino selected", Toast.LENGTH_SHORT).show()
        }

        itemEnglish.setOnClickListener {
            selectedLanguage = "English"
            Toast.makeText(this, "English selected", Toast.LENGTH_SHORT).show()
        }

        itemJapanese.setOnClickListener {
            selectedLanguage = "Japanese"
            Toast.makeText(this, "Japanese selected", Toast.LENGTH_SHORT).show()
        }

        itemKorean.setOnClickListener {
            selectedLanguage = "Korean"
            Toast.makeText(this, "Korean selected", Toast.LENGTH_SHORT).show()
        }

        itemChinese.setOnClickListener {
            selectedLanguage = "Chinese"
            Toast.makeText(this, "Chinese selected", Toast.LENGTH_SHORT).show()
        }

        etSearchLanguage.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearchLanguage.text}", Toast.LENGTH_SHORT).show()
            true
        }

        btnCancel.setOnClickListener {
            finish()
        }

        btnApply.setOnClickListener {
            if (selectedLanguage.isEmpty()) {
                Toast.makeText(this, "Please select a language", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Language set to $selectedLanguage", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}