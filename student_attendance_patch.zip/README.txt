Paste these files into your Android project:

1. app/src/main/java/com/example/myapp/studyworks/StudentRecords.kt
2. app/src/main/java/com/example/myapp/studyworks/AttendanceActivity.kt

Also check AndroidManifest.xml has:
<activity android:name=".studyworks.AttendanceActivity" />

Your Student Records XML must have this container:
<LinearLayout android:id="@+id/tableBody" ... />

Upgrade included:
- Attendance column is clickable per student.
- Clicking Attendance opens Attendance Page for that specific student.
- Attendance Page can mark Present, Absent, or Late.
- Attendance status is saved using SharedPreferences.
