package com.example.myapp.studyworks

import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AttendanceActivity : AppCompatActivity() {

    private lateinit var studentName: String
    private var selectedStatus = "Present"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        studentName = intent.getStringExtra("student_name") ?: "Selected Student"
        buildAttendanceScreen()
    }

    private fun buildAttendanceScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(20))
            setBackgroundColor(0xFFF7F7F7.toInt())
        }

        val title = TextView(this).apply {
            text = "Attendance Page"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF1B5E20.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val name = TextView(this).apply {
            text = "Student: $studentName"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF222222.toInt())
            setPadding(0, dp(25), 0, dp(15))
        }
        root.addView(name)

        val statusText = TextView(this).apply {
            text = "Choose attendance status"
            textSize = 15f
            setTextColor(0xFF555555.toInt())
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(statusText)

        root.addView(attendanceButton("Present", statusText), LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(attendanceButton("Absent", statusText), LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(attendanceButton("Late", statusText), LinearLayout.LayoutParams(-1, dp(52)))

        val btnSave = Button(this).apply {
            text = "Save Attendance"
            setOnClickListener { saveAttendance() }
        }
        val saveParams = LinearLayout.LayoutParams(-1, dp(55)).apply { topMargin = dp(25) }
        root.addView(btnSave, saveParams)

        val btnBack = Button(this).apply {
            text = "Back"
            setOnClickListener { finish() }
        }
        root.addView(btnBack, LinearLayout.LayoutParams(-1, dp(52)))

        setContentView(root)
    }

    private fun attendanceButton(status: String, statusText: TextView): Button {
        return Button(this).apply {
            text = status
            setOnClickListener {
                selectedStatus = status
                statusText.text = "Selected: $status"
            }
        }
    }

    private fun saveAttendance() {
        getSharedPreferences("student_attendance", MODE_PRIVATE)
            .edit()
            .putString(studentName, selectedStatus)
            .apply()

        Toast.makeText(this, "$studentName marked as $selectedStatus", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
