package com.example.myapp.studyworks

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    data class StudentRecord(
        val name: String,
        val attendance: String,
        val quiz: String,
        val exam: String,
        val date: String
    )

    private val students = listOf(
        StudentRecord("Angelica Cruz", "Attendance", "Quiz", "Exam", "Date"),
        StudentRecord("Mark Santos", "Attendance", "Quiz", "Exam", "Date"),
        StudentRecord("John Rey Dela Cruz", "Attendance", "Quiz", "Exam", "Date"),
        StudentRecord("Maria Lopez", "Attendance", "Quiz", "Exam", "Date"),
        StudentRecord("Carlo Reyes", "Attendance", "Quiz", "Exam", "Date")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        val tableBodyId = resources.getIdentifier("tableBody", "id", packageName)
        val tableBody = if (tableBodyId != 0) findViewById<LinearLayout>(tableBodyId) else null

        tableBody?.removeAllViews()
        students.forEach { student ->
            tableBody?.addView(createStudentRow(student))
        }
    }

    private fun createStudentRow(student: StudentRecord): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 10, 8, 10)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        row.addView(cell(student.name, 190, false))

        val attendanceCell = cell(student.attendance, 130, true)
        attendanceCell.setOnClickListener {
            val intent = Intent(this, AttendanceActivity::class.java)
            intent.putExtra("student_name", student.name)
            startActivity(intent)
        }
        row.addView(attendanceCell)

        row.addView(cell(student.quiz, 100, true))
        row.addView(cell(student.exam, 100, true))
        row.addView(cell(student.date, 100, true))

        return row
    }

    private fun cell(text: String, widthDp: Int, clickable: Boolean): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(10, 8, 10, 8)
            layoutParams = LinearLayout.LayoutParams(dp(widthDp), LinearLayout.LayoutParams.WRAP_CONTENT)

            if (clickable) {
                setTypeface(null, Typeface.BOLD)
                setTextColor(0xFF2E7D32.toInt())
                isClickable = true
                isFocusable = true
            } else {
                setTextColor(0xFF222222.toInt())
            }
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
